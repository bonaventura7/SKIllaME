---
name: tp-benchmarking-report-photocopier-v4
version: 4.0-cm-eu-ncp-unlocked
language: it
risk: high
output: DOCX professionale in inglese + QA report + audit pack
mission: >
  Fotocopiatrice transazionale DOCX per report di benchmarking Transfer Pricing in stile SBNP.
  La skill non genera report creativi: clona template DOCX approvati, modifica XML interni,
  inietta solo dati validati, preserva layout/stili/tabelle/header/footer/appendici e blocca
  l'output se package, arithmetic, semantic, contamination, table, style e council gates non passano.
changelog:
  v4: >
    Aggiunta famiglia CM_EU_NCP con gold reale (Crosspolimeri, contract manufacturing
    plastica primaria, Western Europe, FY2023). Fingerprint XML misurato (non dichiarato).
    Router sbloccato per transaction_type=contract manufacturing + PLI=NCP + geography=EU.
---

# TP Benchmarking Report Photocopier v4 — CM_EU_NCP Unlocked

## 0. Golden Rule

**Never optimize for beauty before fidelity.**

Il report non è valido perché "sembra bello". È valido solo se dimostra di essere un clone
controllato di un template SBNP gold standard, con dati iniettati, layout ereditato e
Quality Gate superato.

```text
CASE_LOCK → TEMPLATE_ROUTER → COPY-ON-WRITE DOCX → XML NODE CLONING → QA GATES → COUNCIL → DELIVERY/BLOCK
```

## 1. Modalità obbligatoria (invariata da v3)

### 1.1 Brainstorming Gate
1. esplora contesto, file allegati e modelli;
2. identifica intento e vincoli;
3. seleziona il caso d'uso;
4. crea una matrice dati bloccante;
5. propone approccio solo dopo aver validato le assunzioni → produce `CASE_LOCK.json`.

### 1.2 Error Detective Gate
```text
Symptom / Impact / Evidence / Root Cause / Minimal Fix / Verification / Prevention
```
Se CRITICAL/HIGH non risolto: non si consegna il DOCX finale, solo QA Failure Report.

### 1.3 LLM Council Gate
Contrarian, First Principles, Expansionist, Outsider, Executor.
Se un advisor segnala CRITICAL non risolto: `BLOCK`.

## 2. CASE_LOCK.json — gate zero

Esempio famiglia CM_EU_NCP (Amenduni, derivato dal gold Crosspolimeri):

```json
{
  "client": "Amenduni Group",
  "transaction": "Contract manufacturing [settore da confermare]",
  "tested_party_type": "contract manufacturer",
  "geography": "Western Europe",
  "pli": "NCP",
  "pli_formula": "EBIT / Total Costs",
  "period": "2023-2021",
  "fiscal_year": "FY2024",
  "tp_catalyst_release": "179 - February 2025",
  "tp_catalyst_update_number": "179008",
  "tp_catalyst_version": "179",
  "initial_population": null,
  "quantitative_rejected": null,
  "after_quantitative": null,
  "qualitative_rejected": null,
  "final_sample": null,
  "observation": null,
  "min_pct": null,
  "q1_pct": null,
  "median_pct": null,
  "q3_pct": null,
  "max_pct": null,
  "template_mode": "clone_existing_docx",
  "appendix_profile": "STANDARD_A_H",
  "release_state": "WORKING_DRAFT"
}
```

### 2.1 CASE_LOCK hard rules
- Se manca un campo obbligatorio: `BLOCK`.
- Se il documento finale contraddice CASE_LOCK: `BLOCK`.
- Se il documento contiene valori old-model in blacklist: `BLOCK`.
- Se arithmetic non riconcilia: `BLOCK`.

## 3. Template Router deterministico

| Caso | PLI | Template profile | Appendici | Note | Stato |
|---|---:|---|---|---|---|
| marketing/support/services | NCP | SVC/MKT_SUPPORT_EU_NCP | FULL_A_I | Usare solo se attività e search narrative sono coerenti | ✅ UNLOCKED (gold: 505-Games, Petrone) |
| event organisation services | NCP | EVENT_ORG_EU_NCP | FULL_A_I | Search NACE 8230 / conventions and trade shows | ⏳ locked, nessun gold |
| contract manufacturing | NCP | CM_EU_NCP | STANDARD_A_H | Non mischiare con service providers | ✅ **UNLOCKED v4** (gold: Crosspolimeri) |
| wholesale distribution | ROS | WHS_EU_ROS | COMPACT_A_F | Non usare per servizi NCP | ⏳ locked, nessun gold |

### 3.1 Router hard fail
```text
0 template selected → BLOCK
>1 template selected → BLOCK
wrong PLI for template → BLOCK
appendix profile mismatch → BLOCK
```

## 4. Template Fingerprint — CM_EU_NCP (misurato, non dichiarato)

Estratto via unzip + regex su XML grezzo di `Crosspolimeri_Report_BMA_CM_FY2024.docx`.
Metodo identico a quello usato per la famiglia SVC (v3), applicato ora a CM.

```json
{
  "template_id": "CM_EU_NCP_crosspolimeri_gold_v1",
  "appendix_profile": "STANDARD_A_H",
  "section_sequence": [
    "Executive Summary",
    "The Search Process",
    "The TP Catalyst Search",
    "Further Selection Process",
    "Final Sample",
    "Summary of Results",
    "Limitations"
  ],
  "appendices": ["A", "B", "C", "D", "E", "F", "G", "H"],
  "visual_tokens": {
    "font_body_docDefaults": "Georgia",
    "font_theme_heading": "Arial",
    "table_header_fill": "800000",
    "table_header_fill_count": 17,
    "table_background_fill": "FFFFFF",
    "vMerge_count": 0,
    "gridSpan_count": 171,
    "total_tables": 7
  },
  "contamination_scan": {
    "north_america_in_footer": [],
    "appendix_I_leak": false
  },
  "critical_tables": {
    "table_1_ncp_summary": "1x7 with merged title row (observation/min/Q1/median/Q3/max)",
    "table_2_search_process": "native search process table (image/native, NACE 201/2016)",
    "further_selection": "complex merged native table (quantitative + qualitative screening)",
    "final_sample": "company/BvD/PLI years/average"
  }
}
```

**Confronto con fingerprint SVC (v3):**

| Elemento | SVC/MKT_SUPPORT (v3) | CM_EU_NCP (v4) | Nota |
|---|---|---|---|
| Font corpo | Georgia | Georgia | ✅ identico |
| Font heading | Arial | Arial | ✅ identico |
| Fill header | 800000 | 800000 (17×) | ✅ stesso colore, conteggio diverso per meno tabelle |
| vMerge | 0 | 0 | ✅ mai usato in nessuna famiglia |
| gridSpan | 135–207 | 171 | ✅ merge solo orizzontali |
| Appendici | FULL_A_I (9) | STANDARD_A_H (8) | ⚠️ differenza strutturale attesa dal router |
| Contaminazione footer | difetto noto in 505-Games (North America) | assente in Crosspolimeri | ✅ gold pulito |

Se output fingerprint drift > soglia: `BLOCK` o `REVIEW_CANDIDATE`, mai `FINAL`.

## 5. XML Node Cloning Workflow (invariato da v3)

```text
1. validate input package
2. build CASE_LOCK.json
3. select template via router
4. copy template into isolated workdir
5. unzip DOCX
6. compute template fingerprint
7. normalize split placeholders only where needed
8. replace scalar nodes
9. clone native rows/nodes for repeated tables
10. preserve w:tcPr, w:tblPr, w:gridSpan, w:vMerge, w:shd, w:borders
11. inject data
12. set updateFields on open
13. rezip DOCX
14. package validation
15. arithmetic validation
16. semantic consistency validation
17. full package contamination scan
18. visual/table fingerprint validation
19. council review
20. release state decision
```

### 5.1 Workflow vietato
- Generare da blank document.
- Ricreare manualmente tabelle complesse.
- "Pulire" una tabella nativa trasformandola in tabella semplice.
- Usare `python-docx` come editor principale per merged tables.
- Consegnare file intermedi chiamandoli "final".
- Scansionare solo `word/document.xml`.
- **v4: usare il gold SVC (FULL_A_I) per casi CM — violazione diretta del router.**

## 6. Regression Suite

Errori storici (v3, famiglia SVC/Quickfairs):

| Test ID | Classe | Pattern da bloccare | Severity |
|---|---|---|---:|
| REG-001 | old transaction | marketing and support sales services | CRITICAL |
| REG-002 | old sample count | 31 / 43 / 41 comparable companies | CRITICAL |
| REG-003 | old search total | 1,264 / 1,255 / 577 | CRITICAL |
| REG-004 | wrong NACE narrative | Computer programming / Advertising agencies / Public relations | CRITICAL |
| REG-005 | old years | 2023-2021 / 2021-2019 / 2020-2022 | CRITICAL |
| REG-006 | wrong thresholds | min=2,000, max=100,000 when CASE_LOCK says diverso | CRITICAL |
| REG-007 | hidden XML residue | forbidden tokens in footnotes/endnotes/comments/headers/footers | HIGH |
| REG-008 | table simplification | native Further Selection table replaced by simple 3-column table | HIGH |
| REG-009 | merged cell drift | gridSpan/vMerge count changed unexpectedly | HIGH |
| REG-010 | premature final | release_state=FINAL without all gates PASS | CRITICAL |

Nuovi test v4 (famiglia CM/Crosspolimeri):

| Test ID | Classe | Pattern da bloccare | Severity |
|---|---|---|---:|
| REG-011 | wrong family | Appendix I / Rejection Matrix come Appendice I in un caso CM | CRITICAL |
| REG-012 | old client leak | "Crosspolimeri" residuo in caso Amenduni | CRITICAL |
| REG-013 | old NACE leak | NACE 201/2016 (plastica) in un caso non-plastico | CRITICAL |
| REG-014 | old search totals | 316 / 255 / 15 residui da Crosspolimeri | CRITICAL |
| REG-015 | wrong appendix count | 9 appendici invece di 8 in un output CM_EU_NCP | CRITICAL |

## 7. Full Package Contamination Scan

```text
word/document.xml
word/header*.xml   (11 header trovati in Crosspolimeri: header1-11)
word/footer*.xml   (5 footer trovati in Crosspolimeri: footer1-5)
word/footnotes.xml
word/endnotes.xml
word/comments.xml
word/settings.xml
word/_rels/*.rels
customXml/*.xml, se presenti
```

### 7.1 Forbidden old values generator — CM_EU_NCP (Crosspolimeri)

```text
Crosspolimeri
Contract manufacturing of primary plastic materials
NACE 201
NACE 2016
316 potentially comparable
255 (post-quantitative)
15 comparable companies
2023-2021 (se periodo diverso per nuovo caso)
Release 179 - February 2025
```

## 8. Semantic Consistency Gate

```text
CASE_LOCK
vs Search table
vs Search narrative
vs Appendix D
vs Further Selection table
vs Executive Summary
vs Final Sample
vs Appendix F/G/H
```

Esempi di blocco specifici per CM:
- CASE_LOCK appendix_profile=STANDARD_A_H; documento contiene Appendix I → `BLOCK`.
- CASE_LOCK transaction=contract manufacturing; narrativa Search Process parla di NACE 73xx/82xx (servizi) → `BLOCK`.
- CASE_LOCK final_sample=N; corpo riporta 15 (valore Crosspolimeri non aggiornato) → `BLOCK`.

## 9. Arithmetic Gate

```python
def validate_case_lock(data):
    assert data["initial_population"] - data["quantitative_rejected"] == data["after_quantitative"]
    assert data["after_quantitative"] - data["qualitative_rejected"] == data["final_sample"]
    assert data["observation"] == data["final_sample"]
    assert data["min_pct"] <= data["q1_pct"] <= data["median_pct"] <= data["q3_pct"] <= data["max_pct"]
```

Verificato su Crosspolimeri (gold, non da riusare come dati Amenduni):
```text
316 - 61 = 255
255 - 240 = 15
observation = 15
5.29% <= 8.17% <= 10.41% <= 15.85% <= 40.72%
```

## 10. Release State Machine (invariata)

```text
WORKING_DRAFT
  ↓ package + arithmetic pass
REVIEW_CANDIDATE
  ↓ contamination + semantic + table fingerprint pass
STYLE_CANDIDATE
  ↓ visual/council pass
FINAL
```

## 11. QA JSON schema (invariato da v3)

## 12. HA / Resilience Controls (invariato da v3)

Copy-on-write, rollback, circuit breaker, observability — nessuna modifica in v4.

## 13. Smart Workaround Policy — aggiornamento v4

### Gold CM mancante (RISOLTO in v4)
- Cosa abbiamo fatto: identificato e misurato gold reale Crosspolimeri (contract manufacturing, plastica, Western Europe FY2023).
- Perché funziona: fingerprint XML misurato (non dichiarato) conferma STANDARD_A_H, stessi visual tokens della famiglia SVC (Georgia/Arial/800000), nessuna contaminazione footer.
- Limite: un solo gold per la famiglia CM — nessuna varianza campionaria su settori diversi da plastica.
- Rischio residuo: se Amenduni opera in un settore molto diverso (es. metalmeccanico vs plastica), la search narrative NACE dovrà essere riscritta ex novo, non solo i dati scalari.
- Evoluzione: raccogliere un secondo gold CM in altro settore per validare la stabilità del profilo STANDARD_A_H.

### Template close but not exact (invariato da v3)
- Default: `BLOCK`. Eccezione solo con waiver scritto del reviewer.

### Merged table extraction noisy (invariato da v3)

## 14. Machine Learning / Quality Learning Layer (invariato da v3)

## 15. Final Delivery Rule (invariata da v3)

```text
CASE_LOCK valid
Template router deterministic
DOCX package valid
XML injection completed
Arithmetic pass
Semantic consistency pass
Full package contamination scan pass
Table fingerprint pass
Appendix profile pass
Error Detective no unresolved CRITICAL/HIGH
Council does not BLOCK
QA score >= 99/100
```

## 16. One-line operating command

```text
Think first, lock the case, clone the template, inject only verified data, scan every XML part, block on any critical drift, then deliver only with QA evidence.
```
