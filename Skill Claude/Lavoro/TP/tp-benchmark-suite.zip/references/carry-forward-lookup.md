# Riferimento — Engine CARRY-FORWARD: Storico Screening Multi-Anno (v1.0)

> Riporta Causa di rigetto + Descrizione della Società (+ intero giudizio qualitativo: Matrice X, Esito, Codice, Cluster, Confidence, Website) da un foglio `Analisi` di un anno precedente già screenato, a un foglio `Analisi` dell'anno corrente, per le società già valutate in passato. Evita re-screening da zero (Fase 0–3 di `manual-review`) di comparabili ricorrenti anno su anno. Solo le società NON trovate nello storico vanno al motore `manual-review` completo.

## 0) Quando attivare
- L'utente carica DUE fogli/file: uno **storico** (anno N-1, N-2, …) con `Analisi` già compilato, e uno **corrente** (anno N) con `Analisi` da compilare, sulle stesse società (tipico: benchmark ricorrente, comparabili si ripetono per l'80-90%).
- Segnali: "anno precedente", "storico", "vecchio benchmark", "benchmark vecchio", "carry forward", "già screenato", "riporta causa/descrizione", "non rifare da zero", "vlookup causa", "vlookup descrizione", "popola da anno scorso".
- **Automatico o a richiesta** — due modalità:
  - **Automatica ("finisce tutto")**: l'utente carica il file corrente e indica il file storico → il carry-forward gira subito su tutte le righe matchabili, poi produce la lista delle non-matchate per `manual-review`.
  - **A richiesta (VLOOKUP puntuale)**: l'utente chiede solo il lookup di Causa/Descrizione per righe specifiche o per l'intero foglio, senza voler avviare automaticamente la review qualitativa sulle rimanenti.
- Se l'utente carica solo il file corrente ma nella stessa cartella esiste un file con naming coerente di anno precedente → **proporre** il carry-forward (una domanda) prima di avviare `manual-review` da zero. Non assumere in silenzio.

## Regole assolute (anti-bug)
- **R-CF1** Mai eseguire carry-forward senza identificare ESPLICITAMENTE file/foglio storico sorgente (nome file + anno). Se ambiguo → una domanda.
- **R-CF2** Match per **BvD ID** (chiave primaria, univoca) → fallback **Company Name normalizzato** (case-insensitive, spazi/punteggiatura compressi, suffissi societari rimossi: SpA/Srl/GmbH/Ltd/PLC/SA/NV/BV/Inc/LLC/AG/SAS/KG — stessa normalizzazione di `populate-standard`).
- **R-CF3** Non sovrascrivere MAI celle con formula nel foglio Analisi target (stesso principio trasversale della suite: non rompere Excel).
- **R-CF4** Non sovrascrivere celle target già valorizzate manualmente — scrivi SOLO se la cella target è vuota. Il giudizio dell'anno corrente, se già presente, prevale sempre sullo storico.
- **R-CF5** Ogni riga carry-forward riporta in colonna Fonte/Source: `Carry-forward <anno storico>` (mai "Web Review") — tracciabilità audit obbligatoria, sempre distinguibile da una review fatta ex-novo.
- **R-CF6** Se il dato storico è potenzialmente stale → applicare comunque il carry-forward ma marcare Detail/Note con un flag `[DA RE-VALIDARE: ...]` — non silenziare il segnale, non bloccare l'output. Tre trigger obbligatori: (a) Website storico diverso da quello nel target → `[DA RE-VALIDARE: possibile disallineamento website]`; (b) Esito storico = **Borderline** → **sempre** `[DA RE-VALIDARE: esito storico Borderline]`, indipendentemente da website/BvD/altro — un dubbio irrisolto (R7 di `manual-review`) non va perpetuato all'infinito anno su anno senza essere mai ri-esaminato; (c) NACE storico diverso dal NACE corrente (confronto sul codice numerico, letto come input, mai scritto) → `[DA RE-VALIDARE: NACE storico diverso dal corrente]` — un cambio di classificazione (es. da produttore/toll manufacturer a distributore) implica un profilo funzionale diverso: il giudizio storico (Esito/Causa/Descrizione) può non valere più.
- **R-CF7** Società NON trovate nello storico (0 match, né BvD né Nome) → SEMPRE verso `manual-review` completo (Fase 0–3): mai lasciare Causa/Descrizione vuote per "non trovato".
- **R-CF8** Riepilogo finale obbligatorio: righe target totali, matchate per BvD, matchate per Nome, non matchate, celle scritte, celle saltate (formula, già valorizzata, o merged), righe marcate "da re-validare", BvD ID duplicati nello storico (se presenti).
- **R-CF9** BvD ID duplicato nello storico (stesso ID su ≥2 righe distinte) è **ambiguo**: mai risolvere prendendo "l'ultima riga vince" (rischio concreto di attribuire il giudizio qualitativo di una società a un'altra società). Il BvD duplicato viene escluso dal lookup per BvD; la riga resta risolvibile solo via Company Name normalizzato, altrimenti finisce in unmatched → `manual-review`. Segnalare sempre i BvD duplicati nel riepilogo.
- **R-CF10** Match esatto sull'header prima del match per sottostringa (es. colonna "Codice" vs "Codice Fiscale"/"Codice ATECO"): una keyword generica come "codice" o "note" può collidere con una colonna omonima non correlata già presente nel foglio (dati anagrafici, codice fiscale, note legali) — se esiste un header che corrisponde esattamente alla keyword normalizzata, usare quello; il match per sottostringa è solo un fallback quando non c'è corrispondenza esatta.
- **R-CF11** Celle unite (merged) nel foglio Analisi target NON vanno mai scritte direttamente: scrivere su una cella non-anchor di un merge fa crashare l'intero script (AttributeError, nessun file salvato). Le celle merged vengono sempre saltate con contatore dedicato e segnalate nel riepilogo per verifica manuale — mai un unmerge automatico silenzioso, che altererebbe il layout del template senza preavviso.
- **R-CF12** File `.xlsm` (macro-enabled): il caricamento DEVE usare `keep_vba=True`, altrimenti il progetto VBA (macro, pulsanti, validazioni) viene scartato in silenzio al salvataggio anche se il file di partenza le conteneva. Il nome di output di default deve mantenere l'estensione originale del file corrente (`.xlsx` resta `.xlsx`, `.xlsm` resta `.xlsm`) — mai forzare `.xlsx` su un file macro-enabled.

- **R-CF13** Il rilevamento della riga header pesa prima sulla presenza di keyword note (Company Name, BvD ID, NACE, Esito, Causa, Descrizione, Cluster, Confidence, Fonte, Website, ...) e solo a parità di keyword-hit sul conteggio di celle di testo. Una riga puramente decorativa (titolo report, watermark "Bozza/Riservato", numero pagina) sopra l'header reale non contiene di norma nessuna di queste keyword e quindi non vince più per il solo conteggio di celle. Stesso fix applicato a `populate-standard` (`confronto_analisi.py`), che condivide l'identica euristica; `populate-financial` non è interessato perché usa `--header-idx` esplicito da riga di comando, non auto-detect.

## Fase 1 — Identificazione file e fogli
- **Step 1** Individua file storico (sorgente, sola lettura) e file corrente (target, letto e riscritto). Se l'utente ha nominato solo "il vecchio" e "il nuovo" senza specificare l'anno storico → chiedilo (serve per l'etichetta Fonte, R-CF5).
- **Step 2** Localizza il foglio `Analisi` in entrambi i file con la stessa euristica smart-mapping di `manual-review.md` (scan prime 20 righe per header chiave, fuzzy match case-insensitive).
- **Step 3** Non modificare mai il file storico: è sempre e solo sorgente in lettura.

## Fase 2 — Join e carry-forward
- **Step 4** Costruisci lookup storico: `by_bvd[BvD ID normalizzato] → riga`, `by_name[norm_key(Company Name)] → riga`.
- **Step 5** Per ogni riga del foglio Analisi target: prova match su BvD ID → se assente/non trovato, match su Company Name normalizzato → altrimenti riga "unmatched".
- **Step 6** Se match trovato, copia (solo se cella target vuota e non-formula) le colonne qualitative condivise: Matrice X (A Non-independent · B Trademarks/patents/intangibles · C Different functions · D Additional functions · E Different products/services · F Additional products/services · G Non-comparable sector · H Other); Esito; Codice; **Causa**; **Descrizione**; Cluster; Confidence; Website; Detail. Scrivi Fonte = `Carry-forward <anno storico>`.
- **Step 7** Applica il controllo di freschezza (R-CF6): se Website storico e Website target sono entrambi presenti e diversi dopo normalizzazione → append a Detail `[DA RE-VALIDARE: possibile disallineamento website]`.
- **Step 8** Le righe unmatched NON vengono toccate: finiscono nell'Output C per `manual-review`.

## Fase 3 — Output e riepilogo
- **Output A**: file target aggiornato (in-place se l'utente lo richiede esplicitamente, altrimenti `<nome>_Analisi_CarryForward.xlsx` di default — non sovrascrivere mai il file originale senza conferma).
- **Output B**: report console — righe target totali; matchate per BvD; matchate per Nome; unmatched (elenco nomi); celle scritte; celle saltate (formula / già valorizzata); righe "da re-validare".
- **Output C**: lista "Nuove società da screenare" (le unmatched), pronta come input per `manual-review` (Fase 0–3 completa — non skip, non lasciare vuoto).

## Appendice — Colonne e compatibilità `Analisi`
- **Legge (storico)**: Company name; BvD ID; Matrice X (A–H); Esito; Codice; Causa; Descrizione; Cluster; Confidence; Fonte; Website; Detail.
- **Scrive (target)**: le stesse colonne, solo se vuote e non-formula; Fonte sempre impostata a `Carry-forward <anno>` quando la riga proviene da carry-forward (mai lasciata come "Web Review" o intestazione preesistente ambigua).
- **Non tocca**: colonne finanziarie/quantitative del foglio Analisi (dominio di `populate-standard` / `populate-financial`), che restano gestite dai rispettivi engine.
- **Sequenza consigliata su uno stesso file multi-anno**: (1) `populate-standard` o `populate-financial` per i dati quantitativi dal foglio Results/Bond Results dell'anno corrente; (2) `carry-forward-lookup` per il giudizio qualitativo storico (Causa/Descrizione/Esito/…) sulle società ricorrenti; (3) `manual-review` (Fase 0–3) solo sui residui unmatched, cioè le società realmente nuove. I tre engine sono complementari, non alternativi.
- **Validazione coerenza** (ereditata da `manual-review`): nessuna riga "Accettata" può avere X; ogni "Rigettata" deve avere ≥1 X e Causa non vuota; "Altro" richiede Detail. Il carry-forward non introduce mai una riga incoerente perché copia blocchi interi già validati nell'anno storico.
