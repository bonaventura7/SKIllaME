# Riferimento — Engine FINANCIAL (populate-financial)

> Popola `Analisi Long` da export finanziario/bond usando `Bond ISIN` come chiave di join, **preservando le formule** del foglio Analisi. Attivare per export finanziario/bond, Moody/Modis/EDFX, segnali ISIN/coupon.
> Script: `scripts/populate_analisi_long.py`.

## Scopo
Automatizzare il popolamento del foglio `Analisi`/`Analisi Long` partendo da `Bond Results`, preservando le formule esistenti e mappando correttamente le colonne.

## Procedura operativa
1. Validare presenza fogli e intestazioni.
2. Identificare la riga header e mappare le colonne per pattern.
3. Allineare le righe per **Bond ISIN**.
4. Popolare solo le colonne di input e sintesi.
5. Preservare le formule nelle colonne calcolate.
6. Eseguire controlli di coerenza (mismatch, colonne vuote, formati).

## Regole di compilazione
- Non sovrascrivere formule nel foglio `Analisi`.
- Convertire "n.a." in celle vuote.
- Normalizzare i valori percentuali in numeri.
- Evidenziare i flag NACE per review manuale.

## Mapping colonne Bond Results → Analisi Long (OBBLIGATORIO)
Popolare sempre da Bond Results usando il Bond ISIN come chiave di join:

| Colonna Analisi Long | Indice AL (0-based) | Fonte Bond Results | Indice BR (0-based) |
|---|---|---|---|
| Final Coupon Date | 22 | Final Coupon Date | 32 |
| Price Date | 23 | Price Date | 33 |
| Coupon Type (col 41) | 41 | Coupon Type | 23 |
| Valuta (col 42) | 42 | Bond Currency | 20 |

> ⚠️ **Final Coupon Date e Price Date sono obbligatorie**: sempre popolate. Se un ISIN non ha corrispondenza in Bond Results, segnalarlo nel log finale.

## Formattazione date — REGOLA OBBLIGATORIA
Tutte le date da Bond Results o da qualsiasi fonte `.xlsb` **devono** essere scritte come oggetti `datetime` Python con `number_format = 'DD/MM/YYYY'` (es. `05/06/2115`).
- ❌ Mai stringhe ISO come `2025-03-31T00:00:00.000Z` nelle celle.
- ❌ Mai interi serial Excel senza `number_format` corretto.
- ✅ Sempre oggetti `datetime` con `cell.number_format = 'DD/MM/YYYY'`.

Funzione `parse_date` (usare SEMPRE per qualsiasi valore data — serial xlsb: `datetime(1899, 12, 30) + timedelta(days=int(val))`):
```python
from datetime import datetime, timedelta

def parse_date(val):
    """Converte ISO string o serial Excel in oggetto datetime."""
    if val is None:
        return None
    if isinstance(val, str) and 'T' in val:
        try:
            return datetime.strptime(val[:10], '%Y-%m-%d')
        except ValueError:
            return None
    if isinstance(val, (int, float)) and val > 30000:
        return datetime(1899, 12, 30) + timedelta(days=int(val))
    if isinstance(val, datetime):
        return val
    return None
```

Rilevamento automatico colonne data: applicare `parse_date` + `number_format = 'DD/MM/YYYY'` a tutte le colonne il cui header contiene "date" (case-insensitive), aggiungendo sempre esplicitamente gli indici critici 22 e 23.

## Verifica finale obbligatoria (dopo il salvataggio)
```python
import openpyxl
wb_v = openpyxl.load_workbook(OUTPUT_FILE)
ws_v = wb_v.active
total = sum(1 for r in range(5, ws_v.max_row+1) if ws_v.cell(row=r, column=1).value)
for col_name, col_idx in [('Final Coupon Date', 23), ('Price Date', 24), ('Coupon Type', 42), ('Valuta', 43)]:
    filled = sum(1 for r in range(5, ws_v.max_row+1) if ws_v.cell(row=r, column=1).value and ws_v.cell(row=r, column=col_idx).value)
    print(f"{col_name}: {filled}/{total}")
```

## Gestione errori e bug check (Fase 4)
- ISIN in Analisi Long non trovato in Bond Results → segnalare nel log.
- Formato numerico non coerente (testo vs numero).
- Date scritte come stringhe ISO o interi → usare sempre `parse_date`.

## Output atteso
- File `_Analisi_Long_Popolato.xlsx` con dati inseriti e date in formato `DD/MM/YYYY`.
- Riepilogo colonne popolate e ISIN non matchati stampato a console.

---

## `[FLAG]` Preservazione formule — caveat tecnico
Il template fornito ricostruisce un workbook **nuovo** (`openpyxl.Workbook()`) a partire dalle righe lette: questo **non preserva** formule, stili e altri fogli dell'`Analisi Long` originale, in contrasto con la regola «non sovrascrivere formule». Lo script `scripts/populate_analisi_long.py` espone due modalità via `--mode`:

- **`--mode rebuild`** (default): fedele al comportamento originale, ricostruisce il workbook da zero (ideale per `.xlsb`).
- **`--mode preserve`**: quando il file di input è `.xlsx`, **carica il workbook esistente con openpyxl e scrive solo nelle celle target**, lasciando intatte le colonne con formula.

Usare `--mode preserve` quando l'input è un `.xlsx` con formule da conservare; usare `--mode rebuild` (default) quando si parte da sorgenti `.xlsb` o quando la fedeltà al template è prioritaria. Decisione rimessa all'utente: nessuna logica approvata è stata alterata.

**Esempio:**
```bash
python scripts/populate_analisi_long.py --input bond_results.xlsb --mode rebuild
python scripts/populate_analisi_long.py --input analisi_long.xlsx --mode preserve
```
