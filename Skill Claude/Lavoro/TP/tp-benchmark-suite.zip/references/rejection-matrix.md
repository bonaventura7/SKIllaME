# Riferimento — Engine REJECTION-MATRIX: Matrice di Rigetto (v1.0)

> Genera/aggiorna il foglio `Rejection Matrix` a partire dalle colonne categoriche granulari del foglio `Analisi` (Società non indipendente, Società non finalizzata al profitto, Marchi/brevetti/intangibili, Funzioni diverse, Funzioni ulteriori, Prodotti diversi, Prodotti ulteriori, Altro) e dal `Risultato Finale`, consolidando le 8 categorie granulari nelle 5 colonne standard: Different Functions, Additional Functions, Different Products, Additional Products, Other Reasons. Mapping verificato contro template reale di produzione.
> Script: `scripts/rejection_matrix.py`.

## 0) Quando attivare
- L'utente chiede di generare, popolare o aggiornare il foglio "Rejection Matrix" / "matrice di rigetto" / "reject matrix".
- Segnali: "rejection matrix", "matrice di rigetto", "matrice esclusioni per categoria", "riepilogo cause di rigetto", "quante rigettate per prodotti diversi/funzioni diverse".
- Tipicamente attivato DOPO che il foglio `Analisi` è completo (screening qualitativo concluso, colonne granulari e Risultato Finale valorizzati) — via `manual-review` e/o `carry-forward-lookup`.
- Se l'utente chiede solo "quante rigettate per categoria X" senza voler scrivere un foglio → rispondere con il conteggio (Fase 3, Output B) senza necessariamente salvare un file.

## Struttura osservata (template reale)
Il foglio `Rejection Matrix` reale ha un layout a 2 livelli di header:
```
riga titolo:      (vuota o "Reject Matrix of the Comparable Companies")
riga categorie:   [ ... ] Different Functions | Additional Functions | Different Products | Additional Products | Other Reasons
riga header dati: N. | Company Name | BvD ID number
righe dati:       1  | Alpha SpA    | BVD001        |    |    | X  |    |
```
Include **tutte** le società di `Analisi` (accettate comprese), non solo le rigettate: il rigetto è evidenziato per eccezione tramite le X, le accettate restano con le 5 colonne bucket vuote.

## Regole assolute (anti-bug)

- **R-RJ1** Il foglio Rejection Matrix elenca SEMPRE tutte le società del foglio Analisi sorgente (accettate incluse, senza X) — non solo le rigettate. Rispecchia il template reale: ogni comparabile valutato appare in riga.
- **R-RJ2** Una società riceve X in almeno un bucket SOLO SE `Risultato Finale` (o "Final Result") normalizza a un valore di rigetto (RIFIUTATA / RIGETTATA / REJECTED). Accettata, Borderline o vuoto → nessuna X, mai un rigetto dedotto per default. Borderline non è un rigetto definitivo: trattarlo come rigetto scriverebbe una X non giustificata; lasciarlo vuoto e segnalarlo altrove è compito di `manual-review`/`carry-forward-lookup`, non di questo engine.
- **R-RJ3** Mapping N:1 dalle colonne granulari di Analisi ai 5 bucket standard (verificato su dati reali):
  | Colonna Analisi (granulare) | Bucket Rejection Matrix |
  |---|---|
  | Funzioni diverse | Different Functions |
  | Funzioni ulteriori | Additional Functions |
  | Prodotti diversi | Different Products |
  | Prodotti ulteriori | Additional Products |
  | Società non indipendente | Other Reasons |
  | Società non finalizzata al profitto | Other Reasons |
  | Marchi, brevetti e altri intangibili | Other Reasons |
  | Altro | Other Reasons |

  "Other Reasons" è un OR logico su 4 colonne sorgente: X se **almeno una** delle 4 è marcata.
- **R-RJ4** Una società rigettata può attivare **più bucket contemporaneamente** se più colonne granulari sono marcate (es. sia "Funzioni ulteriori" sia "Società non indipendente"): scrivere X in TUTTI i bucket applicabili — la Rejection Matrix è un cross-tab, non un campo a scelta singola. Non troncare al primo match.
- **R-RJ5** Non sovrascrivere MAI celle con formula, né celle target già valorizzate (stesso principio trasversale della suite). Se una X è già presente manualmente, non toccarla né duplicarla.
- **R-RJ6** Celle unite (merged) nel foglio target NON vanno mai scritte direttamente: stessa protezione anti-crash di `carry-forward-lookup` (R-CF11) — scrivere su una MergedCell non-anchor solleva AttributeError. Saltare con contatore dedicato, mai un unmerge automatico.
- **R-RJ7** Match riga per **BvD ID** (chiave primaria) → fallback **Company Name normalizzato** (stessa normalizzazione — case-insensitive, accenti rimossi, suffissi societari stripped — di `carry-forward-lookup` R-CF2).
- **R-RJ8** Società presenti in Analisi ma assenti da un template Rejection Matrix esistente (`--target`) vengono SEMPRE aggiunte in coda (mai scartate in silenzio), continuando la numerazione `N.` se presente. Segnalare sempre nel riepilogo quante sono state aggiunte.
- **R-RJ9** Sorgente `.xlsb` è sempre sola lettura (via `pyxlsb`, stesso pattern di `populate-financial`). Se non viene fornito `--target`, l'output è sempre un nuovo `.xlsx` costruito da zero (openpyxl non può scrivere `.xlsb`). Se `--target` è fornito, deve essere `.xlsx`/`.xlsm` (necessario per preservare formule ed editare in place).
- **R-RJ10** Rilevamento header: stessa euristica keyword-aware del fix v1.1.3 (bug #7) — pesa prima sulla presenza di keyword note, poi sul conteggio celle di testo, per evitare falsi positivi su righe titolo decorative.
- **R-RJ11** Normalizzazione header con strip degli accenti (es. "Società" → "societa") prima del match per keyword — bug reale riscontrato su file di produzione: header con lettere accentate italiane ("Società non indipendente") non matchavano keyword ASCII senza questo fix. Applicato anche a `carry-forward-lookup` e `populate-standard` (stessa funzione `norm()` condivisa concettualmente).

## Fase 1 — Identificazione file e fogli
- **Step 1** Individua il file sorgente con il foglio `Analisi` completo (screening concluso). Sola lettura.
- **Step 2** Se l'utente fornisce anche un file `--target` con un foglio `Rejection Matrix` già impostato (anche vuoto, solo header) → modalità "riempi template esistente" (preferita: preserva formattazione, larghezze colonna, eventuali formule di conteggio). Altrimenti → modalità "crea foglio da zero" nel file di output.
- **Step 3** Localizza il foglio Analisi (`find_sheet` su "analisi") e, se target fornito, il foglio Rejection Matrix (`find_sheet` su "rejection matrix").

## Fase 2 — Estrazione e consolidamento
- **Step 4** Per ogni riga di Analisi: leggi BvD ID, Company Name, `Risultato Finale`, e le 8 colonne granulari.
- **Step 5** Determina `rejected = norm(Risultato Finale) in {rifiutata, rigettata, rejected, ...}`.
- **Step 6** Se rigettata, determina l'insieme di bucket attivati secondo il mapping R-RJ3 (può essere >1, R-RJ4).
- **Step 7** Se `--target` fornito: matcha ogni società per BvD ID → fallback Nome (R-RJ7); scrivi X solo nelle celle blank e non-locked (R-RJ5, R-RJ6); appendi le società non trovate (R-RJ8). Se `--target` assente: costruisci il foglio da zero replicando la struttura reale (titolo, riga categorie, riga header dati, una riga per società in ordine di apparizione in Analisi).

## Fase 3 — Output e riepilogo
- **Output A**: file con foglio Rejection Matrix compilato/aggiornato (`--in-place` se richiesto esplicitamente, altrimenti `<nome>_RejectionMatrix.xlsx` di default).
- **Output B**: riepilogo console — società totali, rigettate, accettate, distribuzione per bucket (5 conteggi), celle X scritte, celle saltate per lock (formula/merged), società aggiunte in coda (se target parziale).
- **Nessun output silenzioso**: colonne categoriche non trovate in Analisi, bucket non trovati nel target, o società non matchate vengono sempre segnalate con `[ATTENZIONE]`, mai ignorate senza traccia.

## Appendice — Colonne e compatibilità `Analisi`
- **Legge (sorgente Analisi)**: Company Name; BvD ID number; Risultato Finale (o Final Result); Società non indipendente; Società non finalizzata al profitto; Marchi/brevetti/intangibili; Funzioni diverse; Funzioni ulteriori; Prodotti diversi; Prodotti ulteriori; Altro.
- **Scrive (target Rejection Matrix)**: N. (se assente e riga aggiunta), Company Name, BvD ID number (per righe aggiunte), Different Functions, Additional Functions, Different Products, Additional Products, Other Reasons (X dove applicabile).
- **Non tocca**: Causa di rigetto / Descrizione della Società / Codice rigetto (dominio di `manual-review` e `carry-forward-lookup`) — questo engine legge solo le colonne booleane granulari e il Risultato Finale, non i campi testuali di dettaglio.
- **Sequenza consigliata su uno stesso file**: (1) `manual-review` e/o `carry-forward-lookup` completano `Analisi` (colonne granulari + Risultato Finale); (2) `rejection-matrix` genera/aggiorna la vista di sintesi per categoria. L'ordine inverso non ha senso: senza Analisi completo non c'è nulla da consolidare.
