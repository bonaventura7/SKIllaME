# Riferimento — Engine STANDARD (populate-standard)

> Mappa e inserisce i dati di Screening Results nel foglio `Analisi`, **preservando tutte le formule esistenti**. Attivare quando l'utente chiede di popolare automaticamente `Analisi` o di rivedere/configurare le regole di mapping source→target.
> Script: `scripts/confronto_analisi.py`.

## Scopo
Automatizzare il popolamento del foglio `Analisi` partendo dal foglio `Results/Risultati` generato dallo screening, preservando le formule esistenti e mappando correttamente le colonne.

## Quando attivare
- Popolare automaticamente il foglio `Analisi`.
- Mappare colonne tra `Results` e `Analisi`.
- Preservare formule e gestire controlli di coerenza.

## Input richiesti (sempre)
1. **Triennio** da elaborare (es. 2021 2022 2023).
2. **Indicatore finanziario principale** da calcolare o verificare.
3. **File Excel sorgente** e fogli corretti (`Results/Risultati` e `Analisi`).

## Procedura operativa
1. Validare presenza fogli e intestazioni.
2. Identificare la riga header e mappare le colonne per pattern.
3. Allineare le righe per `Company Name` o `BvD ID`.
4. Popolare **solo** le colonne di input e di sintesi.
5. **Preservare le formule** nelle colonne calcolate.
6. Eseguire controlli di coerenza (mismatch, anni mancanti, formati).

## Regole di compilazione
- Non sovrascrivere formule nel foglio `Analisi`.
- Convertire "n.a." in celle vuote.
- Normalizzare i valori percentuali in numeri.
- Evidenziare i flag NACE per review manuale.

## Gestione errori e bug check (Fase 4)
- Mismatch nomi società tra `Results` e `Analisi`.
- Formato numerico non coerente (testo vs numero).
- Anni mancanti o non allineati al triennio richiesto.

## Implementazione tecnica
```bash
python scripts/confronto_analisi.py --input "C:\path\to\file.xlsx" --years 2021 2022 2023
```
Lo script: popola i campi di sintesi e i dati annuali disponibili; preserva le formule; aggiunge `Data Update` e `Source` se le colonne sono presenti; riporta mismatch e anni mancanti a fine esecuzione.

> Nota: il corpo di `confronto_analisi.py` **non era fornito** nel materiale sorgente. Lo script incluso è **ricostruito dalla specifica** sopra; verificarlo contro l'eventuale originale aziendale prima dell'uso in produzione. Vedi l'header dello script.

## Output atteso
- File `_Analisi_Popolato.xlsx` con dati inseriti e formule intatte.
- Riepilogo mismatch e anni mancanti stampato a console.
