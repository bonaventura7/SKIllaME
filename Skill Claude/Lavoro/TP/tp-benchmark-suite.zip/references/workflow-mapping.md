# Riferimento — File / Workflow Mapping

> Attivare quando l'utente chiede di mappare una cartella o un insieme di file TP (mappa file, knowledge map, relazioni, workflow, grafo). Produrre quattro deliverable: `INVENTORY.md`, `MAP.md`, `GRAPH.md`, `QUALITY_REPORT.md`.

## INVENTORY.md — deve includere
path · nome file · estensione · categoria · ruolo operativo · source rilevata · target rilevato · join key · trigger rilevati · confidence.

## MAP.md — deve includere
executive summary · workflow rilevati · agenti disponibili · relazioni · ambiguità · raccomandazioni.

## QUALITY_REPORT.md — deve includere
classificazione scelta · confidence · segnali trovati · segnali mancanti · eventuale ambiguità · agente attivato · motivazione · rischi residui · fallback applicato.

## GRAPH.md — Mermaid graph
```mermaid
graph TD
    ROUTER["tp-benchmark-suite (router)"]

    STD_SRC["TP Catalyst / Results-Risultati"]
    STD_AGENT["populate-standard"]
    ANALISI["Excel Analisi"]

    FIN_SRC["Bond Results / EDFX / Modis / Moody"]
    FIN_AGENT["populate-financial"]
    ANALISI_LONG["Excel Analisi Long"]

    MANUAL_EXCEL["Excel Analisi manuale/precompilato"]
    REVIEW["manual-review"]
    FINAL["Benchmark finale"]

    ROUTER -->|standard export| STD_AGENT
    ROUTER -->|financial/bond export| FIN_AGENT
    ROUTER -->|qualitative review| REVIEW

    STD_SRC --> STD_AGENT
    STD_AGENT --> ANALISI
    ANALISI --> REVIEW
    MANUAL_EXCEL --> REVIEW
    REVIEW --> FINAL

    FIN_SRC --> FIN_AGENT
    FIN_AGENT --> ANALISI_LONG

    STD_AGENT -.->|OPTIONAL_UPSTREAM| REVIEW
    STD_AGENT -.->|FAMILY only| FIN_AGENT
```

## Relazioni tra engine

| Source | Relazione | Target | Confidence | Note |
|---|---|---|---:|---|
| `populate-standard` | OPTIONAL_UPSTREAM | `manual-review` | 0.80 | Prepara Analisi, ma Manual Review può partire anche da Excel manuale |
| `excel-manuale` | ALTERNATIVE_UPSTREAM | `manual-review` | 0.90 | Input valido per review qualitativa |
| `populate-standard` | FAMILY | `populate-financial` | 0.70 | Stessa famiglia concettuale di mapping Excel |
| `populate-financial` | SEPARATE_AGENT | `populate-standard` | 0.95 | Source, target e join key diversi |
| `tp-benchmark-suite` | ROUTES_TO | `populate-standard` | 0.90 | Se rileva Results/Risultati/TP Catalyst |
| `tp-benchmark-suite` | ROUTES_TO | `populate-financial` | 0.95 | Se rileva Bond Results/ISIN/Analisi Long |
| `tp-benchmark-suite` | ROUTES_TO | `manual-review` | 0.90 | Se richiesta review qualitativa |

## Workflow principali

```text
Standard:   TP Catalyst / Results-Risultati -> populate-standard -> Excel Analisi -> manual-review -> Accepted/Rejected/Borderline
Manuale:    Excel Analisi precompilato/manuale -> manual-review -> Benchmark finale qualitativo
Financial:  Bond Results / EDFX / Modis / Moody -> populate-financial -> Excel Analisi Long
```

> Regola di mapping: non collegare i file per solo overlap di keyword. Usare ruoli operativi, source, target, join key, quality gate e workflow.
