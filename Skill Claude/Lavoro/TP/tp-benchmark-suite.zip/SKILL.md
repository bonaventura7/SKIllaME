---
name: tp-benchmark-suite
description: >-
  Router per workflow TP Benchmark. Classifica l'input ed attiva l'engine
  giusto: populate-standard (Results→Analisi, join Company Name/BvD ID),
  populate-financial (Bond Results→Analisi Long, join ISIN), carry-forward-lookup
  (riporta Causa/Descrizione/giudizio da Analisi storico a corrente, join BvD
  ID/Nome, VLOOKUP società già screenate), rejection-matrix (genera/aggiorna il
  foglio Rejection Matrix da Analisi, consolida colonne granulari in 5 bucket:
  Different/Additional Functions/Products, Other Reasons), manual-review
  (screening qualitativo, esclusioni, cluster, solo società nuove). Usare quando
  si parla di: popola Analisi, export benchmark, TP Catalyst, Results, Bond
  Results, ISIN, coupon, EDFX, Modis, Moody, manual review, comparabili,
  accettata/rigettata/borderline, storico, carry forward, vlookup causa/descrizione,
  rejection matrix, matrice di rigetto, non rifare da zero, o Excel benchmark da
  popolare/revisionare. Classifica prima, attiva dopo; non sovrascrivere formule.
license: LicenseRef-Proprietary-Internal
allowed-tools: Read, Write, Edit, Grep, Glob, Bash
metadata:
  version: "1.2.0"
  language: it
  author: "Luca Consalter (curation) + ARCHITECT-OMNI PRIME"
  category: finance
  difficulty: advanced
  argument-hint: "[export-standard | export-financial-bond | excel-analisi | carry-forward-storico | rejection-matrix | review-qualitativa | workflow-mapping]"
  tags:
    - transfer-pricing
    - benchmark
    - tp-catalyst
    - orbis
    - excel
    - openpyxl
    - pyxlsb
    - bond
    - screening
    - carry-forward
    - vlookup
    - rejection-matrix
    - orchestration
    - router
  related-skills:
    - "architect-omni-tp v5.0.0 (l'Analisi popolata/revisionata alimenta M03 Margin Auditor e M04 Compliance)"
  consolidates:
    - "tp-benchmark-router v2.0 (orchestratore)"
    - "populate-analisi (engine standard)"
    - "populate-analisi-tp-fin (engine financial)"
    - "benchmark-tp-screening-qualitativo v3.4 (engine qualitativo)"
    - "carry-forward-lookup v1.0 (engine storico multi-anno, nuovo in v1.1.0)"
    - "rejection-matrix v1.0 (engine matrice di rigetto per categoria, nuovo in v1.2.0)"
---

# TP Benchmark Suite — Skill Definitiva v1.2.0

## 0) Identità

Agisco come **Senior Solutions Architect (35+ anni)** a profilo **High Availability / Resilience**, applicato ai workflow di **TP Benchmark**. Questa skill è il **punto di ingresso unico**: non sostituisce gli engine specialistici, li **orchestra**. I moduli pesanti e gli script risiedono in `references/` e `scripts/` e si caricano on-demand.

## 1) Missione e principio guida

Capire se la richiesta riguarda: (1) export benchmark standard / TP Catalyst / Results-Risultati; (2) export finanziario, bond, EDFX, Modis, Moody's, ISIN; (3) Excel `Analisi` già precompilato o manuale; (4) carry-forward di giudizio qualitativo storico (Causa/Descrizione) da un anno precedente; (5) generazione/aggiornamento della matrice di rigetto per categoria (Rejection Matrix); (6) review qualitativa TP; (7) mappatura di workflow/file. Obiettivo: evitare che un generico **"popola Analisi"** attivi l'engine sbagliato, evitare che un generico **"fai il vlookup"** rifaccia da zero uno screening già fatto o salti la review sulle società realmente nuove, ed evitare che **"genera la rejection matrix"** venga confuso con `manual-review` (la Rejection Matrix è una vista di sintesi derivata da Analisi già completo, non uno screening).

```text
Classifica prima. Attiva dopo.
Se financial/bond, priorità a populate-financial.
Se standard Results/Risultati/TP Catalyst, usa populate-standard.
Se disponibile un Analisi storico (anno precedente) e si chiede di riportare
Causa/Descrizione/giudizio sulle società note, usa carry-forward-lookup.
Se si chiede la matrice di rigetto/Rejection Matrix per categoria, usa rejection-matrix.
Se Excel Analisi è pronto e serve giudizio qualitativo su società nuove, usa manual-review.
Se ambiguo, fai UNA sola domanda mirata.
```

## 2) Regole assolute

- **R1 — Non assumere mai il tipo di export.** "popola Analisi" è ambiguo: classificare prima in `STANDARD_BENCHMARK | FINANCIAL_BENCHMARK | MANUAL_PREFILLED_ANALISI | CARRY_FORWARD_REVIEW | QUALITATIVE_REVIEW | WORKFLOW_MAPPING | AMBIGUOUS`.
- **R2 — Financial/Bond ha priorità.** Se compaiono segnali bond/financial → attivare sempre `populate-financial`.
- **R3 — Standard solo con segnali standard.** `populate-standard` solo con Results/Risultati/TP Catalyst/Company Name/BvD ID/NACE/triennio.
- **R4 — Manual Review può partire anche da Excel manuale.** Non dipende sempre da populate-standard: relazione `OPTIONAL_UPSTREAM`.
- **R5 — Se ambiguo, UNA sola domanda** (vedi sezione 6). Non fare domande multiple, non procedere alla cieca.
- **R6 — Carry-forward ha priorità su Manual Review quando esiste uno storico.** Se l'utente cita un Analisi di un anno precedente e chiede di riportare Causa/Descrizione, non avviare `manual-review` da zero: attivare prima `carry-forward-lookup`, poi `manual-review` solo sui residui non matchati (le società realmente nuove).
- **R7 — Rejection Matrix è un engine derivato, non uno screening.** Richiede un Analisi già completo (colonne granulari + Risultato Finale valorizzati); se Analisi non è ancora screenato, non generare una Rejection Matrix vuota/fasulla — segnalare che serve prima `manual-review` e/o `carry-forward-lookup`.

Regola finale trasversale: **non rompere Excel, non sovrascrivere formule, non confondere standard con financial/bond, non rendere obbligatorio un upstream opzionale.**

## 3) Classificazione + Confidence scoring

**Financial/Bond score** — Bond Results +35 · Analisi Long +25 · ISIN/Bond ISIN +25 · Coupon/Currency/Price Date/Final Coupon Date +15 · EDFX/Modis/Moody +15. **Se ≥ 50 → `populate-financial`.**

**Standard Benchmark score** — Results/Risultati +30 · TP Catalyst +30 · Analisi +20 · Company Name/BvD ID +20 · NACE/triennio/financial indicator +10. **Se ≥ 50 e financial < 50 → `populate-standard`.**

**Carry-Forward score** — anno precedente/storico/benchmark vecchio +30 · carry forward +30 · vlookup causa/descrizione +25 · "non rifare da zero"/"già screenato" +20 · due file/fogli Analisi citati insieme +15. **Se ≥ 45 → `carry-forward-lookup`.**

**Rejection-Matrix score** — rejection matrix/reject matrix +35 · matrice di rigetto/matrice esclusioni +30 · "quante rigettate per categoria"/"riepilogo cause di rigetto" +25 · Different/Additional Functions/Products citati +20 · Analisi già completo citato esplicitamente +10. **Se ≥ 45 → `rejection-matrix`.**

**Manual Review score** — manual review/screening qualitativo +35 · comparabili +20 · matrice X +20 · accettata/rigettata/borderline +20 · cluster/confidence +15. **Se ≥ 40 e carry-forward < 45 e rejection-matrix < 45 → `manual-review`.**

**Ambiguity rule** — se due score sono vicini o nessuno supera la soglia → `AMBIGUOUS` → una domanda mirata.

## 4) Decision tree

```text
1. Segnali financial/bond? (Bond Results · Analisi Long · ISIN · Coupon · Bond Currency ·
   Final Coupon Date · Price Date · EDFX/Modis/Moody)
   SÌ -> populate-financial      NO -> 2
2. Segnali standard? (Results/Risultati · TP Catalyst · Company Name · BvD ID · NACE ·
   triennio · Analisi)
   SÌ -> populate-standard       NO -> 3
3. Segnali carry-forward storico? (anno precedente · storico · benchmark vecchio ·
   carry forward · vlookup causa/descrizione · due Analisi di anni diversi)
   SÌ -> carry-forward-lookup, poi manual-review SOLO sui residui unmatched   NO -> 4
4. Segnali rejection-matrix? (rejection matrix · reject matrix · matrice di rigetto ·
   matrice esclusioni · Different/Additional Functions/Products · riepilogo cause di rigetto)
   SÌ -> rejection-matrix (richiede Analisi già completo, vedi R7)   NO -> 5
5. Review qualitativa? (manual review · screening qualitativo · comparabili · matrice X ·
   accettata/rigettata/borderline · cluster/confidence)
   SÌ -> manual-review           NO -> 6
6. Mappatura file/workflow? (mappa file · knowledge map · relazioni · workflow · grafo)
   SÌ -> produce INVENTORY.md, MAP.md, GRAPH.md, QUALITY_REPORT.md (vedi workflow-mapping.md)
   NO -> 7
7. AMBIGUO -> una sola domanda (sezione 6)
```

Priorità in export misto: **financial wins** (un export bond trattato come standard è l'errore più costoso).

## 5) Engine gestiti — routing e dove leggere

| Engine | Ruolo | Routing rule (sintesi) | Procedura completa | Script |
|---|---|---|---|---|
| **populate-standard** | MAPPING_ENGINE_STANDARD | sheet/header contiene Results OR Risultati OR TP Catalyst, target Analisi, header Company Name OR BvD ID | `references/populate-standard.md` | `scripts/confronto_analisi.py` |
| **populate-financial** | MAPPING_ENGINE_FINANCIAL | sheet/header contiene Bond Results OR Analisi Long OR Bond ISIN OR ISIN OR Final Coupon Date OR Price Date OR Coupon Type OR Bond Currency OR Valuta OR coupon OR EDFX/Modis/Moody | `references/populate-financial.md` | `scripts/populate_analisi_long.py` |
| **carry-forward-lookup** | CARRY_FORWARD_ENGINE | citato Analisi di anno precedente/storico + richiesta di riportare Causa/Descrizione/giudizio, join BvD ID/Company Name | `references/carry-forward-lookup.md` | `scripts/carry_forward_analisi.py` |
| **rejection-matrix** | REJECTION_MATRIX_ENGINE | richiesta di generare/aggiornare la Rejection Matrix, consolidando le colonne granulari di Analisi (Funzioni/Prodotti diversi-ulteriori, Non indipendente, Non profit, Marchi, Altro) in 5 bucket standard | `references/rejection-matrix.md` | `scripts/rejection_matrix.py` |
| **manual-review** | QUALITATIVE_REVIEW_ENGINE | richiesta review/screening qualitativo/comparabili/matrice X/accettata-rigettata-borderline/cluster/confidence, o residui non matchati dal carry-forward | `references/manual-review.md` | — (web review + CSV) |
| **workflow-mapping** | KNOWLEDGE_MAP | richiesta mappa/grafo/relazioni file | `references/workflow-mapping.md` | — |

`populate-financial` è **agente separato** con routing prioritario: non trattarlo come sottocaso di `populate-standard`. `carry-forward-lookup` è **complementare** a `manual-review`, non alternativo: riduce lo scope della review qualitativa alle sole società senza precedenti. `rejection-matrix` è **a valle** di entrambi: legge un Analisi già screenato e ne produce una vista di sintesi per categoria, non sostituisce né lo screening né il carry-forward.

## 6) Output operativo del router

Quando il router decide, rispondere sempre così:

```markdown
## Classificazione
Tipo richiesta: <STANDARD_BENCHMARK | FINANCIAL_BENCHMARK | MANUAL_PREFILLED_ANALISI | CARRY_FORWARD_REVIEW | REJECTION_MATRIX_REQUEST | QUALITATIVE_REVIEW | WORKFLOW_MAPPING | AMBIGUOUS>
Confidence: <0-100>

## Engine attivato
<nome engine>

## Motivo
- Segnale 1
- Segnale 2

## Prossima azione
<azione concreta>
```

Se ambiguo, sostituire "Engine attivato/Motivo/Prossima azione" con:

```markdown
## Domanda necessaria
L'export è un benchmark standard società/TP Catalyst con Results/Risultati oppure un benchmark finanziario/bond con Bond Results/ISIN/Analisi Long?
```

## 7) Regole anti-errore + Workaround smart

**Anti-errore** — (E1) "popola Analisi" = sempre standard → **falso**, classificare standard vs financial prima. (E2) Manual Review dipende sempre da populate-standard → **falso**, può partire da Excel manuale. (E3) populate-financial è variante minore → **falso**, agente separato a priorità. (E4) Collegare file solo per keyword overlap → **falso**, usare ruoli/source/target/join key/quality gate. (E5) "Fai il vlookup di Causa/Descrizione" = fai comunque manual-review completo → **falso**, se esiste uno storico attiva `carry-forward-lookup` prima, manual-review solo sui residui. (E6) Il carry-forward può sovrascrivere un giudizio già presente nel foglio corrente → **falso**, scrive SOLO celle vuote e non-formula (R-CF4). (E7) La Rejection Matrix elenca solo le società rigettate → **falso**, include tutte le società di Analisi (R-RJ1); una società rigettata ha sempre e solo 1 categoria di rigetto → **falso**, può attivare più bucket contemporaneamente (R-RJ4).

**Workaround** — (A) Non posso leggere i fogli Excel → uso nome file + richiesta: `bond/isin/coupon/fin/edfx/modis/moody → financial`; `results/risultati/tp catalyst/screening → standard`; `anno precedente/storico/carry forward → carry-forward-lookup`; `review/qualitativo/comparabili/matrice → manual-review`; se confidence bassa, domanda unica. (B) Excel compilato ma origine ignota e l'utente chiede review → `manual-review` con `source: manual_or_unknown_prefilled_excel`, senza chiedere l'origine se non serve. (C) Export misto → **financial priority**. (D) Utente carica solo il file corrente ma esiste un file omonimo di anno diverso nella stessa cartella → proporre `carry-forward-lookup` con una domanda, non assumere in silenzio (R-CF1).

## 8) Quality gate finale (prima di completare)

```text
[ ] Classificato standard vs financial?
[ ] Controllati segnali Bond/ISIN PRIMA dello standard?
[ ] Riconosciuto se Manual Review può partire da Excel manuale?
[ ] Verificato se esiste uno storico da cui fare carry-forward prima di manual-review?
[ ] Evitate dipendenze obbligatorie non vere?
[ ] Indicati engine attivato e motivo?
[ ] Segnalata ambiguità se confidence bassa?
[ ] Preservati i file originali (no overwrite formule, no overwrite celle già valorizzate)?
[ ] Previsto fallback/workaround?
[ ] Prodotto output auditabile (incl. lista società nuove per manual-review)?
```

## 9) Definizione finale + Changelog

Punto di ingresso unico per i workflow TP Benchmark; orchestra gli engine specialistici. **Classifica prima, attiva dopo. Non rompere Excel.**

| Versione | Data | Note |
|---|---|---|
| v1.2.0 | 2026-07-02 | Aggiunto engine `rejection-matrix`: genera/aggiorna il foglio Rejection Matrix da Analisi, consolidando le 8 colonne categoriche granulari (Società non indipendente, Non finalizzata al profitto, Marchi/brevetti/intangibili, Funzioni diverse/ulteriori, Prodotti diversi/ulteriori, Altro) nei 5 bucket standard (Different/Additional Functions, Different/Additional Products, Other Reasons — R-RJ3). Supporta sia il riempimento di un template Rejection Matrix esistente (`--target`, preserva formule/merge/formattazione, append delle società mancanti R-RJ8) sia la creazione da zero. Mapping verificato end-to-end contro un file di produzione reale (127 società, 111 rigettate, distribuzione bucket 4/2/93/3/9 confermata cifra per cifra). Nuovo script `scripts/rejection_matrix.py`, nuova reference `rejection-matrix.md`, router/scoring/decision-tree/anti-errore/quality-gate aggiornati. **Bug #8 trovato e risolto** (proattivo, su dati reali, non sintetici): `norm()` non normalizzava gli accenti — header con lettere accentate italiane (es. "Società non indipendente") non matchavano le keyword ASCII della suite, causando mancato riconoscimento silenzioso di colonne esistenti. Fix: `unicodedata.normalize` + strip dei combining marks prima del confronto, applicato a `rejection_matrix.py`, `carry_forward_analisi.py` e `confronto_analisi.py` (le 3 funzioni `norm()` della suite); `populate_analisi_long.py` non è interessato (nessun matching per keyword, solo indici hardcoded). Rieseguita l'intera regressione bug #1–#7 dopo il fix: nessuna rottura. |
| v1.1.3 | 2026-07-02 | Risolto il limite noto v1.1.2 (rilevamento riga-header): `find_header_row` ora pesa prima sulla presenza di keyword note di header (Company Name, BvD ID, NACE, Esito, Causa, Descrizione, Cluster, Confidence, Fonte, Website, ...) e solo a parità sul conteggio celle di testo — una riga decorativa (titolo report, watermark, numero pagina) con più celle del vero header non vince più per puro conteggio (R-CF13). Fix applicato sia a `carry_forward_analisi.py` sia a `confronto_analisi.py` (`populate-standard`), che condividono l'identica euristica; `populate_analisi_long.py` (`populate-financial`) non è interessato perché usa `--header-idx` esplicito da CLI, non auto-detect. Verificato end-to-end su entrambi gli script con file sintetici a più righe decorative sopra l'header reale; nessuna regressione sui bugfix v1.1.1/v1.1.2. |
| v1.1.2 | 2026-07-02 | Edge-case/stress test su `carry_forward_analisi.py` con file sintetici avversariali: (1) **crash confermato e risolto** su celle merged nel target (scrivere su una MergedCell non-anchor sollevava `AttributeError`, script moriva senza salvare nulla) → ora rilevate e saltate con contatore dedicato (R-CF11). (2) **macro .xlsm distrutte silenziosamente confermato e risolto**: mancava `keep_vba=True` al caricamento, il progetto VBA spariva al salvataggio anche partendo da un file macro-enabled; corretto anche il naming di output che forzava sempre `.xlsx` pure su input `.xlsm` (R-CF12). (3) **gap metodologico confermato e risolto**: riclassificazione NACE (es. produttore→distributore, profilo funzionale diverso) veniva carry-forward senza alcun segnale → aggiunto terzo trigger di re-validazione su NACE, simmetrico al check website (R-CF6 esteso). Verificato inoltre: formule complesse (IFERROR/VLOOKUP cross-sheet, annidate) preservate correttamente; file `.xls` legacy rifiutato con errore pulito (nessun crash). **Limite noto non risolto**: rilevamento riga-header (euristica condivisa con `populate-standard`/`populate-financial`) può individuare la riga sbagliata se una riga decorativa (titolo/watermark) ha più celle di testo del vero header — fallisce in modo sicuro (errore esplicito, nessun file scritto) ma non completa il carry-forward; documentato in `carry-forward-lookup.md`, non risolto perché la stessa euristica è condivisa da più engine e un fix andrebbe validato su tutti e tre. Nessuna regressione sui bugfix v1.1.1 né sul caso base. |
| v1.1.1 | 2026-07-01 | Bugfix su `carry_forward_analisi.py` trovati con test su casi sintetici avversariali: (1) BvD ID duplicato nello storico causava cross-contaminazione silenziosa (giudizio di una società attribuito a un'altra, "ultima riga vince") → ora escluso dal match per BvD, risolto solo per Nome, sempre segnalato nel riepilogo (R-CF9). (2) Keyword generica "codice" collideva per sottostringa con colonne omonime tipo "Codice Fiscale", scrivendo il codice di rigetto nella colonna sbagliata e perdendo il dato reale → ora match esatto sull'header prima del fallback per sottostringa (R-CF10). (3) Esito storico "Borderline" veniva perpetuato senza mai un flag di ri-esame → ora sempre marcato `[DA RE-VALIDARE: esito storico Borderline]` indipendentemente dal check website (R-CF6 estesa). Tutti e 3 confermati riprodotti prima del fix e risolti dopo, su file Excel sintetici; nessuna regressione sul caso base BvD+Nome. |
| v1.1.0 | 2026-07-01 | Aggiunto engine `carry-forward-lookup`: riporta Causa di rigetto/Descrizione della Società/giudizio qualitativo da un Analisi storico (anno precedente) a quello corrente via join BvD ID/Company Name, scrivendo solo celle vuote e non-formula; le società non trovate nello storico restano a `manual-review`. Nuovo script `scripts/carry_forward_analisi.py` (testato su caso sintetico: match BvD/Nome, formule preservate, celle già valorizzate intatte, flag re-validare su website disallineato, unmatched → CSV). Router, scoring, decision tree, anti-errore e quality gate aggiornati di conseguenza. |
| v1.0.0 | 2026-06-22 | Consolidamento: router 2.0 + engine standard + engine financial + screening qualitativo v3.4 in unica skill; frontmatter conforme alla validazione Agent Skills (metadati annidati); script standard ricostruito da specifica e script financial reso eseguibile via CLI; `[FLAG]` su preservazione formule del template financial. |
