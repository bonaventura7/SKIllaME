#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
carry_forward_analisi.py — Engine CARRY-FORWARD (carry-forward-lookup)

Riporta il giudizio qualitativo (Causa di rigetto, Descrizione della Società,
Esito, Codice, Matrice X A-H, Cluster, Confidence, Website, Detail) da un
foglio 'Analisi' STORICO (anno precedente, gia' screenato) a un foglio
'Analisi' CORRENTE (anno in corso), per le societa' gia' valutate in passato.
Match per BvD ID (chiave primaria) con fallback su Company Name normalizzato.

Non sovrascrive MAI celle con formula, ne' celle target gia' valorizzate
(il giudizio dell'anno corrente prevale sempre). Le righe non trovate nello
storico vengono elencate in output separato per il motore 'manual-review'
(mai lasciate vuote in silenzio).

Uso:
  python carry_forward_analisi.py --source vecchio_2023.xlsx --source-year 2023 \\
      --target nuovo_2024.xlsx --output nuovo_2024_Analisi_CarryForward.xlsx

  python carry_forward_analisi.py --source vecchio_2023.xlsx --source-year 2023 \\
      --target nuovo_2024.xlsx --in-place --unmatched-csv nuove_societa_2024.csv
"""

import argparse
import csv
import os
import re
import sys
import unicodedata

import openpyxl
from openpyxl.cell.cell import MergedCell

CARRY_COLUMNS = {
    "non_independent": ["non independent", "non indipendente", "societa non indipendente"],
    "trademarks": ["trademarks", "marchi"],
    "diff_functions": ["different functions", "funzioni diverse"],
    "add_functions": ["additional functions", "funzioni ulteriori"],
    "diff_products": ["different products", "prodotti diversi"],
    "add_products": ["additional products", "prodotti ulteriori"],
    "non_comparable_sector": ["non comparable sector", "settore non comparabile"],
    "other": ["other", "altro"],
    "esito": ["esito", "risultato"],
    "codice": ["codice"],
    "causa": ["causa"],
    "descrizione": ["descrizione", "description"],
    "cluster": ["cluster"],
    "confidence": ["confidence", "confidenza"],
    "website": ["website", "sito"],
    "detail": ["detail", "dettaglio", "nota", "note"],
}
# Fonte/Source gestita a parte: e' sempre scritta con l'etichetta carry-forward, mai copiata dal valore condiviso.
SOURCE_KEYWORDS = ["fonte", "source"]


def norm(s):
    """Normalizza un'intestazione: minuscolo, senza accenti, senza punteggiatura,
    spazi compressi. Lo strip degli accenti (es. 'Societa' non indipendente' con
    la a accentata -> 'societa non indipendente') evita mismatch silenziosi contro
    keyword ASCII quando l'header reale usa lettere accentate italiane."""
    if s is None:
        return ""
    s = str(s).lower().strip()
    s = "".join(c for c in unicodedata.normalize("NFKD", s) if not unicodedata.combining(c))
    s = re.sub(r"[^\w\s%]", " ", s, flags=re.UNICODE)
    s = re.sub(r"\s+", " ", s).strip()
    return s


def norm_key(s):
    """Chiave di join (Company Name): minuscolo, spazi compressi, suffissi societari rimossi."""
    s = norm(s)
    s = re.sub(r"\b(spa|s p a|srl|s r l|gmbh|ltd|plc|sa|s a|nv|n v|bv|b v|inc|llc|ag|sas|kg)\b", "", s)
    return re.sub(r"\s+", " ", s).strip()


def norm_website(s):
    """Normalizza un URL per il confronto di freschezza (R-CF6): minuscolo, senza schema/www/slash finale."""
    if not s:
        return ""
    s = str(s).strip().lower()
    s = re.sub(r"^https?://", "", s)
    s = re.sub(r"^www\.", "", s)
    return s.rstrip("/")


def norm_nace(s):
    """Normalizza un codice NACE per il confronto di freschezza (R-CF6): estrae
    il codice numerico iniziale (es. '2562' da '2562 - Trattamento metalli'),
    altrimenti confronta il testo normalizzato per intero."""
    if not s:
        return ""
    s = str(s).strip()
    m = re.match(r"\s*(\d{2,4}(?:\.\d+)?)", s)
    return m.group(1) if m else norm(s)


def find_sheet(wb, exact_lower, contains=None):
    for name in wb.sheetnames:
        if name.strip().lower() in exact_lower:
            return name
    if contains:
        for name in wb.sheetnames:
            if contains in name.strip().lower():
                return name
    return None


HEADER_ANCHOR_KEYWORDS = (
    "company name", "company", "societa", "denominazione", "bvd id", "bvd", "bvd number",
    "website", "sito", "nace", "esito", "risultato", "codice", "causa", "descrizione",
    "cluster", "confidence", "confidenza", "fonte", "source", "detail", "dettaglio",
    "non independent", "trademarks", "marchi", "other", "altro",
)


def find_header_row(ws, max_scan=20):
    """Sceglie la riga con piu' hit su keyword note di header (Company Name, BvD ID,
    Esito, Causa, Descrizione, ...); a parita' di hit sceglie quella con piu' celle di
    testo. Una riga puramente decorativa (titolo report, watermark 'Bozza/Riservato',
    numero pagina) sopra l'header reale di norma non contiene nessuna di queste keyword,
    quindi non vince piu' per il solo conteggio di celle (bug: falso positivo su righe
    titolo con piu' celle testo del vero header)."""
    best_idx, best_score, best_count = None, -1, 0
    for r in range(1, min(max_scan, ws.max_row) + 1):
        texts = [str(c.value).strip() for c in ws[r] if isinstance(c.value, str) and c.value.strip()]
        if len(texts) < 3:
            continue
        normed = [norm(t) for t in texts]
        anchor_hits = sum(1 for kw in HEADER_ANCHOR_KEYWORDS if any(kw in t for t in normed))
        if anchor_hits > best_score or (anchor_hits == best_score and len(texts) > best_count):
            best_idx, best_score, best_count = r, anchor_hits, len(texts)
    return best_idx or 1


def header_map(ws, header_row):
    out = {}
    for c_idx, cell in enumerate(ws[header_row], start=1):
        h = norm(cell.value)
        if h and h not in out:
            out[h] = c_idx
    return out


def col_by_keywords(hmap, keywords):
    """Match esatto prima (evita collisioni tipo 'Codice' vs 'Codice Fiscale'),
    poi fallback per sottostringa se nessun header esatto e' stato trovato."""
    for kw in keywords:
        kw = norm(kw)
        if kw and kw in hmap:
            return hmap[kw]
    for kw in keywords:
        kw = norm(kw)
        for h, idx in hmap.items():
            if kw and kw in h:
                return idx
    return None


def is_formula(cell):
    return cell.data_type == "f" or (isinstance(cell.value, str) and cell.value.startswith("="))


def is_locked(cell):
    """Cella non scrivibile: formula (R-CF3) o MergedCell non-anchor (R-CF11).
    Scrivere su una MergedCell non-anchor solleva AttributeError in openpyxl
    e farebbe crashare l'intero script prima del salvataggio."""
    return is_formula(cell) or isinstance(cell, MergedCell)


def is_blank(cell):
    v = cell.value
    return v is None or (isinstance(v, str) and not v.strip())


def build_lookup(ws, header_row, col_bvd, col_company):
    """BvD ID duplicato nello storico e' ambiguo (rischio di attribuire il giudizio
    di una societa' a un'altra): viene escluso da by_bvd, mai risolto a caso
    prendendo 'l'ultima riga vince'. Le righe restano risolvibili via Company Name."""
    by_bvd, by_name, dup_bvd = {}, {}, set()
    for r in range(header_row + 1, ws.max_row + 1):
        bvd = ws.cell(row=r, column=col_bvd).value if col_bvd else None
        name = ws.cell(row=r, column=col_company).value if col_company else None
        if bvd and str(bvd).strip():
            key = str(bvd).strip().upper()
            if key in by_bvd:
                dup_bvd.add(key)
            else:
                by_bvd[key] = r
        if name and str(name).strip():
            by_name[norm_key(name)] = r
    for key in dup_bvd:
        del by_bvd[key]
    return by_bvd, by_name, dup_bvd


def main():
    ap = argparse.ArgumentParser(
        description="Riporta Causa/Descrizione/giudizio qualitativo da Analisi storico a Analisi corrente."
    )
    ap.add_argument("--source", required=True, help="File Excel storico (anno precedente, sola lettura)")
    ap.add_argument("--source-year", required=True, help="Anno del file storico (per etichetta Fonte)")
    ap.add_argument("--target", required=True, help="File Excel corrente (anno in corso, da completare)")
    ap.add_argument("--output", default=None, help="Output (default: <target>_Analisi_CarryForward.xlsx)")
    ap.add_argument("--in-place", action="store_true", help="Sovrascrive --target invece di creare un nuovo file")
    ap.add_argument("--source-sheet", default=None, help="Forza il nome del foglio Analisi storico")
    ap.add_argument("--target-sheet", default=None, help="Forza il nome del foglio Analisi corrente")
    ap.add_argument("--unmatched-csv", default=None,
                    help="Percorso CSV per le societa' non trovate nello storico (input per manual-review)")
    args = ap.parse_args()

    for label, path in (("storico", args.source), ("corrente", args.target)):
        if not os.path.exists(path):
            print(f"ERRORE: file {label} non trovato: {path}")
            sys.exit(1)
        if os.path.splitext(path)[1].lower() not in (".xlsx", ".xlsm"):
            print(f"ERRORE: file {label} non in formato .xlsx/.xlsm (necessario per preservare le formule): {path}")
            sys.exit(1)

    # keep_vba=True e' necessario per i file .xlsm: senza, openpyxl scarta il
    # progetto VBA (macro) in silenzio al salvataggio, anche se il file di
    # partenza le conteneva (R-CF12).
    tgt_is_xlsm = os.path.splitext(args.target)[1].lower() == ".xlsm"
    wb_src = openpyxl.load_workbook(args.source, data_only=False,
                                     keep_vba=(os.path.splitext(args.source)[1].lower() == ".xlsm"))
    wb_tgt = openpyxl.load_workbook(args.target, data_only=False, keep_vba=tgt_is_xlsm)

    src_name = args.source_sheet or find_sheet(wb_src, ("analisi",), contains="analisi")
    tgt_name = args.target_sheet or find_sheet(wb_tgt, ("analisi",), contains="analisi")
    if not src_name:
        print(f"ERRORE: foglio Analisi assente nello storico. Fogli: {wb_src.sheetnames}")
        sys.exit(1)
    if not tgt_name:
        print(f"ERRORE: foglio Analisi assente nel corrente. Fogli: {wb_tgt.sheetnames}")
        sys.exit(1)

    ws_src, ws_tgt = wb_src[src_name], wb_tgt[tgt_name]
    hr_src, hr_tgt = find_header_row(ws_src), find_header_row(ws_tgt)
    hmap_src, hmap_tgt = header_map(ws_src, hr_src), header_map(ws_tgt, hr_tgt)

    col_bvd_src = col_by_keywords(hmap_src, ["bvd id", "bvd", "bvd number"])
    col_company_src = col_by_keywords(hmap_src, ["company name", "company", "societa", "denominazione"])
    col_bvd_tgt = col_by_keywords(hmap_tgt, ["bvd id", "bvd", "bvd number"])
    col_company_tgt = col_by_keywords(hmap_tgt, ["company name", "company", "societa", "denominazione"])
    if not (col_bvd_src or col_company_src) or not (col_bvd_tgt or col_company_tgt):
        print("ERRORE: impossibile individuare Company Name / BvD ID in uno dei due fogli Analisi.")
        sys.exit(1)

    # Colonne qualitative condivise (presenti in entrambi gli header)
    shared = {}
    for label, keywords in CARRY_COLUMNS.items():
        idx_src = col_by_keywords(hmap_src, keywords)
        idx_tgt = col_by_keywords(hmap_tgt, keywords)
        if idx_src and idx_tgt:
            shared[label] = (idx_src, idx_tgt)

    if "causa" not in shared or "descrizione" not in shared:
        print("[ATTENZIONE] Colonna 'Causa' o 'Descrizione' non trovata in uno dei due fogli: verificare gli header.")

    col_source_tgt = col_by_keywords(hmap_tgt, SOURCE_KEYWORDS)
    col_website_src, col_website_tgt = shared.get("website", (None, None))
    col_detail_tgt = shared.get("detail", (None, None))[1]
    # NACE e' una colonna di input (letta da Results/Orbis), non viene mai scritta dal
    # carry-forward: serve solo come segnale di freschezza (R-CF6c) - se il codice e'
    # cambiato, il profilo funzionale storico potrebbe non valere piu'.
    col_nace_src = col_by_keywords(hmap_src, ["nace"])
    col_nace_tgt = col_by_keywords(hmap_tgt, ["nace"])

    by_bvd, by_name, dup_bvd = build_lookup(ws_src, hr_src, col_bvd_src, col_company_src)

    fonte_label = f"Carry-forward {args.source_year}"
    matched_bvd = matched_name = written_cells = skipped_formula = skipped_filled = skipped_merged = revalidate = 0
    unmatched = []

    for r in range(hr_tgt + 1, ws_tgt.max_row + 1):
        bvd = ws_tgt.cell(row=r, column=col_bvd_tgt).value if col_bvd_tgt else None
        name = ws_tgt.cell(row=r, column=col_company_tgt).value if col_company_tgt else None
        if not bvd and not name:
            continue

        src_row = None
        via_bvd = False
        if bvd and str(bvd).strip().upper() in by_bvd:
            src_row = by_bvd[str(bvd).strip().upper()]
            via_bvd = True
        elif name and norm_key(name) in by_name:
            src_row = by_name[norm_key(name)]

        if src_row is None:
            unmatched.append(str(name or bvd))
            continue

        if via_bvd:
            matched_bvd += 1
        else:
            matched_name += 1

        row_written = False
        for _label, (idx_src, idx_tgt) in shared.items():
            tgt_cell = ws_tgt.cell(row=r, column=idx_tgt)
            if isinstance(tgt_cell, MergedCell):
                skipped_merged += 1
                continue
            if is_formula(tgt_cell):
                skipped_formula += 1
                continue
            if not is_blank(tgt_cell):
                skipped_filled += 1
                continue
            src_val = ws_src.cell(row=src_row, column=idx_src).value
            if src_val is None or (isinstance(src_val, str) and not src_val.strip()):
                continue
            tgt_cell.value = src_val
            written_cells += 1
            row_written = True

        if row_written and col_source_tgt:
            src_cell = ws_tgt.cell(row=r, column=col_source_tgt)
            if not is_locked(src_cell):
                src_cell.value = fonte_label

        row_flagged = False
        if row_written and col_detail_tgt:
            detail_cell = ws_tgt.cell(row=r, column=col_detail_tgt)
            if not is_locked(detail_cell):
                flags = []
                if col_website_src and col_website_tgt:
                    w_src = norm_website(ws_src.cell(row=src_row, column=col_website_src).value)
                    w_tgt_now = norm_website(ws_tgt.cell(row=r, column=col_website_tgt).value)
                    if w_src and w_tgt_now and w_src != w_tgt_now:
                        flags.append("[DA RE-VALIDARE: possibile disallineamento website]")
                if col_nace_src and col_nace_tgt:
                    n_src = norm_nace(ws_src.cell(row=src_row, column=col_nace_src).value)
                    n_tgt = norm_nace(ws_tgt.cell(row=r, column=col_nace_tgt).value)
                    if n_src and n_tgt and n_src != n_tgt:
                        flags.append("[DA RE-VALIDARE: NACE storico diverso dal corrente]")
                esito_idx_src = shared.get("esito", (None, None))[0]
                if esito_idx_src:
                    esito_val = ws_src.cell(row=src_row, column=esito_idx_src).value
                    if esito_val and str(esito_val).strip().lower() == "borderline":
                        flags.append("[DA RE-VALIDARE: esito storico Borderline]")
                if flags:
                    added = " ".join(flags)
                    detail_cell.value = f"{detail_cell.value} {added}".strip() if detail_cell.value else added
                    row_flagged = True
        if row_flagged:
            revalidate += 1

    tgt_base, tgt_ext = os.path.splitext(args.target)
    output_file = args.target if args.in_place else (args.output or (tgt_base + "_Analisi_CarryForward" + tgt_ext))
    wb_tgt.save(output_file)

    if args.unmatched_csv and unmatched:
        with open(args.unmatched_csv, "w", newline="", encoding="utf-8-sig") as f:
            writer = csv.writer(f)
            writer.writerow(["Company"])
            for u in unmatched:
                writer.writerow([u])

    print("=== carry_forward_analisi.py — riepilogo ===")
    print(f"Storico: '{args.source}' foglio '{src_name}' (header riga {hr_src}, anno {args.source_year})")
    print(f"Corrente: '{args.target}' foglio '{tgt_name}' (header riga {hr_tgt})")
    print(f"Colonne qualitative riportate: {', '.join(sorted(shared.keys())) or 'NESSUNA (verificare header)'}")
    print(f"Righe corrente matchate per BvD ID: {matched_bvd}")
    print(f"Righe corrente matchate per Company Name: {matched_name}")
    print(f"Righe corrente NON matchate (-> manual-review): {len(unmatched)}")
    print(f"Celle scritte: {written_cells} | saltate per formula: {skipped_formula} | saltate perche' gia' valorizzate: {skipped_filled} | saltate perche' merged: {skipped_merged}")
    print(f"Righe marcate [DA RE-VALIDARE]: {revalidate}")
    if skipped_merged:
        print(f"[ATTENZIONE] {skipped_merged} celle non scritte perche' fanno parte di un merge (cella unita): "
              f"verificare manualmente quelle righe/colonne nel foglio Analisi corrente.")
    if dup_bvd:
        print(f"[ATTENZIONE] {len(dup_bvd)} BvD ID duplicati nello storico (ambigui, esclusi dal match per BvD, "
              f"risolti solo per Company Name se possibile): {', '.join(sorted(dup_bvd))}")
    if unmatched:
        print(f"[NUOVE SOCIETA'] {len(unmatched)} da passare a manual-review: {', '.join(unmatched)}")
        if args.unmatched_csv:
            print(f"Elenco salvato in: {args.unmatched_csv}")
    else:
        print("Nessuna nuova societa': tutte le righe del corrente hanno match nello storico.")
    print(f"Salvato: {output_file}")


if __name__ == "__main__":
    main()
