#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
confronto_analisi.py — Engine STANDARD (populate-standard)

Popola il foglio 'Analisi' a partire dal foglio 'Results'/'Risultati' (export
screening), allineando le righe per Company Name o BvD ID e PRESERVANDO le
formule esistenti (le celle con formula nel foglio 'Analisi' non vengono mai
sovrascritte). Converte 'n.a.' in celle vuote, normalizza le percentuali ed
evidenzia i flag NACE per la review manuale.

[RICOSTRUITO DA SPECIFICA] Il corpo di 'confronto_analisi.py' NON era incluso
nel materiale sorgente (era documentato solo invocazione + comportamento atteso
nella skill 'populate-analisi'). Questo file implementa fedelmente quella
specifica. VERIFICARE contro l'eventuale script originale aziendale prima
dell'uso in produzione. Le assunzioni operative sono marcate con [ASSUNZIONE].

Uso:
  python confronto_analisi.py --input "C:\\path\\to\\file.xlsx" --years 2021 2022 2023
  python confronto_analisi.py --input file.xlsx --years 2021 2022 2023 \\
      --analisi-sheet "Analisi" --percent-mode fraction
"""

import argparse
import os
import re
import sys
import unicodedata
from datetime import date

import openpyxl

RESULTS_NAMES = ("results", "risultati", "screening results")
NACE_HINTS = ("nace",)


def norm(s):
    """Normalizza un'intestazione: minuscolo, senza accenti, senza punteggiatura,
    spazi compressi. Lo strip degli accenti (es. 'Societa' non indipendente' con
    la a accentata -> 'societa non indipendente') evita mismatch silenziosi contro
    keyword ASCII quando l'header reale usa lettere accentate italiane."""
    if s is None:
        return ""
    s = str(s).lower().strip()
    s = "".join(c for c in unicodedata.normalize("NFKD", s) if not unicodedata.combining(c))
    s = re.sub(r"[^\w\s%]", " ", s, flags=re.UNICODE)
    s = re.sub(r"\s+", " ", s).strip()
    return s


def norm_key(s):
    """Chiave di join (Company Name): minuscolo, spazi compressi, suffissi societari rimossi."""
    s = norm(s)
    s = re.sub(r"\b(spa|s p a|srl|s r l|gmbh|ltd|plc|sa|s a|nv|n v|bv|b v|inc|llc|ag|sas|kg)\b", "", s)
    return re.sub(r"\s+", " ", s).strip()


def find_sheet(wb, candidates_lower, contains=None):
    """Trova un foglio per nome esatto (lista) o per 'contains'."""
    for name in wb.sheetnames:
        if name.strip().lower() in candidates_lower:
            return name
    if contains:
        for name in wb.sheetnames:
            if contains in name.strip().lower():
                return name
    return None


HEADER_ANCHOR_KEYWORDS = (
    "company name", "company", "societa", "denominazione", "bvd id", "bvd", "bvd number",
    "nace", "source", "fonte", "data update", "data aggiornamento", "update",
    "results", "risultati", "tp catalyst", "analisi",
)


def find_header_row(ws, max_scan=20):
    """Sceglie la riga con piu' hit su keyword note di header (Company Name, BvD ID,
    NACE, Source, ...); a parita' di hit sceglie quella con piu' celle di testo. Una
    riga puramente decorativa (titolo report, watermark, numero pagina) sopra l'header
    reale di norma non contiene nessuna di queste keyword, quindi non vince piu' per il
    solo conteggio di celle (bug: falso positivo su righe titolo con piu' celle testo
    del vero header)."""
    best_idx, best_score, best_count = None, -1, 0
    for r in range(1, min(max_scan, ws.max_row) + 1):
        texts = [str(c.value).strip() for c in ws[r] if isinstance(c.value, str) and c.value.strip()]
        if len(texts) < 3:
            continue
        normed = [norm(t) for t in texts]
        anchor_hits = sum(1 for kw in HEADER_ANCHOR_KEYWORDS if any(kw in t for t in normed))
        if anchor_hits > best_score or (anchor_hits == best_score and len(texts) > best_count):
            best_idx, best_score, best_count = r, anchor_hits, len(texts)
    return best_idx or 1


def header_map(ws, header_row):
    """Mappa header_normalizzato -> indice colonna (1-based)."""
    out = {}
    for c_idx, cell in enumerate(ws[header_row], start=1):
        h = norm(cell.value)
        if h and h not in out:
            out[h] = c_idx
    return out


def col_by_keywords(hmap, keywords):
    """Restituisce l'indice colonna il cui header contiene una delle keyword."""
    for kw in keywords:
        kw = norm(kw)
        for h, idx in hmap.items():
            if kw and kw in h:
                return idx
    return None


def is_formula(cell):
    return cell.data_type == "f" or (isinstance(cell.value, str) and cell.value.startswith("="))


def to_number(s):
    """Converte una stringa numerica EU/US in int/float, o None se non numerica.
    Gestisce separatori migliaia ('.' EU o ',' US) e decimale ('.' o ',')."""
    s = s.strip().replace(" ", "").replace("\u00a0", "")
    if not s:
        return None
    neg = s.startswith("-")
    body = s[1:] if neg else s
    if re.fullmatch(r"\d{1,3}(\.\d{3})+(,\d+)?", body):        # EU: 1.000.000,50
        body = body.replace(".", "").replace(",", ".")
    elif re.fullmatch(r"\d{1,3}(,\d{3})+(\.\d+)?", body):      # US: 1,000,000.50
        body = body.replace(",", "")
    elif re.fullmatch(r"\d+,\d+", body):                        # decimale a virgola: 12,3
        body = body.replace(",", ".")
    elif not re.fullmatch(r"\d+(\.\d+)?", body):                # non numerico
        return None
    try:
        f = float(body)
    except ValueError:
        return None
    f = -f if neg else f
    return int(f) if f.is_integer() else f


def clean_value(val, percent_mode):
    """'n.a.' -> None; normalizza numeri e percentuali (testo vs numero)."""
    if val is None:
        return None
    if isinstance(val, str):
        s = val.strip()
        if s.lower() in ("n.a.", "na", "n/a", "n.d.", "nd", "-", ""):
            return None
        if s.endswith("%"):
            num = to_number(s[:-1])
            if num is None:
                return s
            if percent_mode == "fraction":
                return num / 100.0
            if percent_mode == "number":
                return num
            return s  # raw
        num = to_number(s)
        return num if num is not None else s
    return val


def build_results_lookup(ws, header_row, col_company, col_bvd):
    """Lookup righe Results per BvD ID e per Company Name normalizzato."""
    by_bvd, by_name = {}, {}
    for r in range(header_row + 1, ws.max_row + 1):
        bvd = ws.cell(row=r, column=col_bvd).value if col_bvd else None
        name = ws.cell(row=r, column=col_company).value if col_company else None
        if bvd:
            by_bvd[str(bvd).strip().upper()] = r
        if name:
            by_name[norm_key(name)] = r
    return by_bvd, by_name


def main():
    ap = argparse.ArgumentParser(description="Popola 'Analisi' da 'Results/Risultati' preservando le formule.")
    ap.add_argument("--input", required=True, help="File Excel sorgente (.xlsx/.xlsm)")
    ap.add_argument("--years", nargs="+", required=True, help="Triennio, es. 2021 2022 2023")
    ap.add_argument("--output", default=None, help="Output (default: _Analisi_Popolato.xlsx)")
    ap.add_argument("--results-sheet", default=None, help="Forza il nome del foglio Results")
    ap.add_argument("--analisi-sheet", default=None, help="Forza il nome del foglio Analisi")
    ap.add_argument("--indicator", default=None, help="Indicatore finanziario principale (info/log)")
    ap.add_argument("--percent-mode", choices=["fraction", "number", "raw"], default="fraction",
                    help="[ASSUNZIONE] '12,3%%' -> 0.123 (fraction) | 12.3 (number) | testo (raw)")
    args = ap.parse_args()

    if not os.path.exists(args.input):
        print(f"ERRORE: file non trovato: {args.input}")
        sys.exit(1)
    ext = os.path.splitext(args.input)[1].lower()
    if ext not in (".xlsx", ".xlsm"):
        print(f"ERRORE: estensione non supportata ({ext}). Convertire in .xlsx per preservare le formule.")
        sys.exit(1)

    wb = openpyxl.load_workbook(args.input)  # data_only=False: preserva le formule
    res_name = args.results_sheet or find_sheet(wb, RESULTS_NAMES, contains="result") or find_sheet(wb, RESULTS_NAMES, contains="risult")
    ana_name = args.analisi_sheet or find_sheet(wb, ("analisi",), contains="analisi")
    if not res_name:
        print(f"ERRORE: foglio Results/Risultati assente. Fogli: {wb.sheetnames}")
        sys.exit(1)
    if not ana_name:
        print(f"ERRORE: foglio Analisi assente. Fogli: {wb.sheetnames}")
        sys.exit(1)

    ws_res, ws_ana = wb[res_name], wb[ana_name]
    hr_res, hr_ana = find_header_row(ws_res), find_header_row(ws_ana)
    hmap_res, hmap_ana = header_map(ws_res, hr_res), header_map(ws_ana, hr_ana)

    col_company_res = col_by_keywords(hmap_res, ["company name", "company", "società", "denominazione"])
    col_bvd_res = col_by_keywords(hmap_res, ["bvd id", "bvd", "bvd number"])
    col_company_ana = col_by_keywords(hmap_ana, ["company name", "company", "società", "denominazione"])
    col_bvd_ana = col_by_keywords(hmap_ana, ["bvd id", "bvd", "bvd number"])
    if not (col_company_res or col_bvd_res) or not (col_company_ana or col_bvd_ana):
        print("ERRORE: impossibile individuare Company Name / BvD ID nei due fogli.")
        sys.exit(1)

    # Colonne input da popolare: header presenti in ENTRAMBI i fogli (mapping per pattern)
    shared = {}
    for h, idx_ana in hmap_ana.items():
        if h in hmap_res:
            shared[h] = (hmap_res[h], idx_ana)
    # Escludi le chiavi di join dalla scrittura
    for key_col in (col_company_ana, col_bvd_ana):
        shared = {h: v for h, v in shared.items() if v[1] != key_col}

    # Anni mancanti: ogni anno richiesto deve comparire in almeno un header di Analisi
    missing_years = [y for y in args.years if not any(str(y) in h for h in hmap_ana)]

    # Colonne accessorie
    col_dataupdate = col_by_keywords(hmap_ana, ["data update", "data aggiornamento", "update"])
    col_source = col_by_keywords(hmap_ana, ["source", "fonte"])
    col_nace_ana = col_by_keywords(hmap_ana, NACE_HINTS)

    by_bvd, by_name = build_results_lookup(ws_res, hr_res, col_company_res, col_bvd_res)

    today = date.today().strftime("%d/%m/%Y")
    matched, unmatched_ana, nace_flags, written_cells = 0, [], 0, 0

    for r in range(hr_ana + 1, ws_ana.max_row + 1):
        bvd = ws_ana.cell(row=r, column=col_bvd_ana).value if col_bvd_ana else None
        name = ws_ana.cell(row=r, column=col_company_ana).value if col_company_ana else None
        if not bvd and not name:
            continue
        src_row = None
        if bvd and str(bvd).strip().upper() in by_bvd:
            src_row = by_bvd[str(bvd).strip().upper()]
        elif name and norm_key(name) in by_name:
            src_row = by_name[norm_key(name)]
        if src_row is None:
            unmatched_ana.append(str(name or bvd))
            continue
        matched += 1

        for _h, (idx_res, idx_ana) in shared.items():
            tgt = ws_ana.cell(row=r, column=idx_ana)
            if is_formula(tgt):   # PRESERVA le formule: non sovrascrivere
                continue
            raw = ws_res.cell(row=src_row, column=idx_res).value
            val = clean_value(raw, args.percent_mode)
            if val is not None:
                tgt.value = val
                written_cells += 1

        if col_dataupdate and not is_formula(ws_ana.cell(row=r, column=col_dataupdate)):
            ws_ana.cell(row=r, column=col_dataupdate).value = today
        if col_source and not is_formula(ws_ana.cell(row=r, column=col_source)):
            ws_ana.cell(row=r, column=col_source).value = res_name
        if col_nace_ana and ws_ana.cell(row=r, column=col_nace_ana).value:
            nace_flags += 1

    output_file = args.output or (os.path.splitext(args.input)[0] + "_Analisi_Popolato.xlsx")
    wb.save(output_file)

    # Riepilogo a console
    print("=== confronto_analisi.py — riepilogo ===")
    print(f"Foglio Results: '{res_name}' (header riga {hr_res}) | Foglio Analisi: '{ana_name}' (header riga {hr_ana})")
    if args.indicator:
        print(f"Indicatore principale: {args.indicator}")
    print(f"Triennio richiesto: {' '.join(map(str, args.years))}")
    print(f"Righe Analisi matchate: {matched} | celle input scritte: {written_cells} (formule preservate)")
    print(f"Flag NACE evidenziati (per review manuale): {nace_flags}")
    if missing_years:
        print(f"[ATTENZIONE] Anni mancanti tra le intestazioni di Analisi: {', '.join(map(str, missing_years))}")
    if unmatched_ana:
        print(f"[MISMATCH] {len(unmatched_ana)} società in Analisi senza corrispondenza in Results: {', '.join(unmatched_ana)}")
    else:
        print("Nessun mismatch: tutte le società di Analisi hanno corrispondenza in Results.")
    print(f"Salvato: {output_file}")


if __name__ == "__main__":
    main()
