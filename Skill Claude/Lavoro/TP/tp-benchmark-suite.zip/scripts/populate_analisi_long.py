#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
populate_analisi_long.py — Engine FINANCIAL (populate-financial)

Popola il foglio 'Analisi Long' da 'Bond Results' usando il Bond ISIN come
chiave di join. Le date sono SEMPRE scritte come oggetti datetime con
number_format 'DD/MM/YYYY' (mai stringhe ISO, mai serial Excel grezzi).

Origine: questo script riproduce fedelmente il template della skill
'populate-analisi-tp-fin' (sorgente fornita), reso eseguibile via CLI.
Aggiunge una modalita' opzionale --preserve che, per input .xlsx, scrive
SOLO nelle celle target lasciando intatte le formule (vedi [FLAG] nel
reference populate-financial.md). La modalita' default 'rebuild' e' fedele
al template originale (ricostruisce un workbook nuovo dai valori letti).

Mapping OBBLIGATORIO Bond Results -> Analisi Long (indici 0-based):
  Final Coupon Date  AL 22  <- BR 32
  Price Date         AL 23  <- BR 33
  Coupon Type        AL 41  <- BR 23
  Valuta             AL 42  <- BR 20 (Bond Currency)

Uso:
  python populate_analisi_long.py --input file.xlsb
  python populate_analisi_long.py --input file.xlsx --mode preserve
  python populate_analisi_long.py --input file.xlsb --output out.xlsx \
      --br-sheet "Bond Results" --al-sheet "Analisi Long" --header-idx 3
"""

import argparse
import os
import sys
from datetime import datetime, timedelta

import openpyxl

# Mapping colonne (0-based): AL_idx -> ('etichetta', BR_idx, is_date)
COLUMN_MAP = [
    (22, "Final Coupon Date", 32, True),
    (23, "Price Date", 33, True),
    (41, "Coupon Type", 23, False),
    (42, "Valuta (Bond Currency)", 20, False),
]
CRITICAL_DATE_COLS = {22, 23}
MAX_COL = 51  # ampiezza minima riga da garantire


def parse_date(val):
    """Converte ISO string o serial Excel in oggetto datetime."""
    if val is None:
        return None
    if isinstance(val, str) and "T" in val:
        try:
            return datetime.strptime(val[:10], "%Y-%m-%d")
        except ValueError:
            return None
    if isinstance(val, (int, float)) and val > 30000:
        return datetime(1899, 12, 30) + timedelta(days=int(val))
    if isinstance(val, datetime):
        return val
    return None


def read_sheet(path, sheet_name):
    """Legge un foglio come lista di righe (liste di valori). Dispatch per estensione."""
    ext = os.path.splitext(path)[1].lower()
    rows = []
    if ext == ".xlsb":
        from pyxlsb import open_workbook  # import locale: serve solo per .xlsb
        with open_workbook(path) as wb:
            with wb.get_sheet(sheet_name) as sheet:
                for row in sheet.rows():
                    rows.append([c.v for c in row])
    elif ext in (".xlsx", ".xlsm"):
        wb = openpyxl.load_workbook(path, data_only=True)
        if sheet_name not in wb.sheetnames:
            raise ValueError(f"Foglio '{sheet_name}' assente. Disponibili: {wb.sheetnames}")
        ws = wb[sheet_name]
        for row in ws.iter_rows(values_only=True):
            rows.append(list(row))
    else:
        raise ValueError(f"Estensione non supportata: {ext} (usare .xlsb, .xlsx, .xlsm)")
    return rows


def build_rows(input_file, br_sheet, al_sheet, header_idx):
    """Costruisce le righe di Analisi Long popolate in memoria + log ISIN non matchati."""
    rows_br = read_sheet(input_file, br_sheet)
    rows_al = read_sheet(input_file, al_sheet)

    # Lookup Bond Results per ISIN (colonna 0)
    br_lookup = {row[0]: row for row in rows_br[1:] if row and row[0]}

    # Colonne data dall'header + colonne critiche
    header = rows_al[header_idx] if len(rows_al) > header_idx else []
    date_cols = {i for i, h in enumerate(header) if h and "date" in str(h).lower()}
    date_cols.update(CRITICAL_DATE_COLS)

    unmatched = []
    for r_idx, row in enumerate(rows_al):
        if r_idx <= header_idx or not row or row[0] is None:
            continue
        isin = row[1] if len(row) > 1 else None
        if not isin:
            continue
        if isin not in br_lookup:
            unmatched.append(isin)
            continue
        br = br_lookup[isin]
        while len(row) <= MAX_COL:
            row.append(None)
        # Popola solo se la cella e' vuota (non sovrascrive valori esistenti)
        for al_idx, _label, br_idx, is_date in COLUMN_MAP:
            if row[al_idx] is None:
                raw = br[br_idx] if len(br) > br_idx else None
                row[al_idx] = parse_date(raw) if is_date else raw
        # Converte tutte le date esistenti in datetime
        for col_i in date_cols:
            if col_i < len(row) and row[col_i] is not None and not isinstance(row[col_i], datetime):
                row[col_i] = parse_date(row[col_i])

    return rows_al, date_cols, unmatched


def write_rebuild(rows_al, date_cols, output_file, al_title="Analisi Long"):
    """Modalita' fedele al template: ricostruisce un workbook nuovo dai valori letti."""
    wb_out = openpyxl.Workbook()
    ws = wb_out.active
    ws.title = al_title
    for r_idx, row in enumerate(rows_al):
        for c_idx, val in enumerate(row):
            if val is None:
                continue
            cell = ws.cell(row=r_idx + 1, column=c_idx + 1)
            cell.value = val
            if c_idx in date_cols and isinstance(val, datetime):
                cell.number_format = "DD/MM/YYYY"
    wb_out.save(output_file)


def write_preserve(input_file, rows_al, date_cols, output_file, al_sheet, header_idx):
    """Modalita' preserve (solo .xlsx/.xlsm): scrive SOLO le celle target nel workbook
    esistente, lasciando intatte formule, stili e altri fogli."""
    ext = os.path.splitext(input_file)[1].lower()
    if ext not in (".xlsx", ".xlsm"):
        raise ValueError("--mode preserve richiede input .xlsx/.xlsm (le formule non esistono in .xlsb)")
    wb = openpyxl.load_workbook(input_file)  # data_only=False: preserva le formule
    ws = wb[al_sheet]
    target_cols = {al_idx for al_idx, _l, _b, _d in COLUMN_MAP}
    for r_idx, row in enumerate(rows_al):
        if r_idx <= header_idx or not row or row[0] is None:
            continue
        for c_idx in sorted(target_cols | date_cols):
            if c_idx >= len(row):
                continue
            val = row[c_idx]
            if val is None:
                continue
            cell = ws.cell(row=r_idx + 1, column=c_idx + 1)
            # Non toccare celle che contengono formule
            if isinstance(cell.value, str) and cell.value.startswith("="):
                continue
            cell.value = val
            if c_idx in date_cols and isinstance(val, datetime):
                cell.number_format = "DD/MM/YYYY"
    wb.save(output_file)


def verify(output_file):
    """Verifica finale obbligatoria: conta le colonne critiche popolate (1-based openpyxl)."""
    wb_v = openpyxl.load_workbook(output_file)
    ws_v = wb_v.active
    total = sum(1 for r in range(5, ws_v.max_row + 1) if ws_v.cell(row=r, column=1).value)
    print(f"Righe dati: {total}")
    for col_name, col_idx in [("Final Coupon Date", 23), ("Price Date", 24),
                              ("Coupon Type", 42), ("Valuta", 43)]:
        filled = sum(
            1 for r in range(5, ws_v.max_row + 1)
            if ws_v.cell(row=r, column=1).value and ws_v.cell(row=r, column=col_idx).value
        )
        print(f"{col_name}: {filled}/{total}")


def main():
    ap = argparse.ArgumentParser(description="Popola Analisi Long da Bond Results (join ISIN).")
    ap.add_argument("--input", required=True, help="File Excel sorgente (.xlsb/.xlsx/.xlsm)")
    ap.add_argument("--output", default=None, help="File di output (default: _Analisi_Long_Popolato.xlsx)")
    ap.add_argument("--br-sheet", default="Bond Results", help="Nome foglio Bond Results")
    ap.add_argument("--al-sheet", default="Analisi Long", help="Nome foglio Analisi Long")
    ap.add_argument("--header-idx", type=int, default=3, help="Indice 0-based della riga header in Analisi Long")
    ap.add_argument("--mode", choices=["rebuild", "preserve"], default="rebuild",
                    help="rebuild (fedele al template) | preserve (mantiene formule, solo .xlsx)")
    args = ap.parse_args()

    if not os.path.exists(args.input):
        print(f"ERRORE: file non trovato: {args.input}")
        sys.exit(1)

    output_file = args.output or (os.path.splitext(args.input)[0] + "_Analisi_Long_Popolato.xlsx")

    rows_al, date_cols, unmatched = build_rows(args.input, args.br_sheet, args.al_sheet, args.header_idx)

    if args.mode == "preserve":
        write_preserve(args.input, rows_al, date_cols, output_file, args.al_sheet, args.header_idx)
    else:
        write_rebuild(rows_al, date_cols, output_file)

    print(f"Salvato: {output_file} (modalita': {args.mode})")
    verify(output_file)
    if unmatched:
        print(f"ISIN non matchati in Bond Results ({len(unmatched)}): {', '.join(map(str, unmatched))}")
    else:
        print("Tutti gli ISIN di Analisi Long hanno corrispondenza in Bond Results.")


if __name__ == "__main__":
    main()
