#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
rejection_matrix.py — Engine REJECTION-MATRIX (rejection-matrix)

Genera/aggiorna il foglio 'Rejection Matrix' a partire dalle colonne
categoriche granulari del foglio 'Analisi' (Società non indipendente,
Società non finalizzata al profitto, Marchi/brevetti/intangibili,
Funzioni diverse, Funzioni ulteriori, Prodotti diversi, Prodotti ulteriori,
Altro) e dal Risultato Finale (Accettata/Rifiutata), consolidando le 8
categorie granulari nelle 5 colonne standard della Rejection Matrix:
Different Functions, Additional Functions, Different Products,
Additional Products, Other Reasons. Mapping verificato su template reale
di produzione (v1.2.0).

Mapping N:1 (R-RJ3):
  Funzioni diverse        -> Different Functions
  Funzioni ulteriori      -> Additional Functions
  Prodotti diversi        -> Different Products
  Prodotti ulteriori      -> Additional Products
  Non indipendente / Non finalizzata al profitto / Marchi-brevetti / Altro
                          -> Other Reasons (OR logico)

Include TUTTE le società di Analisi, accettate comprese (senza X - R-RJ1):
rispecchia il template reale osservato in produzione.

Uso:
  python rejection_matrix.py --source analisi_2024.xlsb --output rejection_matrix_2024.xlsx
  python rejection_matrix.py --source analisi_2024.xlsx --target template_vuoto.xlsx --in-place
"""

import argparse
import os
import re
import sys
import unicodedata

import openpyxl
from openpyxl.cell.cell import MergedCell

GRANULAR_COLUMNS = {
    "non_independent": ["societa non indipendente", "non independent"],
    "non_profit": ["non finalizzata al profitto", "not for profit", "non profit"],
    "trademarks": ["marchi brevetti", "marchi", "brevetti", "trademarks", "intangibili", "intangibles"],
    "diff_functions": ["funzioni diverse", "different functions"],
    "add_functions": ["funzioni ulteriori", "additional functions"],
    "diff_products": ["prodotti diversi", "different products"],
    "add_products": ["prodotti ulteriori", "additional products"],
    "other": ["altro", "other"],
}

# Mapping N:1 verso le 5 colonne standard della Rejection Matrix (R-RJ3).
BUCKET_MAP = {
    "Different Functions": ["diff_functions"],
    "Additional Functions": ["add_functions"],
    "Different Products": ["diff_products"],
    "Additional Products": ["add_products"],
    "Other Reasons": ["non_independent", "non_profit", "trademarks", "other"],
}
BUCKET_ORDER = ["Different Functions", "Additional Functions", "Different Products",
                "Additional Products", "Other Reasons"]
BUCKET_KEYWORDS = {
    "Different Functions": ["different functions", "funzioni diverse"],
    "Additional Functions": ["additional functions", "funzioni ulteriori"],
    "Different Products": ["different products", "prodotti diversi"],
    "Additional Products": ["additional products", "prodotti ulteriori"],
    "Other Reasons": ["other reasons", "altro", "other"],
}

RESULT_KEYWORDS = ["risultato finale", "final result"]
REJECTED_VALUES = {"rifiutata", "rigettata", "rejected", "rifiutato", "rigettato"}

HEADER_ANCHOR_KEYWORDS = (
    "company name", "company", "societa", "ragione sociale", "denominazione",
    "bvd id", "bvd", "bvd number", "risultato finale", "final result",
    "funzioni diverse", "funzioni ulteriori", "prodotti diversi", "prodotti ulteriori",
    "altro", "causa", "codice", "n",
)


def norm(s):
    """Normalizza un'intestazione: minuscolo, senza accenti, senza punteggiatura,
    spazi compressi. Lo strip degli accenti (es. 'Societa' non indipendente' con
    la a accentata -> 'societa non indipendente') evita mismatch silenziosi contro
    keyword ASCII quando l'header reale usa lettere accentate italiane."""
    if s is None:
        return ""
    s = str(s).lower().strip()
    s = "".join(c for c in unicodedata.normalize("NFKD", s) if not unicodedata.combining(c))
    s = re.sub(r"[^\w\s%]", " ", s, flags=re.UNICODE)
    s = re.sub(r"\s+", " ", s).strip()
    return s


def norm_key(s):
    """Chiave di join (Company Name): minuscolo, spazi compressi, suffissi societari rimossi."""
    s = norm(s)
    s = re.sub(r"\b(spa|s p a|srl|s r l|gmbh|ltd|plc|sa|s a|nv|n v|bv|b v|inc|llc|ag|sas|kg)\b", "", s)
    return re.sub(r"\s+", " ", s).strip()


def read_rows(path, sheet_name):
    """Legge un foglio come lista di righe (liste di valori). Dispatch per estensione
    (stesso pattern di populate_analisi_long.py): .xlsb via pyxlsb (sola lettura),
    .xlsx/.xlsm via openpyxl."""
    ext = os.path.splitext(path)[1].lower()
    rows = []
    if ext == ".xlsb":
        from pyxlsb import open_workbook
        with open_workbook(path) as wb:
            with wb.get_sheet(sheet_name) as sheet:
                for row in sheet.rows():
                    rows.append([c.v for c in row])
    elif ext in (".xlsx", ".xlsm"):
        wb = openpyxl.load_workbook(path, data_only=False, read_only=True)
        ws = wb[sheet_name]
        for row in ws.iter_rows(values_only=True):
            rows.append(list(row))
    else:
        raise ValueError(f"Estensione non supportata: {ext} (usare .xlsb, .xlsx, .xlsm)")
    return rows


def find_sheet_name(names, exact_lower, contains=None):
    for name in names:
        if name.strip().lower() in exact_lower:
            return name
    if contains:
        for name in names:
            if contains in name.strip().lower():
                return name
    return None


def find_header_row_in_rows(rows, max_scan=25):
    """Sceglie la riga (0-based) con piu' hit su keyword note di header; a parita'
    sceglie quella con piu' celle di testo (stessa euristica keyword-aware del
    fix v1.1.3, adattata a liste di valori grezzi invece che a un worksheet)."""
    best_idx, best_score, best_count = None, -1, 0
    for i, row in enumerate(rows[:max_scan]):
        texts = [str(v).strip() for v in row if isinstance(v, str) and v.strip()]
        if len(texts) < 2:
            continue
        normed = [norm(t) for t in texts]
        anchor_hits = sum(1 for kw in HEADER_ANCHOR_KEYWORDS if any(kw in t for t in normed))
        if anchor_hits > best_score or (anchor_hits == best_score and len(texts) > best_count):
            best_idx, best_score, best_count = i, anchor_hits, len(texts)
    return best_idx if best_idx is not None else 0


def header_map_from_row(row):
    out = {}
    for c_idx, val in enumerate(row):
        h = norm(val)
        if h and h not in out:
            out[h] = c_idx
    return out


def col_by_keywords(hmap, keywords):
    """Match esatto prima, poi fallback per sottostringa (stessa logica R-CF10)."""
    for kw in keywords:
        kw = norm(kw)
        if kw and kw in hmap:
            return hmap[kw]
    for kw in keywords:
        kw = norm(kw)
        for h, idx in hmap.items():
            if kw and kw in h:
                return idx
    return None


def is_formula(cell):
    return cell.data_type == "f" or (isinstance(cell.value, str) and cell.value.startswith("="))


def is_locked(cell):
    """Cella non scrivibile: formula o MergedCell non-anchor (stessa protezione
    anti-crash di carry_forward_analisi.py R-CF11)."""
    return is_formula(cell) or isinstance(cell, MergedCell)


def is_blank(cell):
    v = cell.value
    return v is None or (isinstance(v, str) and not v.strip())


def extract_companies(rows, header_idx):
    """Estrae per ogni societa': bvd, nome, rigettata (bool), bucket attivati (set).
    Una societa' rigettata puo' attivare piu' bucket contemporaneamente (R-RJ4)."""
    hmap = header_map_from_row(rows[header_idx])
    col_bvd = col_by_keywords(hmap, ["bvd id number", "bvd id", "bvd", "bvd number"])
    col_company = col_by_keywords(hmap, ["company name", "company", "ragione sociale", "societa", "denominazione"])
    col_result = col_by_keywords(hmap, RESULT_KEYWORDS)
    if not (col_bvd or col_company):
        return None, "Impossibile individuare Company Name / BvD ID nel foglio Analisi."
    if col_result is None:
        return None, "Impossibile individuare 'Risultato Finale' nel foglio Analisi."

    col_granular = {}
    for label, keywords in GRANULAR_COLUMNS.items():
        idx = col_by_keywords(hmap, keywords)
        if idx is not None:
            col_granular[label] = idx
    missing = [k for k in GRANULAR_COLUMNS if k not in col_granular]
    if missing:
        print(f"[ATTENZIONE] Colonne categoriche non trovate in Analisi (bucket collegati sempre vuoti): {', '.join(missing)}")

    companies = []
    for row in rows[header_idx + 1:]:
        if col_bvd is not None and col_bvd < len(row):
            bvd = row[col_bvd]
        else:
            bvd = None
        if col_company is not None and col_company < len(row):
            name = row[col_company]
        else:
            name = None
        if not bvd and not name:
            continue
        result_val = row[col_result] if col_result < len(row) else None
        rejected = bool(result_val) and norm(result_val) in REJECTED_VALUES

        buckets = set()
        if rejected:
            for bucket, labels in BUCKET_MAP.items():
                for label in labels:
                    idx = col_granular.get(label)
                    if idx is not None and idx < len(row):
                        v = row[idx]
                        if v is not None and str(v).strip():
                            buckets.add(bucket)
                            break
        companies.append({"bvd": str(bvd).strip() if bvd else None,
                           "name": str(name).strip() if name else None,
                           "rejected": rejected, "buckets": buckets})
    return companies, None


def find_rejection_sheet_layout(ws, max_scan=25):
    """Individua nel foglio Rejection Matrix la riga header dati (N./Company Name/BvD ID)
    e ricava le colonne dei 5 bucket standard scandendo le righe circostanti (la riga
    delle categorie di solito precede immediatamente l'header dati, ma la ricerca e'
    fatta su una finestra per robustezza contro template con layout leggermente diverso)."""
    rows_vals = [[c.value for c in ws[r]] for r in range(1, min(max_scan, ws.max_row) + 1)]
    hdr_idx0 = find_header_row_in_rows(rows_vals, max_scan=max_scan)
    header_row = hdr_idx0 + 1  # 1-based per openpyxl

    hmap = header_map_from_row(rows_vals[hdr_idx0])
    col_bvd = col_by_keywords(hmap, ["bvd id number", "bvd id", "bvd", "bvd number"])
    col_company = col_by_keywords(hmap, ["company name", "company", "ragione sociale", "societa", "denominazione"])
    col_n = col_by_keywords(hmap, ["n"])

    bucket_cols = {}
    window = range(max(0, hdr_idx0 - 3), min(len(rows_vals), hdr_idx0 + 1))
    for i in window:
        hmap_i = header_map_from_row(rows_vals[i])
        for bucket, keywords in BUCKET_KEYWORDS.items():
            if bucket in bucket_cols:
                continue
            idx = col_by_keywords(hmap_i, keywords)
            if idx is not None:
                bucket_cols[bucket] = idx + 1  # 1-based

    return header_row, (col_bvd + 1 if col_bvd is not None else None), \
        (col_company + 1 if col_company is not None else None), \
        (col_n + 1 if col_n is not None else None), bucket_cols


def build_lookup(ws, header_row, col_bvd, col_company):
    by_bvd, by_name = {}, {}
    for r in range(header_row + 1, ws.max_row + 1):
        bvd = ws.cell(row=r, column=col_bvd).value if col_bvd else None
        name = ws.cell(row=r, column=col_company).value if col_company else None
        if bvd and str(bvd).strip():
            by_bvd[str(bvd).strip().upper()] = r
        if name and str(name).strip():
            by_name[norm_key(name)] = r
    return by_bvd, by_name


def fill_existing_target(wb_tgt, sheet_name, companies):
    ws = wb_tgt[sheet_name]
    header_row, col_bvd, col_company, col_n, bucket_cols = find_rejection_sheet_layout(ws)
    if not (col_bvd or col_company):
        print("ERRORE: impossibile individuare Company Name / BvD ID nel foglio Rejection Matrix target.")
        sys.exit(1)
    missing_buckets = [b for b in BUCKET_ORDER if b not in bucket_cols]
    if missing_buckets:
        print(f"[ATTENZIONE] Colonne bucket non trovate nella Rejection Matrix target: {', '.join(missing_buckets)}")

    by_bvd, by_name = build_lookup(ws, header_row, col_bvd, col_company)
    written_x = skipped_locked = appended = 0
    next_row = ws.max_row + 1
    next_n = None
    if col_n:
        vals = [ws.cell(row=r, column=col_n).value for r in range(header_row + 1, ws.max_row + 1)]
        nums = [v for v in vals if isinstance(v, (int, float))]
        next_n = (max(nums) + 1) if nums else 1

    for comp in companies:
        tgt_row = None
        if comp["bvd"] and comp["bvd"].upper() in by_bvd:
            tgt_row = by_bvd[comp["bvd"].upper()]
        elif comp["name"] and norm_key(comp["name"]) in by_name:
            tgt_row = by_name[norm_key(comp["name"])]

        if tgt_row is None:
            # Societa' assente dal template esistente: aggiunta in coda (R-RJ8),
            # mai scartata in silenzio.
            tgt_row = next_row
            next_row += 1
            appended += 1
            if col_n:
                ws.cell(row=tgt_row, column=col_n).value = next_n
                next_n += 1
            if col_company:
                ws.cell(row=tgt_row, column=col_company).value = comp["name"]
            if col_bvd:
                ws.cell(row=tgt_row, column=col_bvd).value = comp["bvd"]

        if not comp["rejected"]:
            continue
        for bucket in comp["buckets"]:
            col = bucket_cols.get(bucket)
            if not col:
                continue
            cell = ws.cell(row=tgt_row, column=col)
            if is_locked(cell):
                skipped_locked += 1
                continue
            if is_blank(cell):
                cell.value = "X"
                written_x += 1
    return written_x, skipped_locked, appended


def build_fresh_sheet(wb_out, companies):
    ws = wb_out.create_sheet("Rejection Matrix")
    ws.cell(row=2, column=2, value="Reject Matrix of the Comparable Companies")
    for i, bucket in enumerate(BUCKET_ORDER):
        ws.cell(row=3, column=5 + i, value=bucket)
    ws.cell(row=4, column=2, value="N.")
    ws.cell(row=4, column=3, value="Company Name")
    ws.cell(row=4, column=4, value="BvD ID number")

    written_x = 0
    for i, comp in enumerate(companies, start=1):
        r = 4 + i
        ws.cell(row=r, column=2, value=i)
        ws.cell(row=r, column=3, value=comp["name"])
        ws.cell(row=r, column=4, value=comp["bvd"])
        if comp["rejected"]:
            for bucket in comp["buckets"]:
                col = 5 + BUCKET_ORDER.index(bucket)
                ws.cell(row=r, column=col, value="X")
                written_x += 1
    return written_x


def main():
    ap = argparse.ArgumentParser(
        description="Genera/aggiorna il foglio Rejection Matrix da Analisi (colonne categoriche -> 5 bucket)."
    )
    ap.add_argument("--source", required=True, help="File Excel con foglio Analisi (.xlsb/.xlsx/.xlsm, sola lettura)")
    ap.add_argument("--analisi-sheet", default=None, help="Forza il nome del foglio Analisi")
    ap.add_argument("--target", default=None,
                    help="File .xlsx/.xlsm con foglio Rejection Matrix esistente da completare "
                         "(se omesso: crea un nuovo foglio da zero nell'output)")
    ap.add_argument("--rejection-sheet", default=None, help="Forza il nome del foglio Rejection Matrix nel target")
    ap.add_argument("--output", default=None, help="Output (default: <source>_RejectionMatrix.xlsx)")
    ap.add_argument("--in-place", action="store_true", help="Sovrascrive --target invece di creare un nuovo file")
    args = ap.parse_args()

    if not os.path.exists(args.source):
        print(f"ERRORE: file sorgente non trovato: {args.source}")
        sys.exit(1)
    src_ext = os.path.splitext(args.source)[1].lower()
    if src_ext not in (".xlsb", ".xlsx", ".xlsm"):
        print(f"ERRORE: estensione sorgente non supportata: {src_ext} (usare .xlsb, .xlsx, .xlsm)")
        sys.exit(1)

    if src_ext == ".xlsb":
        with __import__("pyxlsb").open_workbook(args.source) as wb_probe:
            sheet_names = list(wb_probe.sheets)
    else:
        wb_probe = openpyxl.load_workbook(args.source, read_only=True)
        sheet_names = wb_probe.sheetnames

    analisi_name = args.analisi_sheet or find_sheet_name(sheet_names, ("analisi",), contains="analisi")
    if not analisi_name:
        print(f"ERRORE: foglio Analisi non trovato nella sorgente. Fogli disponibili: {sheet_names}")
        sys.exit(1)

    rows = read_rows(args.source, analisi_name)
    header_idx = find_header_row_in_rows(rows)
    companies, err = extract_companies(rows, header_idx)
    if err:
        print(f"ERRORE: {err}")
        sys.exit(1)

    n_rejected = sum(1 for c in companies if c["rejected"])
    bucket_counts = {b: 0 for b in BUCKET_ORDER}
    for c in companies:
        for b in c["buckets"]:
            bucket_counts[b] += 1

    if args.target:
        if not os.path.exists(args.target):
            print(f"ERRORE: file target non trovato: {args.target}")
            sys.exit(1)
        tgt_ext = os.path.splitext(args.target)[1].lower()
        if tgt_ext not in (".xlsx", ".xlsm"):
            print(f"ERRORE: --target deve essere .xlsx/.xlsm (necessario per scrivere): {args.target}")
            sys.exit(1)
        wb_tgt = openpyxl.load_workbook(args.target, data_only=False, keep_vba=(tgt_ext == ".xlsm"))
        rej_name = args.rejection_sheet or find_sheet_name(wb_tgt.sheetnames, ("rejection matrix",), contains="rejection")
        if not rej_name:
            print(f"ERRORE: foglio Rejection Matrix non trovato nel target. Fogli disponibili: {wb_tgt.sheetnames}")
            sys.exit(1)
        written_x, skipped_locked, appended = fill_existing_target(wb_tgt, rej_name, companies)
        tgt_base, tgt_ext2 = os.path.splitext(args.target)
        output_file = args.target if args.in_place else (args.output or (tgt_base + "_RejectionMatrix" + tgt_ext2))
        wb_tgt.save(output_file)
        mode_msg = f"aggiornato foglio esistente '{rej_name}'"
    else:
        wb_out = openpyxl.Workbook()
        wb_out.remove(wb_out.active)
        written_x = build_fresh_sheet(wb_out, companies)
        skipped_locked = appended = 0
        src_base = os.path.splitext(args.source)[0]
        output_file = args.output or (src_base + "_RejectionMatrix.xlsx")
        wb_out.save(output_file)
        mode_msg = "creato nuovo foglio da zero"

    print("=== rejection_matrix.py — riepilogo ===")
    print(f"Sorgente: '{args.source}' foglio '{analisi_name}' (header riga {header_idx + 1})")
    print(f"Modalita': {mode_msg}")
    print(f"Societa' totali: {len(companies)} | rigettate: {n_rejected} | accettate: {len(companies) - n_rejected}")
    print("Distribuzione per bucket:")
    for b in BUCKET_ORDER:
        print(f"  {b}: {bucket_counts[b]}")
    print(f"Celle X scritte: {written_x} | saltate perche' locked (formula/merged): {skipped_locked}")
    if appended:
        print(f"[ATTENZIONE] {appended} societa' assenti dal template Rejection Matrix, aggiunte in coda (R-RJ8).")
    print(f"Salvato: {output_file}")


if __name__ == "__main__":
    main()
