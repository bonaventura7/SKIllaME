# Quality Gates

A package may be called final only if all gates pass.

## Gate 1 - Structural integrity
- Valid ZIP archive
- Single skill folder at top level
- `SKILL.md` present at skill folder root

## Gate 2 - Skill format
- YAML frontmatter at file start
- Required keys: `name`, `description`
- Description states what the skill does and when to use it

## Gate 3 - Content integrity
- No placeholders
- No claims beyond verified scope
- No contradictory inventory counts

## Gate 4 - Operational clarity
- Import instructions included
- Gaps or assumptions declared
- Artifact names stable and ASCII-safe
