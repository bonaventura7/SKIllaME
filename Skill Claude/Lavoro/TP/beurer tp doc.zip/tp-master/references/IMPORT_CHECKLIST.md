# Import Checklist

## Claude app upload

1. Open Claude.
2. Ensure Code execution and file creation is enabled.
3. Go to Customize > Skills.
4. Create or upload a skill.
5. Upload the ZIP file that contains the skill folder.
6. Verify the skill appears in the skills list.

## Claude Code global install

1. Create the folder `~/.claude/skills/tp-master/`.
2. Copy `SKILL.md` into that folder.
3. Optionally copy the `references/` folder.
4. Restart or refresh if your environment requires it.

## Acceptance checks

- `SKILL.md` exists at the skill root.
- YAML frontmatter is the first block in the file.
- `name` and `description` are present.
- ZIP opens without errors.
- No placeholder text remains.
