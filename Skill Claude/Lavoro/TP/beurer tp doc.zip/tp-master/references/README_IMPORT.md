# TP Master Claude Skill - Import Package

This package is the definitive Claude custom skill bundle generated from the verified request scope.

## Included artifacts
- `SKILL.md`
- `references/IMPORT_CHECKLIST.md`
- `references/QUALITY_GATES.md`
- `references/TP_MASTER_SPEC.md`

## Scope note
This ZIP is a Claude skill import package. It is not presented as the complete 20-file runtime script package, because several referenced files were not fully included in the provided prompt.

## Recommended use
Use this package when you want Claude to reliably handle TP Master archive analysis, yearly setup, packaging, and validation requests.
