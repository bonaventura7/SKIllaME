# TP Master v4.2 Production Hardened - Verified Spec Snapshot

This reference captures the verified information supplied in the request.
It is intentionally conservative and does not invent missing file bodies.

## Declared package inventory

The request declares a 20-file package with this index:

1. SKILL.md
2. Run-Master.ps1
3. 01_Scan.ps1
4. 02_Classifica.ps1
5. 03_Relazioni.ps1
6. 04_LogicaCompilazione.ps1
7. 05_GeneraMappa.ps1
8. 06_Fix_Classificazione.ps1
9. 07_Standardizza_Naming.ps1
10. 08_Fix_Cartelle.ps1
11. New-TPYear.ps1
12. New-DNTemplate.ps1
13. generate-dn.js
14. Build-Allegati.ps1
15. setup.ps1
16. Test-TPMaster.ps1
17. package.json
18. MANIFEST.json
19. README_IMPORT.md
20. CHANGELOG_v4.2.md

## Verified full file bodies present in the request

The following files were fully present in the request text and can be treated as verified source material:
- 01_Scan.ps1
- 03_Relazioni.ps1
- 04_LogicaCompilazione.ps1
- 05_GeneraMappa.ps1
- 06_Fix_Classificazione.ps1
- 07_Standardizza_Naming.ps1
- 08_Fix_Cartelle.ps1
- New-TPYear.ps1
- New-DNTemplate.ps1
- Build-Allegati.ps1
- package.json
- README_IMPORT.md
- partial updated setup.ps1

## Referenced but not fully included in the request body

The request explicitly says these were provided elsewhere and were not repeated in full in the current prompt:
- SKILL.md
- Run-Master.ps1
- 02_Classifica.ps1
- generate-dn.js
- Test-TPMaster.ps1
- MANIFEST.json
- CHANGELOG_v4.2.md

## Safe interpretation rule

If asked to produce a final runtime package from only the current prompt, do not claim the omitted files are verified. Either:
- request those omitted files, or
- build a verified partial package plus a gap report.

## Packaging objective

For Claude import, the minimum valid package is a ZIP containing a skill folder with `SKILL.md` at the folder root.
