---
name: tp-italy-law-review
version: "3.2"
description: >
  Skill specializzato per l'aggiornamento del capitolo Transfer Pricing Italy
  per Lexology In-Depth 2026. Gestisce l'intero workflow: classificazione
  materiale, inserimento conservativo, condensazione smart, validazione word
  count (4.800-5.000 parole corpo), diagnostica automatica, verifica integrità,
  riparazione errori, e generazione output conforme allo stile editoriale
  Lexology (British English, minimal capitalisation, no boldface).

  PERIODO DI RIFERIMENTO: 31 March 2025 – 22 April 2026
  VERSIONE OCSE RIFERIMENTO: 2022 (con aggiornamenti 2025 Model Tax Convention)

  TRIGGER: quando l'utente menziona "transfer pricing", "Lexology",
  "aggiornamento libro", "TP Italy", "inserimento materiale", "condensazione",
  "word count", "verifica", "diagnostica", "check", "ripara", "fonti",
  o fornisce nuove fonti giuridiche (sentenze, circolari, decreti, articoli).

  DO NOT USE per: generale consulenza fiscale non-TP, redazione contratti,
  calcoli matematici non correlati al word count.

author: Senior Solutions Architect
license: Proprietary
---

# Transfer Pricing Italy — Law Review Skill v3.2

## 🎯 OBIETTIVO
Aggiornare il capitolo Transfer Pricing: Italy per Lexology In-Depth 2026,
mantenendo la struttura editoriale esistente, intervenendo solo se strettamente
necessario per coerenza logica o rispetto del vincolo word count
(4.800–5.000 parole corpo, escluse footnotes).

## 📅 PERIODO DI RIFERIMENTO
31 March 2025 – 22 April 2026. Fonti anteriori ammesse solo come presupposti
normativi o contesto consolidato, con flag esplicito [pre-dating review period].

## 🔄 WORKFLOW PRINCIPALE
ADD → VALIDATE → CONDENSE → SYNTHESIZE → VERIFY → REPAIR

## 🆕 NOVITÀ VERSIONE 3.2
- Periodo di riferimento esplicitato con regole di ammissibilità legacy
- Mappatura fonti 42+ con stato integrazione/mancante
- Sezione "Tax challenges arising from digitalisation" ora obbligatoria
- Gestione secondary adjustments (Lagrutta/Miele, Corriere Tributario 4/2026)
- Interpello 214/2025 e AG Kokott Stellantis per IVA/TP
- Nuovo Patent Box (D.L. 146/2021, efficace 1 January 2026)
- CFC rules aggiornate (D.L. 84/2025)
- MEMAP 2026 e best practices MAP
- Provvedimento 46523/2026 (dichiarazione GMT)
- Cass. 7169/2026, 5753/2026, 18714/2025, 29083/2025
- CGT Milano 3213/2025, CGT Lombardia 2401/2025

---

## 1️⃣ CLASSIFICAZIONE INTELLIGENTE

INPUT: Materiale grezzo (circolare, sentenza, aggiornamento normativo)
↓
[Keyword Engine + Context Analysis]
↓
OUTPUT:
  • Target section: [nome sezione]
  • Priority: [high/medium/low]
  • Action: [append / replace snippet / merge]

**Mappatura sezioni-guidance aggiornata:**
| Materiale | Sezione Target | Priority |
|---|---|---|
| Sentenze Cassazione/CGT 2025-2026 | Recent cases | HIGH |
| Pillar Two, DST, CFC (D.L. 84/2025) | Tax challenges / Broader taxation | HIGH |
| CbCR, TSH, compliance documentation | Filing requirements | MEDIUM |
| IVA adjustments, AG Kokott, cash pooling | Consequential impact | MEDIUM |
| Finanziamenti infruttiferi, tassi zero | Special considerations / Recent cases | MEDIUM |
| DEMPE, royalty, patent box (nuovo regime) | Intangible assets | LOW |
| Management fees, benefit test | Investigations / Presenting the case | LOW |
| MEMAP 2026, MAP updates | Double taxation | LOW |
| Secondary adjustments (Lagrutta/Miele) | Secondary adjustment and penalties | HIGH |
| GMT dichiarazione (Provv. 46523/2026) | Tax challenges / Filing requirements | MEDIUM |

---

## 2️⃣ INSERIMENTO CONSERVATIVO (Default: APPEND)

**Regola base:** INSERISCI dopo l'ultimo paragrafo "body" della sezione target.

**Eccezioni:**
• Se il nuovo contenuto contraddice testo esistente → FLAG per revisione
• Se la sezione è vuota → inserisci come primo body
• Se l'inserimento rompe il flusso logico → suggerisci riordino minimale

**Regole periodo di riferimento:**
- Fonti nel periodo 31 March 2025 – 22 April 2026: inserimento standard
- Fonti anteriori al periodo:
  a) Presupposto normativo vigente → inserisci con nota [pre-dating review period]
  b) Giurisprudenza consolidata → citabile per contesto, non come "recent case"
  c) Posizione ufficiale non modificata → aggiorna solo se necessario

---

## 3️⃣ GUARDRAIL WORD COUNT + CONDENSATION SMART

```
IF body_words > 5000 AFTER insertion:
  ↓
  [Condensation Engine]
  • Rimuovi SOLO: connettivi ridondanti
  • Mantieni SEMPRE: citazioni, articoli di legge, date, numeri di sentenza
  • Priorità: paragrafi > 40 parole, non tecnici, descrittivi
  ↓
  Report: "Condensed X words in section [Y], saved Z words"
```

**Strategia di condensazione per sezione (fattori v3.2):**
- **Introduction**: 12% condensabile (rimuovi ripetizioni procedurali)
- **Year in review**: 8% (mantieni sviluppi recenti)
- **Filing requirements**: 10% (condensa descrizione master file)
- **Double taxation**: 25% (condensa confronto procedure)
- **Broader taxation issues**: 15% (sintetizza misure supplementari)
- **Settlements**: 10% (condensa procedural detail ripetuto)
- **Acknowledgements**: 30% (riduci a paragrafo formale ~50 parole)
- **Recent cases**: 3% (NON condensare)
- **Pricing methods**: 5% (NON condensare)

---

## 4️⃣ COERENZA LOGICA POST-INSERT (Validation Hook)

```
After insertion, run quick logic check:
  • [✓] No duplicate content in same section
  • [✓] Chronological order preserved (case law by date)
  • [✓] Cross-references still valid
  • [✓] Terminology consistent ("ITA" vs "Revenue Agency")
  • [✓] No contradictions with existing text
  • [✓] Periodo di riferimento rispettato
  ↓
  If ANY check fails → FLAG for user review + suggest minimal fix
```

---

## 🔬 5️⃣ DIAGNOSTICA AUTOMATICA (Health Check)

**Esegui SEMPRE prima e dopo ogni operazione.**

### 5.1 Pre-Flight Check
```
□ Verifica struttura: tutte le sezioni presenti?
□ Verifica word count baseline: corpo tra 4.800-5.000?
□ Verifica footnotes: separate dal corpo? Non conteggiate?
□ Verifica fonti: quali fonti sono già integrate? Quali mancano?
□ Verifica coerenza terminologica: "ITA" usato consistentemente?
□ Verifica periodo: nessuna fonte anteriore al 31 March 2025 senza flag?
```

### 5.2 Post-Flight Check
```
□ Word count finale: 4.800 ≤ corpo ≤ 5.000?
□ Sezioni non vuote: tutte le sezioni obbligatorie hanno contenuto?
  - Required: Introduction, Year in review, Outlook and conclusions
  - Recommended: Recent cases, Filing requirements, Pricing methods
□ Cross-references valide
□ Ordine cronologico: sentenze in ordine crescente
□ Footnotes: tutte hanno un marker nel corpo?
□ British English: nessuna parola in American English?
□ No boldface
□ No invented content
□ Date format: "1 January 2025" (no virgole)
□ Virgolette doppie
□ Footnote markers dopo la punteggiatura
```

### 5.3 Fonti Check
```
□ Lista fonti caricate: leggi /references/fonti_*.txt
□ Confronta con fonti già integrate nel libro
□ Identifica fonti NUOVE da integrare
□ Identifica fonti OBSOLETE
□ Verifica che il numero di fonti non sia fisso a 42 — può variare
```

**Output diagnostico:**
```
[DIAGNOSTICS]
  • Sections present: 18/18 ✓
  • Body words: 4.961 ✓
  • Footnotes: 70 (excluded) ✓
  • British English check: ✓ PASS
  • No boldface check: ✓ PASS
  • Chronological order: ✓ PASS
  • Cross-references: ✓ PASS
  • Fonti totali nel progetto: 47
  • Fonti già integrate: 38
  • Fonti da integrare: 9
  • Fonti obsolete: 2
  • Periodo check: ✓ PASS
  • Overall health: ✅ HEALTHY
```

---

## 🔧 6️⃣ RIPARAZIONE AUTOMATICA (Auto-Repair)

### 6.1 Word Count Overflow (> 5.000)
```
STEP 1: Identifica sezioni più lunghe (> 400 parole)
STEP 2: Per ogni sezione, applica fattore di condensabilità
STEP 3: Rimuovi connettivi ridondanti:
  - "Furthermore," → ""
  - "In addition," → ""
  - "It is worth noting that" → ""
  - "As a general rule," → ""
  - "However," → "" (solo se non cambia senso logico)
STEP 4: Comprimi frasi di raccordo
STEP 5: Ricalcola word count
STEP 6: Se ancora > 5.000, sposta contenuto non-essenziale in Special considerations
```

### 6.2 Word Count Underflow (< 4.800)
```
STEP 1: Identifica sezioni più corte (< 150 parole)
STEP 2: Verifica fonti non integrate pertinenti
STEP 3: Aggiungi dettagli mancanti dalle fonti
STEP 4: Espandi Special considerations con materiale tematico
STEP 5: Ricalcola word count
```

### 6.3 Sezione Vuota Non Autorizzata
```
Se una sezione required è vuota:
  - Introduction: overview regime TP italiano (Art. 110 TUIR, OECD)
  - Year in review: riepilogo sviluppi ultimi 12 mesi
  - Outlook and conclusions: riepilogo temi salienti + previsioni
```

### 6.4 Contraddizioni Rilevate
```
Se nuovo materiale contraddice testo esistente:
  - FLAG il conflitto
  - Non sovrascrivere automaticamente
  - Presenta opzioni:
    a) Mantieni testo esistente
    b) Sostituisci con nuovo, sposta vecchio in nota
    c) Riscrivi entrambi per coerenza
```

### 6.5 Cross-Reference Rotte
```
Se un riferimento interno è invalido:
  - Identifica target mancante o spostato
  - Aggiorna il riferimento
  - Se target non esiste più, rimuovi il riferimento
```

---

## 🧭 DECISION TREE — "MODIFICO O NO?"

```
Nuovo materiale ricevuto
        │
        ▼
[Esegui PRE-FLIGHT CHECK]
        │
        ▼
[È pertinente a una sezione esistente?]
        ├── NO → Chiedi: "Creare nuova sezione o scartare?"
        │
        ▼ SI
[Il contenuto è nel periodo di riferimento?]
        ├── NO → Verifica se ammissibile come presupposto/legacy
        │
        ▼ SI / AMMISSIBILE
[Il contenuto è complementare o contraddittorio?]
        ├── CONTRADDITTORIO → FLAG: "Revisione necessaria"
        │                    → Attiva Auto-Repair 6.4
        │
        ▼ COMPLEMENTARE
[Inserimento fa superare 5000 parole?]
        ├── SI → Attiva Condensation Engine
        │      → Se ancora sopra, attiva Auto-Repair 6.1
        │
        ▼ NO
[Inserimento fa scendere sotto 4800?]
        ├── SI → Attiva Auto-Repair 6.2
        │
        ▼ NO
[Inserimento rompe coerenza logica?]
        ├── SI → Suggerisci minimal rewrite
        │      → Attiva Auto-Repair 6.5
        │
        ▼ NO
✓ Inserisci → Esegui POST-FLIGHT CHECK → Report
```

---

## 📦 OUTPUT FORMAT

```
[DIAGNOSTICS — PRE-FLIGHT]
  • Sections: 18/18 ✓
  • Body words: 4.961 (target: 4.800-5.000) ✓
  • Footnotes: 70 (excluded) ✓
  • Fonti nel progetto: 47 totali
  • Fonti integrate: 38
  • Fonti da aggiornare: 9

[CLASSIFICATION]
  • Topic: [es. Pillar Two implementation]
  • Target: [Tax challenges arising from digitalisation]
  • Action: [append after last body para]
  • Priority: [high]

[INSERTION]
  • Location: Section "X", after "[first 8 words...]"
  • New text: "[exact inserted snippet]"
  • Words added: +45

[VALIDATION — POST-FLIGHT]
  • Word count: 4.961 → 5.006 (+45) | Status: OVERFLOW
  • Coherence check: ✓ No conflicts

[CONDENSATION — AUTO-REPAIR 6.1]
  • Removed: "Furthermore, it is worth noting that..." → saved 12 words
  • Section affected: Introduction
  • Final word count: 4.986 ✓

[DIAGNOSTICS — FINAL]
  • Overall health: ✅ HEALTHY
  • All checks: PASS

[FILE]
  • Saved: Libro_UpdatedV2026.txt
  • Diff available

Next: Send more material / "finalize" / "synthesize" / "diagnostica"
```

---

## 🛡️ PRINCIPI NON NEGOZIABILI (Hard Constraints)

| Regola | Motivazione |
|--------|-------------|
| ✅ Mai inventare norme, sentenze o posizioni ufficiali | Integrità legale |
| ✅ Mai riscrivere intere sezioni senza esplicita richiesta | Rispetto struttura |
| ✅ Condensare SOLO prose ridondanti, MAI contenuto tecnico | Preservare valore |
| ✅ Segnalare SEMPRE modifiche che impattano coerenza | Trasparenza |
| ✅ Mantenere British English, stile Normal, no bold | Conformità Lexology |
| ✅ Footnotes escluse dal conteggio | Compliance editoriale |
| ✅ Eseguire SEMPRE diagnostica pre e post | Qualità assicurata |
| ✅ Verificare SEMPRE fonti — il numero può variare | Integrità contenuto |
| ✅ Periodo di riferimento 31 March 2025 – 22 April 2026 | Attualità contenuto |
| ✅ Secondary adjustments: citare Lagrutta/Miele | Completezza tecnica |
| ✅ Tax challenges: coprire Pillar One/Two, DST, CFC | Completezza guidance |

---

## 📚 REFERENCE MATERIALS

Vedi cartella `/references/` per:
- `lexology_guidance.txt` — Editorial guidance e heading structure
- `libro_baseline.txt` — Libro TP Italy originale (baseline)
- `fonti_42_tabella.txt` — Tabella riepilogativa fonti (può variare)

---

## 🚀 INVOCAZIONE

**Modalità standard:**
```
"Aggiorna il libro con questo materiale: [incolla]"
→ Esegue: Classifica → Insert → Validate → Condense → Verify → Report
```

**Modalità diagnostica:**
```
"Diagnostica" / "Health check" / "Verifica libro"
→ Esegue: Full diagnostics → Report stato → Suggerimenti
```

**Modalità riparazione:**
```
"Ripara word count" / "Sistema overflow" / "Condensa sezione X"
→ Esegue: Identifica problema → Auto-Repair → Verify → Report
```

**Modalità dry-run:**
```
"dry-run: [materiale]"
→ Mostra output simulato senza modificare il file
```

**Modalità fonti:**
```
"Controlla fonti" / "Quali fonti mancano?"
→ Esegue: Scan references → Confronta con libro → Report gap
```
