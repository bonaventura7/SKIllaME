# Transfer Pricing Italy — Claude Skill v3.2

## Novità v3.2
- Periodo di riferimento: 31 March 2025 – 22 April 2026
- Mappatura fonti 42+ con stato integrazione/mancante
- Sezione "Tax challenges arising from digitalisation" obbligatoria
- Gestione secondary adjustments (Lagrutta/Miele)
- Interpello 214/2025, AG Kokott Stellantis
- Nuovo Patent Box (D.L. 146/2021), CFC aggiornate (D.L. 84/2025)
- MEMAP 2026, Provvedimento 46523/2026 (dichiarazione GMT)
- Giurisprudenza 2025-2026: Cass. 7169/2026, 5753/2026, 18714/2025, 29083/2025
- Script validate_book.py e auto_repair.py completamente funzionanti

## Installazione

### Claude.ai (Web)
1. Settings → Capabilities → Skills
2. Upload Skill → seleziona `tp-italy-law-review-v32.zip`
3. Attiva lo skill nel progetto

### Claude Code (CLI)
```bash
mkdir -p ~/.claude/skills
cd ~/.claude/skills
unzip /path/to/tp-italy-law-review-v32.zip
mv tp-italy-law-review-v32 tp-italy-law-review
```

## Uso

### Aggiornamento standard
```
"Aggiorna il libro con questo materiale: [incolla]"
```

### Diagnostica
```
"Diagnostica" / "Health check" / "Verifica libro"
```

### Riparazione
```
"Ripara word count" / "Sistema overflow"
```

### Controllo fonti
```
"Controlla fonti" / "Quali fonti mancano?"
```

### Dry-run (simulazione)
```
"dry-run: [materiale]"
```

## Struttura

```
tp-italy-law-review/
├── SKILL.md                    # Istruzioni principali v3.2
├── README.md                   # Questo file
├── scripts/
│   ├── validate_book.py        # Diagnostica completa (fonti, BE, bold, date, cronologia)
│   └── auto_repair.py          # Riparazione automatica (condensazione selettiva per sezione)
├── references/
│   ├── lexology_guidance.txt   # Guidance editoriale Lexology
│   ├── libro_baseline.txt      # Libro originale (baseline)
│   └── fonti_42_tabella.txt   # Tabella fonti (variabile)
└── assets/                     # Template e risorse
```

## Workflow

```
ADD → VALIDATE → CONDENSE → SYNTHESIZE → VERIFY → REPAIR
```

## Target Word Count

- **Corpo**: 4.800 – 5.000 parole (escluse footnotes)
- **Footnotes**: separate, non conteggiate

## Periodo di Riferimento

31 March 2025 – 22 April 2026

Fonti anteriori ammesse solo come presupposti normativi o contesto consolidato,
con flag esplicito [pre-dating review period].

## Requisiti Script Python

```bash
# Nessuna dipendenza esterna — solo Python 3.8+
python scripts/validate_book.py references/libro_baseline.txt
python scripts/auto_repair.py references/libro_baseline.txt --target 4900
```

## Contatti

Senior Solutions Architect — Transfer Pricing Law Review
