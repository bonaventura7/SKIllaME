#!/usr/bin/env python3
"""
Script di riparazione automatica per il capitolo Transfer Pricing Italy v3.2.
Gestisce overflow, underflow, e problemi di stile.
Uso: python auto_repair.py <path_al_libro.txt> [--target 4900] [--mode condense|expand]
"""

import sys
import re
import argparse
from pathlib import Path

# Connettivi ridondanti per condensazione
CONDENSABLE_CONNECTORS = [
    (r'Furthermore,\s*', ''),
    (r'In addition,\s*', ''),
    (r'It is worth noting that\s*', ''),
    (r'As a general rule,\s*', ''),
    (r'However,\s*', ''),
    (r'Nevertheless,\s*', ''),
    (r'With regard to\s*', 'Regarding '),
    (r'In respect to\s*', 'Regarding '),
    (r'In respect of\s*', 'Regarding '),
    (r'It should be noted that\s*', ''),
    (r'It is important to highlight that\s*', ''),
    (r'As mentioned above,\s*', ''),
    (r'As previously stated,\s*', ''),
]

# Sezioni e loro fattore di condensabilità (0.0 = non toccare, 0.3 = condensabile)
SECTION_CONDENSABILITY = {
    "Introduction": 0.12,
    "Year in review": 0.08,
    "Filing requirements": 0.10,
    "Presenting the case": 0.05,
    "Pricing methods": 0.05,
    "Authority scrutiny and evidence gathering": 0.08,
    "Intangible assets": 0.08,
    "Settlements": 0.10,
    "Investigations": 0.10,
    "Litigation": 0.10,
    "Procedure": 0.10,
    "Recent cases": 0.03,
    "Secondary adjustment and penalties": 0.08,
    "Broader taxation issues": 0.15,
    "Tax challenges arising from digitalisation": 0.10,
    "Double taxation": 0.25,
    "Consequential impact for other taxes": 0.10,
    "Special considerations": 0.15,
    "Outlook and conclusions": 0.10,
    "Acknowledgements": 0.30,
}

KNOWN_SECTIONS = [
    "Transfer Pricing: Italy", "Introduction", "Year in review",
    "Filing requirements", "Presenting the case", "Pricing methods",
    "Authority scrutiny and evidence gathering", "Intangible assets",
    "Settlements", "Investigations", "Litigation", "Procedure",
    "Recent cases", "Secondary adjustment and penalties",
    "Broader taxation issues",
    "Diverted profits tax, digital sales taxes and other supplementary measures",
    "Tax challenges arising from digitalisation", "Double taxation",
    "Consequential impact for other taxes", "Special considerations",
    "Outlook and conclusions", "Acknowledgements"
]


def split_into_sections(text):
    """Divide il testo in sezioni."""
    lines = text.split('\n')
    sections = {}
    current_section = "Preamble"
    current_lines = []

    for line in lines:
        stripped = line.strip()
        is_header = False
        for sec in KNOWN_SECTIONS:
            if stripped.lower() == sec.lower():
                if current_lines:
                    sections[current_section] = '\n'.join(current_lines)
                current_section = sec
                current_lines = [line]
                is_header = True
                break
        if not is_header:
            current_lines.append(line)

    if current_lines:
        sections[current_section] = '\n'.join(current_lines)

    return sections


def condensa_sezione(text, target_reduction):
    """Condensa una singola sezione rimuovendo connettivi e ridondanze."""
    original_words = len(text.split())
    if original_words == 0 or target_reduction <= 0:
        return text, 0

    # Fase 1: rimuovi connettivi ridondanti
    saved = 0
    for pattern, replacement in CONDENSABLE_CONNECTORS:
        matches = re.findall(pattern, text, flags=re.IGNORECASE)
        for _ in matches:
            text = re.sub(pattern, replacement, text, count=1, flags=re.IGNORECASE)
            saved += len(_.split()) - len(replacement.split())

    # Fase 2: se ancora necessario, comprimi frasi ripetute
    if saved < target_reduction:
        # Rimuovi spazi multipli
        text = re.sub(r'\s+', ' ', text)
        # Sostituisci "; in particular," → ";"
        text = re.sub(r';\s*in particular,\s*', '; ', text)
        text = re.sub(r';\s*specifically,\s*', '; ', text)
        text = re.sub(r',\s*as well as\s*', ' and ', text)

    new_words = len(text.split())
    saved = original_words - new_words
    return text, max(0, saved)


def espandi_sezione(text, sezione_name, fonti_path='fonti_42_tabella.txt'):
    """Espande una sezione aggiungendo materiale dalle fonti disponibili."""
    # Stub avanzato: in uno scenario reale integrerebbe contenuto dalle fonti
    # Per ora restituisce hint su cosa aggiungere
    return text


def condensa_testo(text, target_reduction, verbose=False):
    """Condensa il testo globale con strategia sezione per sezione."""
    sections = split_into_sections(text)
    total_saved = 0
    report = []

    # Calcola parole per sezione
    section_words = {sec: len(content.split()) for sec, content in sections.items()}
    total_words = sum(section_words.values())

    # Distribuisci il target di riduzione proporzionalmente alla condensabilità
    for sec, content in sections.items():
        if sec not in SECTION_CONDENSABILITY:
            continue
        factor = SECTION_CONDENSABILITY[sec]
        sec_target = int(target_reduction * (section_words[sec] / total_words) * factor * 10)
        if sec_target < 5:
            continue

        new_content, saved = condensa_sezione(content, sec_target)
        if saved > 0:
            sections[sec] = new_content
            total_saved += saved
            report.append(f"  Condensed {saved} words in '{sec}'")

    # Ricostruisci testo
    result = []
    for sec in sections:
        result.append(sections[sec])

    return '\n'.join(result), total_saved, report


def espandi_testo(text, target_increase, fonti_path='fonti_42_tabella.txt'):
    """Espande il testo aggiungendo dettagli dalle fonti."""
    sections = split_into_sections(text)
    report = []

    # Identifica sezioni corte
    for sec, content in sections.items():
        words = len(content.split())
        if words < 150 and sec not in ["Acknowledgements", "Preamble"]:
            report.append(f"  Section '{sec}' is short ({words} words) — consider expanding")

    return text, 0, report


def main():
    parser = argparse.ArgumentParser(description='Auto-repair TP Italy book')
    parser.add_argument('filepath', help='Path to the book file')
    parser.add_argument('--target', type=int, default=4900, help='Target word count')
    parser.add_argument('--mode', choices=['condense', 'expand', 'auto'], default='auto',
                        help='Repair mode')
    parser.add_argument('--output', '-o', help='Output file path')
    args = parser.parse_args()

    with open(args.filepath, 'r', encoding='utf-8') as f:
        content = f.read()

    # Estrai corpo (semplificato)
    lines = content.split('\n')
    body_lines = [l for l in lines if l.strip() and not l.strip().startswith('^')]
    body_text = '\n'.join(body_lines)
    current_words = len(body_text.split())

    print(f"Current word count: {current_words}")
    print(f"Target: {args.target}")

    mode = args.mode
    if mode == 'auto':
        if current_words > args.target + 100:
            mode = 'condense'
        elif current_words < args.target - 100:
            mode = 'expand'
        else:
            mode = 'none'

    if mode == 'condense':
        overflow = current_words - args.target
        print(f"\n⚠️  OVERFLOW detected: {overflow} words over target")
        print("Activating Condensation Engine...")
        new_text, saved, report = condensa_testo(body_text, overflow, verbose=True)
        print(f"\nSaved {saved} words through condensation")
        for r in report:
            print(r)

        new_count = len(new_text.split())
        print(f"New word count: {new_count}")

        if new_count > args.target + 50:
            print("\n⚠️  Still over target. Additional condensation needed.")
            print("Consider moving content to Special considerations.")

    elif mode == 'expand':
        underflow = args.target - current_words
        print(f"\n⚠️  UNDERFLOW detected: {underflow} words under target")
        print("Activating Expansion Engine...")
        new_text, added, report = espandi_testo(body_text, underflow)
        for r in report:
            print(r)
        print("\nConsider adding more material from available sources.")
        new_count = len(new_text.split())
        print(f"New word count: {new_count}")

    else:
        print("\n✅ Word count within acceptable range. No repair needed.")
        new_text = body_text
        new_count = current_words

    # Salva output
    if args.output:
        with open(args.output, 'w', encoding='utf-8') as f:
            f.write(new_text)
        print(f"\n💾 Saved to: {args.output}")

    print(f"\nFinal word count: {new_count}")
    return 0


if __name__ == '__main__':
    sys.exit(main())
