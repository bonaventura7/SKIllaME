#!/usr/bin/env python3
"""
Script di validazione per il capitolo Transfer Pricing Italy v3.2.
Esegue diagnostica completa: word count, struttura, coerenza, fonti, British English.
Uso: python validate_book.py <path_al_libro.txt> [--fonti fonti_42_tabella.txt]
"""

import sys
import re
import argparse
from pathlib import Path
from collections import defaultdict

# Dizionario American English → British English
AMERICANISMS = {
    'organization': 'organisation',
    'center': 'centre',
    'behavior': 'behaviour',
    'color': 'colour',
    'analyze': 'analyse',
    'analyzing': 'analysing',
    'analyzed': 'analysed',
    'license': 'licence',
    'practice': 'practise',
    'program': 'programme',
    'traveled': 'travelled',
    'travelling': 'travelling',
    'labeled': 'labelled',
    'modeling': 'modelling',
    'fulfill': 'fulfil',
    'defense': 'defence',
    'offense': 'offence',
}

KNOWN_SECTIONS = [
    "Transfer Pricing: Italy", "Introduction", "Year in review",
    "Filing requirements", "Presenting the case", "Pricing methods",
    "Authority scrutiny and evidence gathering", "Intangible assets",
    "Settlements", "Investigations", "Litigation", "Procedure",
    "Recent cases", "Secondary adjustment and penalties",
    "Broader taxation issues",
    "Diverted profits tax, digital sales taxes and other supplementary measures",
    "Tax challenges arising from digitalisation", "Double taxation",
    "Consequential impact for other taxes", "Special considerations",
    "Outlook and conclusions", "Acknowledgements"
]

REQUIRED_SECTIONS = ["Introduction", "Year in review", "Outlook and conclusions"]
RECOMMENDED_SECTIONS = ["Recent cases", "Filing requirements", "Pricing methods"]


def extract_body_and_footnotes(filepath):
    """Separa corpo e footnotes dal file."""
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()

    lines = content.split('\n')
    body_lines = []
    footnote_lines = []

    for line in lines:
        stripped = line.strip()
        if stripped.startswith('^'):
            footnote_lines.append(stripped)
        elif stripped and not stripped.startswith('['):
            body_lines.append(stripped)

    return body_lines, footnote_lines


def identify_sections(body_lines):
    """Identifica le sezioni e conta le parole per sezione."""
    sections = defaultdict(list)
    current_section = "Preamble"
    section_order = []

    for text in body_lines:
        is_header = False
        for sec in KNOWN_SECTIONS:
            if text.strip().lower() == sec.lower():
                current_section = sec
                is_header = True
                if sec not in section_order:
                    section_order.append(sec)
                break
        if not is_header:
            sections[current_section].append(text)

    return dict(sections), section_order


def check_british_english(text):
    """Controlla parole in American English."""
    issues = []
    text_lower = text.lower()
    for am, br in AMERICANISMS.items():
        # Cerca whole word
        for match in re.finditer(r'\b' + re.escape(am) + r'\b', text_lower):
            issues.append(f"  Found '{am}' → should be '{br}'")
    return issues


def check_boldface(text):
    """Controlla testo in grassetto nel corpo."""
    bold_patterns = [r'\*\*.*?\*\*', r'__.*?__', r'<b>.*?</b>']
    issues = []
    for pattern in bold_patterns:
        matches = re.findall(pattern, text)
        for m in matches:
            issues.append(f"  Boldface found: {m}")
    return issues


def check_chronological_order(sections):
    """Controlla ordine cronologico delle sentenze nelle Recent cases."""
    recent_cases = sections.get('Recent cases', [])
    text = ' '.join(recent_cases)

    # Pattern per anni nelle citazioni
    years = re.findall(r'(?:Decision|Decree|Order) No\. \d+.*?((?:19|20)\d{2})', text)
    years_numeric = [int(y) for y in years if y.isdigit()]

    issues = []
    if len(years_numeric) >= 2:
        for i in range(len(years_numeric) - 1):
            if years_numeric[i] > years_numeric[i + 1]:
                issues.append(
                    f"  Chronology issue: {years_numeric[i]} before {years_numeric[i + 1]}"
                )
    return issues


def check_fonti_integrity(body_text, fonti_path):
    """Controlla quali fonti dalla tabella sono citate nel corpo."""
    if not Path(fonti_path).exists():
        return {"integrated": 0, "total": 0, "missing": [], "error": "Fonti file not found"}

    with open(fonti_path, 'r', encoding='utf-8') as f:
        fonti_content = f.read()

    # Estrai nomi file dalla tabella (prima colonna)
    file_patterns = re.findall(
        r'^([A-Za-z0-9_\-]+\.(?:pdf|txt))', fonti_content, re.MULTILINE
    )

    integrated = []
    missing = []
    body_lower = body_text.lower()

    for fonte in file_patterns:
        base_name = fonte.split('.')[0].lower()
        # Cerca per nome base o per parole chiave significative nel nome
        if base_name in body_lower or any(
            kw in body_lower for kw in base_name.split('_') if len(kw) > 4
        ):
            integrated.append(fonte)
        else:
            missing.append(fonte)

    return {
        "integrated": len(integrated),
        "total": len(file_patterns),
        "missing": missing,
        "integrated_list": integrated
    }


def check_footnote_markers(body_text, footnote_count):
    """Verifica che i marker di footnote siano coerenti."""
    markers = re.findall(r'(\d+)(?=[,\.\s])', body_text)
    # Stima euristica: cerca numeri seguiti da spazio/punto che potrebbero essere marker
    # Questo è un check semplificato
    return []


def check_date_format(text):
    """Controlla formato date Lexology: 1 January 2025 (no virgole)."""
    issues = []
    # Cerca date in formato sbagliato (es. "January 1, 2025" o "1 January, 2025")
    bad_patterns = [
        r'\b(?:January|February|March|April|May|June|July|August|September|October|November|December)\s+\d{1,2},\s*\d{4}',
        r'\b\d{1,2}\s+(?:January|February|March|April|May|June|July|August|September|October|November|December),\s*\d{4}',
    ]
    for pattern in bad_patterns:
        matches = re.findall(pattern, text)
        for m in matches:
            issues.append(f"  Bad date format: '{m}' → use '1 January 2025'")
    return issues


def main():
    parser = argparse.ArgumentParser(description='Validate TP Italy book')
    parser.add_argument('filepath', help='Path to the book file')
    parser.add_argument('--fonti', default='fonti_42_tabella.txt', help='Path to fonti table')
    parser.add_argument('--target-min', type=int, default=4800, help='Min target word count')
    parser.add_argument('--target-max', type=int, default=5000, help='Max target word count')
    args = parser.parse_args()

    body_lines, footnote_lines = extract_body_and_footnotes(args.filepath)
    sections, section_order = identify_sections(body_lines)
    full_text = ' '.join(body_lines)

    print("=" * 72)
    print("DIAGNOSTICA COMPLETA — Transfer Pricing Italy v3.2")
    print("=" * 72)

    # 1. Word count per sezione
    total_body = 0
    print("\n📊 WORD COUNT PER SEZIONE:")
    for sec in section_order:
        words = len(' '.join(sections.get(sec, [])).split())
        total_body += words
        status = "✅" if words > 0 else "⚠️  VUOTA"
        print(f"  {sec:55s} {words:5d} words {status}")

    print(f"\n{'TOTAL BODY WORDS:':55s} {total_body:5d}")
    print(f"{'TARGET RANGE:':55s} {args.target_min:,} – {args.target_max:,}")
    if args.target_min <= total_body <= args.target_max:
        print(f"{'STATUS:':55s} ✅ WITHIN RANGE")
    elif total_body > args.target_max:
        overflow = total_body - args.target_max
        print(f"{'STATUS:':55s} ❌ OVERFLOW by {overflow} words")
        print(f"{'ACTION:':55s} Activate Auto-Repair 6.1 (Condensation)")
    else:
        underflow = args.target_min - total_body
        print(f"{'STATUS:':55s} ❌ UNDERFLOW by {underflow} words")
        print(f"{'ACTION:':55s} Activate Auto-Repair 6.2 (Expansion)")

    # 2. Footnotes
    print(f"\n📎 FOOTNOTES: {len(footnote_lines)} (excluded from count)")

    # 3. Sezioni required
    print("\n📋 REQUIRED SECTIONS:")
    for sec in REQUIRED_SECTIONS:
        words = len(' '.join(sections.get(sec, [])).split())
        status = "✅" if words > 50 else "❌ TOO SHORT"
        print(f"  {sec:30s} {words:5d} words {status}")

    print("\n📋 RECOMMENDED SECTIONS:")
    for sec in RECOMMENDED_SECTIONS:
        words = len(' '.join(sections.get(sec, [])).split())
        status = "✅" if words > 0 else "⚠️  EMPTY"
        print(f"  {sec:30s} {words:5d} words {status}")

    # 4. British English
    print("\n🇬🇧 BRITISH ENGLISH CHECK:")
    be_issues = check_british_english(full_text)
    if be_issues:
        for issue in be_issues[:10]:
            print(issue)
        if len(be_issues) > 10:
            print(f"  ... and {len(be_issues) - 10} more")
    else:
        print("  ✅ PASS")

    # 5. Boldface
    print("\n🔤 BOLDFACE CHECK:")
    bold_issues = check_boldface(full_text)
    if bold_issues:
        for issue in bold_issues[:5]:
            print(issue)
    else:
        print("  ✅ PASS")

    # 6. Date format
    print("\n📅 DATE FORMAT CHECK:")
    date_issues = check_date_format(full_text)
    if date_issues:
        for issue in date_issues[:5]:
            print(issue)
    else:
        print("  ✅ PASS")

    # 7. Chronological order
    print("\n📅 CHRONOLOGICAL ORDER CHECK (Recent cases):")
    chrono_issues = check_chronological_order(sections)
    if chrono_issues:
        for issue in chrono_issues:
            print(issue)
    else:
        print("  ✅ PASS")

    # 8. Fonti integrity
    print("\n📚 FONTI INTEGRITY CHECK:")
    fonti_report = check_fonti_integrity(full_text, args.fonti)
    if "error" in fonti_report:
        print(f"  ⚠️  {fonti_report['error']}")
    else:
        print(f"  Total fonti in table: {fonti_report['total']}")
        print(f"  Integrated: {fonti_report['integrated']}")
        print(f"  Missing: {len(fonti_report['missing'])}")
        if fonti_report['missing']:
            print("  Missing fonti:")
            for m in fonti_report['missing'][:10]:
                print(f"    - {m}")
            if len(fonti_report['missing']) > 10:
                print(f"    ... and {len(fonti_report['missing']) - 10} more")

    # 9. Overall health
    print("\n" + "=" * 72)
    issues_count = len(be_issues) + len(bold_issues) + len(chrono_issues) + len(date_issues)
    if total_body > args.target_max:
        issues_count += 1
    elif total_body < args.target_min:
        issues_count += 1

    if issues_count == 0:
        print("🟢 OVERALL HEALTH: ✅ HEALTHY — All checks passed")
    elif issues_count <= 3:
        print(f"🟡 OVERALL HEALTH: ⚠️  WARNING — {issues_count} minor issues")
    else:
        print(f"🔴 OVERALL HEALTH: ❌ CRITICAL — {issues_count} issues require attention")

    print("=" * 72)

    # Return code per automazione
    return 0 if issues_count == 0 else 1


if __name__ == '__main__':
    sys.exit(main())
