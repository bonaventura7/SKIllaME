"""
Layout renderers for ppt-autodesign skill.

Each renderer signature:
    render_<name>(slide: dict, prs: Presentation, theme: dict, ctx: dict) -> None

It uses python-pptx primitives only (no images, no external deps).
All slides are drawn on a 16:9 blank layout (slide_layouts[6]) so we
have total control over composition.

Resilience principles:
  - Every renderer wraps its content logic in a try/except and falls back
    to render_bullets on failure.
  - Coordinates are computed from prs.slide_width/height so the result
    is correct even if the master changes size.
"""
from __future__ import annotations
import re
import sys
import traceback

from pptx import Presentation  # noqa: F401  (typing only)
from pptx.util import Inches, Pt, Emu
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.chart.data import CategoryChartData
from pptx.enum.chart import XL_CHART_TYPE, XL_LEGEND_POSITION


# ---------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------
def _rgb(hex_str: str) -> RGBColor:
    return RGBColor.from_string(hex_str)


def _blank_slide(prs):
    """Return a fresh blank slide (layout index 6 in default master)."""
    layout = prs.slide_layouts[6]  # blank
    return prs.slides.add_slide(layout)


def _paint_background(slide, prs, theme):
    """Solid rectangle filling the slide with theme bg colour."""
    bg = slide.shapes.add_shape(
        MSO_SHAPE.RECTANGLE, 0, 0, prs.slide_width, prs.slide_height
    )
    bg.line.fill.background()
    bg.fill.solid()
    bg.fill.fore_color.rgb = _rgb(theme["colors"]["bg"])
    bg.shadow.inherit = False
    # Send to back
    spTree = bg._element.getparent()
    spTree.remove(bg._element)
    spTree.insert(2, bg._element)
    return bg


def _add_text(slide, x, y, w, h, text, *,
              font_name="Calibri", size_pt=18, color_hex="111111",
              bold=False, italic=False, align=PP_ALIGN.LEFT,
              anchor=MSO_ANCHOR.TOP, line_spacing=1.1):
    tb = slide.shapes.add_textbox(x, y, w, h)
    tf = tb.text_frame
    tf.word_wrap = True
    tf.margin_left = tf.margin_right = Emu(0)
    tf.margin_top = tf.margin_bottom = Emu(0)
    tf.vertical_anchor = anchor

    lines = text.split("\n") if isinstance(text, str) else list(text)
    for idx, line in enumerate(lines):
        p = tf.paragraphs[0] if idx == 0 else tf.add_paragraph()
        p.alignment = align
        p.line_spacing = line_spacing
        run = p.add_run()
        run.text = line
        run.font.name = font_name
        run.font.size = Pt(size_pt)
        run.font.bold = bold
        run.font.italic = italic
        run.font.color.rgb = _rgb(color_hex)
    return tb


def _header_bar(slide, prs, theme, title_text):
    """Top accent bar + slide title; common to most layouts."""
    c = theme["colors"]
    s = theme["sizes"]
    f = theme["fonts"]

    if theme.get("decor", {}).get("title_bar", True):
        bar = slide.shapes.add_shape(
            MSO_SHAPE.RECTANGLE, 0, 0, prs.slide_width, Inches(0.18)
        )
        bar.line.fill.background()
        bar.fill.solid()
        bar.fill.fore_color.rgb = _rgb(c["accent"])

    if theme.get("decor", {}).get("accent_dot", True):
        dot = slide.shapes.add_shape(
            MSO_SHAPE.OVAL, Inches(0.55), Inches(0.78), Inches(0.18), Inches(0.18)
        )
        dot.line.fill.background()
        dot.fill.solid()
        dot.fill.fore_color.rgb = _rgb(c["accent"])

    _add_text(
        slide,
        Inches(0.85), Inches(0.62),
        prs.slide_width - Inches(1.7), Inches(0.7),
        title_text,
        font_name=f["title"], size_pt=s["h2_pt"],
        color_hex=c["primary"], bold=True,
    )


def _footer(slide, prs, theme, ctx):
    if not theme.get("decor", {}).get("footer_bar", True):
        return
    c = theme["colors"]
    s = theme["sizes"]
    f = theme["fonts"]
    h = Inches(0.32)
    y = prs.slide_height - h
    bar = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, 0, y, prs.slide_width, h)
    bar.line.fill.background()
    bar.fill.solid()
    bar.fill.fore_color.rgb = _rgb(c["bg_alt"])
    _add_text(
        slide, Inches(0.4), y, prs.slide_width - Inches(0.8), h,
        f"{ctx.get('deck_title','')}",
        font_name=f["body"], size_pt=s["small_pt"], color_hex=c["text_muted"],
        anchor=MSO_ANCHOR.MIDDLE,
    )
    _add_text(
        slide, prs.slide_width - Inches(1.2), y,
        Inches(0.8), h,
        f"{ctx.get('slide_num','')} / {ctx.get('slide_total','')}",
        font_name=f["body"], size_pt=s["small_pt"], color_hex=c["text_muted"],
        align=PP_ALIGN.RIGHT, anchor=MSO_ANCHOR.MIDDLE,
    )


def _clean_bullets(body_lines):
    """Strip leading bullet markers; return list of clean strings."""
    out = []
    for ln in body_lines:
        s = ln.strip()
        if not s:
            continue
        if s.startswith(("-", "*", "•")):
            s = s.lstrip("-*• ").strip()
        out.append(s)
    return out


# ---------------------------------------------------------------------
# Renderers
# ---------------------------------------------------------------------
def render_title(slide_data, prs, theme, ctx):
    c = theme["colors"]; s = theme["sizes"]; f = theme["fonts"]
    slide = _blank_slide(prs)
    _paint_background(slide, prs, theme)

    # Big accent block on the left
    block = slide.shapes.add_shape(
        MSO_SHAPE.RECTANGLE, 0, 0, Inches(0.4), prs.slide_height
    )
    block.line.fill.background()
    block.fill.solid()
    block.fill.fore_color.rgb = _rgb(c["accent"])

    # Decorative thin line under title
    _add_text(
        slide, Inches(0.9), Inches(2.3),
        prs.slide_width - Inches(1.5), Inches(1.8),
        ctx.get("deck_title", slide_data.get("heading", "")),
        font_name=f["title"], size_pt=s["title_pt"] + 6,
        color_hex=c["primary"], bold=True, line_spacing=1.05,
    )
    line = slide.shapes.add_shape(
        MSO_SHAPE.RECTANGLE, Inches(0.9), Inches(4.05),
        Inches(1.0), Inches(0.06),
    )
    line.line.fill.background()
    line.fill.solid()
    line.fill.fore_color.rgb = _rgb(c["accent"])

    subtitle = ctx.get("subtitle") or ""
    if subtitle:
        _add_text(
            slide, Inches(0.9), Inches(4.25),
            prs.slide_width - Inches(1.5), Inches(0.8),
            subtitle,
            font_name=f["body"], size_pt=s["subtitle_pt"],
            color_hex=c["secondary"], italic=True,
        )

    foot = " · ".join([x for x in (ctx.get("author"), ctx.get("date")) if x])
    if foot:
        _add_text(
            slide, Inches(0.9), prs.slide_height - Inches(0.9),
            prs.slide_width - Inches(1.5), Inches(0.5),
            foot,
            font_name=f["body"], size_pt=s["small_pt"],
            color_hex=c["text_muted"],
        )
    return slide


def render_section(slide_data, prs, theme, ctx):
    c = theme["colors"]; s = theme["sizes"]; f = theme["fonts"]
    slide = _blank_slide(prs)
    _paint_background(slide, prs, theme)

    # Full-bleed accent band
    band = slide.shapes.add_shape(
        MSO_SHAPE.RECTANGLE, 0, Inches(2.6), prs.slide_width, Inches(2.2)
    )
    band.line.fill.background()
    band.fill.solid()
    band.fill.fore_color.rgb = _rgb(c["bg_alt"])

    _add_text(
        slide, Inches(0.8), Inches(2.85),
        prs.slide_width - Inches(1.6), Inches(1.7),
        slide_data.get("heading", ""),
        font_name=f["title"], size_pt=s["title_pt"],
        color_hex=c["primary"], bold=True, anchor=MSO_ANCHOR.MIDDLE,
    )
    # Accent underline
    line = slide.shapes.add_shape(
        MSO_SHAPE.RECTANGLE, Inches(0.8), Inches(4.55),
        Inches(0.9), Inches(0.07),
    )
    line.line.fill.background()
    line.fill.solid()
    line.fill.fore_color.rgb = _rgb(c["accent"])
    _footer(slide, prs, theme, ctx)
    return slide


def render_bullets(slide_data, prs, theme, ctx):
    c = theme["colors"]; s = theme["sizes"]; f = theme["fonts"]
    slide = _blank_slide(prs)
    _paint_background(slide, prs, theme)
    _header_bar(slide, prs, theme, slide_data.get("heading", ""))

    bullets = _clean_bullets(slide_data.get("body_lines", []))
    if not bullets:
        bullets = ["TBD"]

    tb = slide.shapes.add_textbox(
        Inches(0.9), Inches(1.7),
        prs.slide_width - Inches(1.8),
        prs.slide_height - Inches(2.4),
    )
    tf = tb.text_frame
    tf.word_wrap = True
    tf.margin_left = tf.margin_right = Emu(0)

    for idx, b in enumerate(bullets):
        p = tf.paragraphs[0] if idx == 0 else tf.add_paragraph()
        p.alignment = PP_ALIGN.LEFT
        p.line_spacing = 1.3
        p.space_after = Pt(8)
        run = p.add_run()
        run.text = f"●  {b}"
        run.font.name = f["body"]
        run.font.size = Pt(s["body_pt"])
        run.font.color.rgb = _rgb(c["text"])

    _footer(slide, prs, theme, ctx)
    return slide


def render_agenda(slide_data, prs, theme, ctx):
    c = theme["colors"]; s = theme["sizes"]; f = theme["fonts"]
    slide = _blank_slide(prs)
    _paint_background(slide, prs, theme)
    _header_bar(slide, prs, theme, slide_data.get("heading", "Agenda"))

    items = _clean_bullets(slide_data.get("body_lines", [])) or ["TBD"]
    top = Inches(1.7)
    item_h = Inches(0.7)
    left = Inches(0.9)
    width = prs.slide_width - Inches(1.8)

    for i, item in enumerate(items):
        y = top + i * item_h
        # Number badge
        badge = slide.shapes.add_shape(
            MSO_SHAPE.OVAL, left, y, Inches(0.55), Inches(0.55)
        )
        badge.line.fill.background()
        badge.fill.solid()
        badge.fill.fore_color.rgb = _rgb(c["accent"])
        _add_text(
            slide, left, y, Inches(0.55), Inches(0.55),
            f"{i+1:02d}",
            font_name=f["title"], size_pt=14,
            color_hex=c["bg"], bold=True,
            align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE,
        )
        _add_text(
            slide, left + Inches(0.85), y,
            width - Inches(0.85), Inches(0.55),
            item,
            font_name=f["body"], size_pt=s["body_pt"] + 2,
            color_hex=c["text"], anchor=MSO_ANCHOR.MIDDLE,
        )
    _footer(slide, prs, theme, ctx)
    return slide


def render_two_column(slide_data, prs, theme, ctx):
    c = theme["colors"]; s = theme["sizes"]; f = theme["fonts"]
    slide = _blank_slide(prs)
    _paint_background(slide, prs, theme)
    _header_bar(slide, prs, theme, slide_data.get("heading", ""))

    body = "\n".join(slide_data.get("body_lines", []))
    # Split on **Left** / **Right**
    left_text = ""
    right_text = ""
    pattern = re.compile(r"\*\*(Left|Right)\*\*\s*:?\s*", re.IGNORECASE)
    parts = pattern.split(body)
    # parts = [pre, 'Left', leftbody, 'Right', rightbody] (in any order)
    it = iter(parts[1:])
    for label, content in zip(it, it):
        if label.lower() == "left":
            left_text = content.strip()
        else:
            right_text = content.strip()

    col_w = (prs.slide_width - Inches(2.1)) // 2
    top = Inches(1.7)
    h = prs.slide_height - Inches(2.4)

    # Left column card
    for i, (txt, x_off) in enumerate([(left_text, Inches(0.9)),
                                       (right_text, Inches(0.9) + col_w + Inches(0.3))]):
        card = slide.shapes.add_shape(
            MSO_SHAPE.ROUNDED_RECTANGLE, x_off, top, col_w, h
        )
        card.line.fill.background()
        card.fill.solid()
        card.fill.fore_color.rgb = _rgb(c["bg_alt"])
        card.adjustments[0] = 0.05

        # Column label
        label = "LEFT" if i == 0 else "RIGHT"
        _add_text(
            slide, x_off + Inches(0.3), top + Inches(0.25),
            col_w - Inches(0.6), Inches(0.4),
            label,
            font_name=f["title"], size_pt=12,
            color_hex=c["accent"], bold=True,
        )
        _add_text(
            slide, x_off + Inches(0.3), top + Inches(0.75),
            col_w - Inches(0.6), h - Inches(1.0),
            txt or "—",
            font_name=f["body"], size_pt=s["body_pt"],
            color_hex=c["text"], line_spacing=1.3,
        )

    _footer(slide, prs, theme, ctx)
    return slide


def render_kpi(slide_data, prs, theme, ctx):
    c = theme["colors"]; s = theme["sizes"]; f = theme["fonts"]
    slide = _blank_slide(prs)
    _paint_background(slide, prs, theme)
    _header_bar(slide, prs, theme, slide_data.get("heading", ""))

    raw = [l.strip() for l in slide_data.get("body_lines", []) if l.strip().startswith("-")]
    items = []
    for r in raw:
        parts = [p.strip() for p in r.lstrip("-").split("|")]
        if len(parts) >= 2:
            label = parts[0]
            value = parts[1]
            delta = parts[2] if len(parts) >= 3 else ""
            items.append((label, value, delta))
    if not items:
        return render_bullets(slide_data, prs, theme, ctx)

    n = len(items)
    cols = min(n, 4)
    rows = (n + cols - 1) // cols
    margin = Inches(0.9)
    gap = Inches(0.3)
    avail_w = prs.slide_width - 2 * margin - (cols - 1) * gap
    card_w = avail_w // cols
    top_zone = Inches(1.8)
    avail_h = prs.slide_height - top_zone - Inches(0.7)
    card_h = (avail_h - (rows - 1) * gap) // rows

    for idx, (label, value, delta) in enumerate(items):
        r = idx // cols
        col = idx % cols
        x = margin + col * (card_w + gap)
        y = top_zone + r * (card_h + gap)

        card = slide.shapes.add_shape(
            MSO_SHAPE.ROUNDED_RECTANGLE, x, y, card_w, card_h
        )
        card.line.fill.background()
        card.fill.solid()
        card.fill.fore_color.rgb = _rgb(c["bg_alt"])
        card.adjustments[0] = 0.08

        # Top accent line
        accent = slide.shapes.add_shape(
            MSO_SHAPE.RECTANGLE, x, y, card_w, Inches(0.08)
        )
        accent.line.fill.background()
        accent.fill.solid()
        accent.fill.fore_color.rgb = _rgb(c["accent"])

        _add_text(
            slide, x + Inches(0.25), y + Inches(0.3),
            card_w - Inches(0.5), Inches(0.4),
            label.upper(),
            font_name=f["title"], size_pt=s["kpi_label_pt"],
            color_hex=c["text_muted"], bold=True,
        )
        _add_text(
            slide, x + Inches(0.25), y + Inches(0.75),
            card_w - Inches(0.5), card_h - Inches(1.3),
            value,
            font_name=f["title"], size_pt=s["kpi_value_pt"],
            color_hex=c["primary"], bold=True, anchor=MSO_ANCHOR.TOP,
        )
        if delta:
            color = c["success"] if delta.lstrip().startswith("+") else (
                c["danger"] if delta.lstrip().startswith("-") else c["text_muted"]
            )
            _add_text(
                slide, x + Inches(0.25), y + card_h - Inches(0.55),
                card_w - Inches(0.5), Inches(0.4),
                delta,
                font_name=f["body"], size_pt=s["body_pt"] - 2,
                color_hex=color, bold=True,
            )

    _footer(slide, prs, theme, ctx)
    return slide


def render_quote(slide_data, prs, theme, ctx):
    c = theme["colors"]; s = theme["sizes"]; f = theme["fonts"]
    slide = _blank_slide(prs)
    _paint_background(slide, prs, theme)

    heading = slide_data.get("heading", "").strip()
    body_lines = [l.strip() for l in slide_data.get("body_lines", []) if l.strip()]

    # If heading is the quote (wrapped in quotes), use it; else use first body line
    if heading.startswith('"') and heading.endswith('"'):
        quote_text = heading.strip('"')
        attribution = " ".join(body_lines)
    else:
        # find body line starting with > as quote, else combine
        quote_text = ""
        attribution = ""
        for ln in body_lines:
            if ln.startswith(">"):
                quote_text = ln.lstrip(">").strip()
            elif ln.startswith("—") or ln.startswith("--") or ln.startswith("-"):
                attribution = ln.lstrip("—-").strip()
            else:
                quote_text = quote_text or ln
        if not quote_text and body_lines:
            quote_text = body_lines[0]
            attribution = " ".join(body_lines[1:])

    # Large accent quotation mark
    _add_text(
        slide, Inches(0.6), Inches(0.6),
        Inches(2.0), Inches(2.0),
        "“",
        font_name=f["title"], size_pt=200,
        color_hex=c["accent"], bold=True,
    )
    _add_text(
        slide, Inches(1.2), Inches(2.0),
        prs.slide_width - Inches(2.4), Inches(3.5),
        quote_text or "—",
        font_name=f["title"], size_pt=s["title_pt"] - 4,
        color_hex=c["primary"], italic=True, line_spacing=1.25,
        anchor=MSO_ANCHOR.MIDDLE,
    )
    if attribution:
        _add_text(
            slide, Inches(1.2), prs.slide_height - Inches(1.4),
            prs.slide_width - Inches(2.4), Inches(0.5),
            attribution,
            font_name=f["body"], size_pt=s["subtitle_pt"] - 2,
            color_hex=c["secondary"], bold=True,
        )
    return slide


def render_timeline(slide_data, prs, theme, ctx):
    c = theme["colors"]; s = theme["sizes"]; f = theme["fonts"]
    slide = _blank_slide(prs)
    _paint_background(slide, prs, theme)
    _header_bar(slide, prs, theme, slide_data.get("heading", ""))

    items = []
    for ln in slide_data.get("body_lines", []):
        s_ = ln.strip()
        if not s_.startswith("-"):
            continue
        parts = [p.strip() for p in s_.lstrip("-").split("|", 1)]
        if len(parts) == 2:
            items.append((parts[0], parts[1]))
    if not items:
        return render_bullets(slide_data, prs, theme, ctx)

    n = len(items)
    margin = Inches(0.9)
    avail_w = prs.slide_width - 2 * margin
    y_line = Inches(3.5)
    line_h = Inches(0.06)

    # Base line
    line = slide.shapes.add_shape(
        MSO_SHAPE.RECTANGLE, margin, y_line, avail_w, line_h
    )
    line.line.fill.background()
    line.fill.solid()
    line.fill.fore_color.rgb = _rgb(c["secondary"])

    step = avail_w // max(n - 1, 1) if n > 1 else 0
    node_size = Inches(0.45)
    for i, (label, desc) in enumerate(items):
        cx = margin + (i * step if n > 1 else avail_w // 2) - node_size // 2
        cy = y_line + line_h // 2 - node_size // 2
        node = slide.shapes.add_shape(MSO_SHAPE.OVAL, cx, cy, node_size, node_size)
        node.line.color.rgb = _rgb(c["bg"])
        node.line.width = Pt(2)
        node.fill.solid()
        node.fill.fore_color.rgb = _rgb(c["accent"])

        # Alternate above/below
        label_w = Inches(2.2)
        label_x = cx + node_size // 2 - label_w // 2
        if i % 2 == 0:
            label_y_label = y_line - Inches(1.4)
            label_y_desc = y_line - Inches(0.9)
        else:
            label_y_label = y_line + Inches(0.5)
            label_y_desc = y_line + Inches(1.0)

        _add_text(
            slide, label_x, label_y_label, label_w, Inches(0.4),
            label,
            font_name=f["title"], size_pt=s["body_pt"],
            color_hex=c["accent"], bold=True, align=PP_ALIGN.CENTER,
        )
        _add_text(
            slide, label_x, label_y_desc, label_w, Inches(1.0),
            desc,
            font_name=f["body"], size_pt=s["small_pt"] + 1,
            color_hex=c["text"], align=PP_ALIGN.CENTER, line_spacing=1.2,
        )
    _footer(slide, prs, theme, ctx)
    return slide


def render_comparison(slide_data, prs, theme, ctx):
    c = theme["colors"]; s = theme["sizes"]; f = theme["fonts"]
    slide = _blank_slide(prs)
    _paint_background(slide, prs, theme)
    _header_bar(slide, prs, theme, slide_data.get("heading", ""))

    # Group bullets by preceding **Header**
    groups = []
    current_label = None
    current_items = []
    for ln in slide_data.get("body_lines", []):
        s_ = ln.strip()
        if not s_:
            continue
        m = re.match(r"^\*\*([^*]+)\*\*\s*$", s_)
        if m:
            if current_label is not None:
                groups.append((current_label, current_items))
            current_label = m.group(1).strip()
            current_items = []
            continue
        if s_.startswith(("-", "*", "•")):
            current_items.append(s_.lstrip("-*• ").strip())
        else:
            current_items.append(s_)
    if current_label is not None:
        groups.append((current_label, current_items))
    if len(groups) < 2:
        return render_bullets(slide_data, prs, theme, ctx)

    groups = groups[:3]  # cap at 3 columns
    n = len(groups)
    margin = Inches(0.9)
    gap = Inches(0.3)
    top = Inches(1.8)
    card_w = (prs.slide_width - 2 * margin - (n - 1) * gap) // n
    card_h = prs.slide_height - top - Inches(0.7)

    accent_colors = [c["accent"], c["secondary"], c["success"]]
    for i, (label, items) in enumerate(groups):
        x = margin + i * (card_w + gap)
        card = slide.shapes.add_shape(
            MSO_SHAPE.ROUNDED_RECTANGLE, x, top, card_w, card_h
        )
        card.line.fill.background()
        card.fill.solid()
        card.fill.fore_color.rgb = _rgb(c["bg_alt"])
        card.adjustments[0] = 0.06

        # Header band
        band = slide.shapes.add_shape(
            MSO_SHAPE.RECTANGLE, x, top, card_w, Inches(0.7)
        )
        band.line.fill.background()
        band.fill.solid()
        band.fill.fore_color.rgb = _rgb(accent_colors[i % len(accent_colors)])
        _add_text(
            slide, x, top, card_w, Inches(0.7),
            label,
            font_name=f["title"], size_pt=s["body_pt"] + 4,
            color_hex=c["bg"], bold=True,
            align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE,
        )

        # Items
        tb = slide.shapes.add_textbox(
            x + Inches(0.3), top + Inches(0.95),
            card_w - Inches(0.6), card_h - Inches(1.2),
        )
        tf = tb.text_frame
        tf.word_wrap = True
        tf.margin_left = tf.margin_right = Emu(0)
        for j, it in enumerate(items or ["—"]):
            p = tf.paragraphs[0] if j == 0 else tf.add_paragraph()
            p.line_spacing = 1.3
            p.space_after = Pt(6)
            run = p.add_run()
            run.text = f"•  {it}"
            run.font.name = f["body"]
            run.font.size = Pt(s["body_pt"] - 1)
            run.font.color.rgb = _rgb(c["text"])

    _footer(slide, prs, theme, ctx)
    return slide


def render_chart(slide_data, prs, theme, ctx):
    c = theme["colors"]; s = theme["sizes"]; f = theme["fonts"]
    slide = _blank_slide(prs)
    _paint_background(slide, prs, theme)
    _header_bar(slide, prs, theme, slide_data.get("heading", ""))

    cats = []
    vals = []
    for ln in slide_data.get("body_lines", []):
        s_ = ln.strip()
        if not s_.startswith("-"):
            continue
        parts = [p.strip() for p in s_.lstrip("-").split("|", 1)]
        if len(parts) != 2:
            continue
        try:
            v = float(parts[1].replace(",", "."))
        except ValueError:
            continue
        cats.append(parts[0])
        vals.append(v)
    if not cats:
        return render_bullets(slide_data, prs, theme, ctx)

    chart_data = CategoryChartData()
    chart_data.categories = cats
    chart_data.add_series("Series 1", vals)

    x = Inches(1.0)
    y = Inches(1.7)
    cx = prs.slide_width - Inches(2.0)
    cy = prs.slide_height - Inches(2.4)
    graphic = slide.shapes.add_chart(
        XL_CHART_TYPE.COLUMN_CLUSTERED, x, y, cx, cy, chart_data
    )
    chart = graphic.chart
    chart.has_legend = False
    chart.has_title = False
    # Style series colour with accent
    plot = chart.plots[0]
    for ser in plot.series:
        ser.format.fill.solid()
        ser.format.fill.fore_color.rgb = _rgb(c["accent"])
        ser.format.line.fill.background()

    _footer(slide, prs, theme, ctx)
    return slide


def render_thanks(slide_data, prs, theme, ctx):
    c = theme["colors"]; s = theme["sizes"]; f = theme["fonts"]
    slide = _blank_slide(prs)
    _paint_background(slide, prs, theme)

    # Big accent diagonal block
    block = slide.shapes.add_shape(
        MSO_SHAPE.RECTANGLE, 0, prs.slide_height - Inches(1.6),
        prs.slide_width, Inches(1.6),
    )
    block.line.fill.background()
    block.fill.solid()
    block.fill.fore_color.rgb = _rgb(c["accent"])

    _add_text(
        slide, Inches(0.9), Inches(2.0),
        prs.slide_width - Inches(1.8), Inches(2.0),
        slide_data.get("heading", "Thank you"),
        font_name=f["title"], size_pt=s["title_pt"] + 14,
        color_hex=c["primary"], bold=True,
    )
    contact = ""
    for ln in slide_data.get("body_lines", []):
        if ln.strip().startswith(">"):
            contact = ln.strip().lstrip(">").strip()
            break
    if contact:
        _add_text(
            slide, Inches(0.9), Inches(4.2),
            prs.slide_width - Inches(1.8), Inches(0.6),
            contact,
            font_name=f["body"], size_pt=s["subtitle_pt"],
            color_hex=c["secondary"],
        )
    return slide


# ---------------------------------------------------------------------
# Dispatcher
# ---------------------------------------------------------------------
RENDERERS = {
    "title":      render_title,
    "section":    render_section,
    "bullets":    render_bullets,
    "agenda":     render_agenda,
    "two-column": render_two_column,
    "two_column": render_two_column,
    "twocolumn":  render_two_column,
    "kpi":        render_kpi,
    "quote":      render_quote,
    "timeline":   render_timeline,
    "comparison": render_comparison,
    "chart":      render_chart,
    "thanks":     render_thanks,
}


def render(layout_name, slide_data, prs, theme, ctx):
    """Dispatch with resilient fallback to bullets."""
    fn = RENDERERS.get((layout_name or "").lower(), render_bullets)
    try:
        return fn(slide_data, prs, theme, ctx)
    except Exception:  # pragma: no cover (defensive)
        sys.stderr.write(
            f"[layouts] WARN: renderer '{layout_name}' failed, "
            f"falling back to bullets for slide '{slide_data.get('heading')}'.\n"
        )
        traceback.print_exc(file=sys.stderr)
        try:
            return render_bullets(slide_data, prs, theme, ctx)
        except Exception:
            # Absolute last resort
            return _blank_slide(prs)
