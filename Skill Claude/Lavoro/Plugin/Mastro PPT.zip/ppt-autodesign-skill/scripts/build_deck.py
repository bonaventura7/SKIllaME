#!/usr/bin/env python3
"""CLI entry point for ppt-autodesign.

Usage:
    python scripts/build_deck.py --outline outline.md --theme dark --out deck.pptx
"""
from __future__ import annotations
import argparse
import sys
from pathlib import Path

# Ensure local imports work whether invoked from project root or scripts/.
sys.path.insert(0, str(Path(__file__).resolve().parent))


def main() -> int:
    ap = argparse.ArgumentParser(description="Generate an auto-designed .pptx deck from a Markdown outline.")
    ap.add_argument("--outline", required=True, help="Path to the markdown outline.")
    ap.add_argument("--theme", default="corporate",
                    choices=None,
                    help="Theme name: corporate (default) | dark | vibrant | minimal | tech.")
    ap.add_argument("--out", default="deck.pptx", help="Output .pptx file path.")
    args = ap.parse_args()

    try:
        from agent import build_presentation
    except ImportError as e:
        if "pptx" in str(e):
            print("ERROR: python-pptx not installed. Run:  pip install python-pptx",
                  file=sys.stderr)
        else:
            print(f"ERROR: import failure: {e}", file=sys.stderr)
        return 2

    try:
        out = build_presentation(args.outline, theme=args.theme, output=args.out)
        print(f"✓ Deck created: {out}")
        return 0
    except FileNotFoundError as e:
        print(f"ERROR: outline file not found: {e}", file=sys.stderr)
        return 3
    except Exception as e:
        print(f"ERROR: unexpected failure: {e}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
