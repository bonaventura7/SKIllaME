"""
ppt-autodesign orchestrator.

Public entry point:
    build_presentation(outline_path, theme="corporate", output="deck.pptx")
"""
from __future__ import annotations
import json
import sys
from pathlib import Path

from pptx import Presentation
from pptx.util import Inches

from parser import parse_outline_file, auto_detect_layout
import layouts as L


SCRIPT_DIR = Path(__file__).resolve().parent
SKILL_ROOT = SCRIPT_DIR.parent
THEMES_DIR = SKILL_ROOT / "themes"
DEFAULT_THEME = "corporate"


def load_theme(name: str) -> dict:
    """Resilient theme loader: requested -> default -> minimal hardcoded."""
    name = (name or "").lower().strip()
    candidates = [name, DEFAULT_THEME]
    for cand in candidates:
        if not cand:
            continue
        path = THEMES_DIR / f"{cand}.json"
        if path.exists():
            try:
                t = json.loads(path.read_text(encoding="utf-8"))
                if cand != name and name:
                    sys.stderr.write(
                        f"[agent] WARN: theme '{name}' not found, "
                        f"falling back to '{cand}'.\n"
                    )
                return t
            except Exception as e:
                sys.stderr.write(f"[agent] WARN: failed to read theme {path}: {e}\n")
                continue
    # Hardcoded last-resort theme
    sys.stderr.write("[agent] WARN: no theme file usable; using hardcoded minimal.\n")
    return {
        "name": "fallback",
        "colors": {
            "bg": "FFFFFF", "bg_alt": "F2F2F2",
            "primary": "111111", "secondary": "555555", "accent": "0066CC",
            "text": "111111", "text_muted": "777777",
            "success": "2E7D32", "warning": "C77700", "danger": "B00020",
        },
        "fonts": {"title": "Calibri", "body": "Calibri", "mono": "Consolas"},
        "sizes": {
            "title_pt": 40, "subtitle_pt": 22, "h2_pt": 30,
            "body_pt": 18, "small_pt": 13, "kpi_value_pt": 40, "kpi_label_pt": 14,
        },
        "decor": {"title_bar": True, "footer_bar": True, "accent_dot": True},
    }


def build_presentation(outline_path: str, theme: str = DEFAULT_THEME,
                       output: str = "deck.pptx") -> str:
    deck = parse_outline_file(outline_path)
    theme_data = load_theme(theme)

    prs = Presentation()
    # Force 16:9
    prs.slide_width = Inches(13.333)
    prs.slide_height = Inches(7.5)

    # If first slide isn't explicitly a title slide, prepend one from deck meta
    has_title_slide = (
        deck["slides"] and
        (deck["slides"][0].get("layout") == "title" or
         not deck["slides"][0].get("body_lines"))
    )
    slides_plan = list(deck["slides"])
    if not has_title_slide:
        slides_plan.insert(0, {
            "heading": deck["title"],
            "layout": "title",
            "body_lines": [],
        })

    ctx = {
        "deck_title": deck["title"],
        "subtitle":   deck["subtitle"],
        "author":     deck["author"],
        "date":       deck["date"],
        "slide_total": len(slides_plan),
    }

    for idx, slide in enumerate(slides_plan):
        layout_name = slide.get("layout") or auto_detect_layout(slide, is_first=(idx == 0))
        ctx["slide_num"] = idx + 1
        L.render(layout_name, slide, prs, theme_data, ctx)

    out_path = Path(output)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    prs.save(str(out_path))
    return str(out_path)


if __name__ == "__main__":  # pragma: no cover
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--outline", required=True)
    ap.add_argument("--theme", default=DEFAULT_THEME)
    ap.add_argument("--out", default="deck.pptx")
    args = ap.parse_args()
    p = build_presentation(args.outline, args.theme, args.out)
    print(p)
