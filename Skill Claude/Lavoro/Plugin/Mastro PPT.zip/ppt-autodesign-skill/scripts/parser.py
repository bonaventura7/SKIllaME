"""
Markdown outline parser for ppt-autodesign skill.

Contract:
  - Document starts with `# Title` (deck title).
  - Optional metadata lines starting with `> key: value` (subtitle, author, date).
  - Each `## Heading` opens a new slide.
  - Optional `@layout: <name>` line right under the slide heading forces the layout.
  - Body = remaining lines until next `##`.

Returns a `Deck` dict:
  {
    "title": str,
    "subtitle": str | None,
    "author":   str | None,
    "date":     str | None,
    "slides": [ {"heading": str, "layout": str|None, "body_lines": [str, ...]}, ... ]
  }

Resilience:
  - Any unparseable line is preserved as raw body_line; never raises.
  - Missing top-level title -> "Untitled Deck".
"""
from __future__ import annotations
from pathlib import Path
import re
import sys


META_RE = re.compile(r"^>\s*([a-zA-Z_]+)\s*:\s*(.+?)\s*$")
LAYOUT_RE = re.compile(r"^@layout\s*:\s*([a-zA-Z0-9_\-]+)\s*$", re.IGNORECASE)


def parse_outline(text: str) -> dict:
    deck = {
        "title": "Untitled Deck",
        "subtitle": None,
        "author": None,
        "date": None,
        "slides": [],
    }

    lines = text.splitlines()
    i = 0
    n = len(lines)

    # --- Header block (# Title + meta) ---
    while i < n:
        ln = lines[i].rstrip()
        if not ln.strip():
            i += 1
            continue
        if ln.startswith("# ") and not ln.startswith("## "):
            deck["title"] = ln[2:].strip() or "Untitled Deck"
            i += 1
            break
        # If first non-empty line is already a slide, no title given.
        if ln.startswith("## "):
            break
        # Stray text before title — ignore but warn.
        sys.stderr.write(f"[parser] WARN: ignoring pre-title line: {ln!r}\n")
        i += 1

    # Meta lines (>) until first slide
    while i < n:
        ln = lines[i].rstrip()
        if not ln.strip():
            i += 1
            continue
        if ln.startswith("## "):
            break
        m = META_RE.match(ln)
        if m:
            key, value = m.group(1).lower(), m.group(2)
            if key in ("subtitle", "author", "date"):
                deck[key] = value
            i += 1
            continue
        # Non-meta text outside slide — ignore gracefully.
        sys.stderr.write(f"[parser] WARN: ignoring orphan line: {ln!r}\n")
        i += 1

    # --- Slides ---
    current = None
    while i < n:
        ln = lines[i].rstrip()
        if ln.startswith("## "):
            if current is not None:
                deck["slides"].append(current)
            current = {
                "heading": ln[3:].strip(),
                "layout": None,
                "body_lines": [],
            }
            i += 1
            continue
        if current is None:
            # Should not happen, but be tolerant.
            i += 1
            continue
        m = LAYOUT_RE.match(ln.strip())
        if m and not current["body_lines"]:
            current["layout"] = m.group(1).lower()
            i += 1
            continue
        current["body_lines"].append(ln)
        i += 1

    if current is not None:
        deck["slides"].append(current)

    return deck


def parse_outline_file(path: str | Path) -> dict:
    p = Path(path)
    return parse_outline(p.read_text(encoding="utf-8"))


# ----------------------------------------------------------------------
# Layout auto-detection heuristics.
# ----------------------------------------------------------------------
def auto_detect_layout(slide: dict, is_first: bool = False) -> str:
    """Pick the best layout when @layout: is absent."""
    heading = (slide.get("heading") or "").strip().lower()
    body = [l.strip() for l in slide.get("body_lines", []) if l.strip()]

    # Title slide (only first slide and explicitly empty body or "title")
    if is_first and not body:
        return "title"

    # Thanks / Q&A / closing
    if any(kw in heading for kw in ("thank", "grazie", "q&a", "qa", "domande", "questions")):
        return "thanks"

    # Quote: heading wrapped in quotes, or body starts with >
    if (heading.startswith('"') and heading.endswith('"')) or (body and body[0].startswith(">")):
        return "quote"

    # Two-column: presence of **Left** / **Right** markers
    joined = "\n".join(body).lower()
    if "**left**" in joined and "**right**" in joined:
        return "two-column"

    # Comparison: two distinct bolded section headers each followed by bullets
    bold_headers = re.findall(r"^\*\*([^*]+)\*\*\s*$", "\n".join(body), flags=re.MULTILINE)
    if len(bold_headers) >= 2:
        return "comparison"

    # Pipe-table style content -> kpi / chart / timeline
    pipe_items = [b for b in body if b.startswith("-") and "|" in b]
    if pipe_items and len(pipe_items) == len([b for b in body if b.startswith("-")]):
        cols = max(len(b.split("|")) for b in pipe_items)
        # 2 cols + all values numeric -> chart
        if cols == 2:
            try:
                for b in pipe_items:
                    parts = [p.strip() for p in b.lstrip("-").split("|")]
                    float(parts[1].replace(",", "."))
                return "chart"
            except (ValueError, IndexError):
                return "timeline"
        if cols >= 3:
            return "kpi"

    # Agenda / TOC
    if heading in ("agenda", "indice", "contents", "outline", "summary", "sommario"):
        return "agenda"

    # Default: bullets (or section divider if empty body)
    if not body:
        return "section"
    return "bullets"
