# Layout Catalog — ppt-autodesign

Detailed reference of all 10 layouts: when to use, outline syntax, auto-detection rules.

---

## 1. `title`
**Cover slide.** Big deck title, accent line, subtitle, author/date footer.

Auto-detected when: it's the first slide AND body is empty.
Forced with: `@layout: title`

```markdown
## Q2 2026 Strategy Review
@layout: title
```
(Deck-level `# Title` is used; subtitle/author come from `> subtitle:` / `> author:` meta.)

---

## 2. `agenda`
**Numbered list of agenda items**, each with a circular badge.

Auto-detected when: heading is "Agenda", "Indice", "Contents", "Outline", "Summary".

```markdown
## Agenda
- Market overview
- Product roadmap
- Financials
- Q&A
```

---

## 3. `section`
**Section divider.** Big title in a coloured band — used to break the deck into chapters.

Auto-detected when: body is empty (and not first slide).

```markdown
## Part 2 — Financials
@layout: section
```

---

## 4. `bullets`
**Generic content slide.** Clean accent bullets, comfortable line-height.

Default fallback layout. Auto-used when nothing else fits.

```markdown
## Next quarter focus
- Finalize multi-region rollout
- Hire 4 SREs for follow-the-sun
- Launch partner programme
```

---

## 5. `two-column`
**Two large balanced cards** with LEFT / RIGHT label tags. Use for "before/after", "problem/solution", "thesis/antithesis".

Auto-detected when: body contains `**Left**` AND `**Right**` markers.

```markdown
## Market overview
@layout: two-column
**Left**: TAM grew 18% YoY...
**Right**: Competitive pressure from 3 new entrants...
```

---

## 6. `kpi`
**Metric cards grid** (auto‑wraps to 1–8 cards). Each card has top accent stripe, label, value, optional colored delta.

Auto-detected when: all dash-items have `|` and ≥ 3 columns.

```markdown
## Key KPIs
@layout: kpi
- ARR          | €12.4M | +34%
- NRR          | 118%   | +5pp
- Gross margin | 76%    | +2pp
- Churn        | 4.1%   | -1.2pp
```

Delta colour rule:
- Starts with `+` → success colour (green family)
- Starts with `-` → danger colour (red family)
- Otherwise → muted

---

## 7. `quote`
**Editorial pull quote** with oversized accent quotation mark.

Auto-detected when: heading is wrapped in quotes OR body starts with `>`.

```markdown
## "We don't sell software. We sell predictable outcomes."
@layout: quote
— Anna Bianchi, VP Sales
```

Or:
```markdown
## On reliability
@layout: quote
> Resilience is the ability to fail gracefully and recover invisibly.
— SRE handbook
```

---

## 8. `timeline`
**Horizontal milestone line** with alternating above/below labels.

Auto-detected when: all dash-items have exactly 2 columns (`label | description`), values non-numeric.

```markdown
## Roadmap H2
@layout: timeline
- Jul | Beta multi-region failover
- Sep | GA enterprise SSO
- Nov | AI copilot v2
- Dec | SOC2 Type II
```

---

## 9. `comparison`
**Side-by-side cards** (2 or 3 columns) for option comparison.

Auto-detected when: body contains ≥ 2 `**Header**` blocks with bullets under each.

```markdown
## On-prem vs Cloud vs Hybrid
@layout: comparison
**On-prem**
- Full data sovereignty
- Higher CapEx
**Cloud**
- Elastic scale
- OpEx model
**Hybrid**
- Best-of-both
- Recommended
```

---

## 10. `chart`
**Clustered column chart** (real PowerPoint chart, editable in PPT).

Auto-detected when: all dash-items have 2 columns AND every value parses as number.

```markdown
## Revenue mix 2026
@layout: chart
- Subscriptions | 62
- Services      | 21
- Marketplace   | 11
- Other         | 6
```

---

## 11. `thanks`
**Closing slide.** Big "Thank you" + accent bottom band + optional contact.

Auto-detected when: heading contains "thank", "grazie", "Q&A", "questions", "domande".

```markdown
## Thank you
@layout: thanks
> Contact: mario.rossi@company.com
```

---

## Auto-detection priority (when `@layout:` is omitted)

```
is_first AND body empty       → title
heading contains thanks-kw    → thanks
heading is "Agenda"/etc       → agenda
heading "..." OR body starts > → quote
body has **Left** AND **Right**→ two-column
≥2 **Header** blocks          → comparison
all rows "- a | b | c" (≥3col)→ kpi
all rows "- a | b", numeric   → chart
all rows "- a | b", text      → timeline
body empty                    → section
else                          → bullets
```
