---
name: ppt-autodesign
description: Generate professional, auto-designed PowerPoint (.pptx) presentations from a simple Markdown outline. Picks the best layout per slide (title, agenda, KPI, two-column, quote, comparison, timeline, chart, thanks), applies a consistent theme (Corporate / Dark / Vibrant / Minimal / Tech) with safe system fonts. 100% offline, no external APIs, high-availability design with fallback chain.
version: 1.0.0
author: Senior Solutions Architect (35+ yrs HA workflows)
license: MIT
tags: [pptx, powerpoint, presentation, slides, auto-design, offline, ha]
---

# ppt-autodesign — Agent Skill

> **Mission**: turn any structured outline into a polished, *editable* `.pptx` deck — without depending on online APIs, web fonts, or cloud rendering services.

## When to use this skill
Use this skill whenever the user asks you to:
- "Make a PowerPoint / PPT / slide deck about X"
- "Turn this report / outline / brief into slides"
- "Generate a pitch deck / weekly report / executive summary as pptx"
- "Build a presentation with a clean design"

## Why this skill (architectural rationale)
Built by a Senior Solutions Architect specialising in **High Availability** workflows. Design choices:

| Decision | Reason |
|---|---|
| `python-pptx` only (no API) | Zero downtime risk, fully reproducible, runs on air‑gapped envs |
| System-safe fonts (Calibri / Arial / Consolas) | No CDN dependency → no broken decks if webfonts fail |
| JSON-based design tokens (`themes/*.json`) | Theme swap is one flag; new themes don't require code changes |
| Layout auto-selection (heuristics) | Caller doesn't need to know layout names; agent stays "prompt-simple" |
| **Fallback chain**: requested theme → `corporate` (default) → plain bullet layout | Resilience: any failure degrades gracefully instead of crashing |

## Quick start (for the agent)

```bash
python scripts/build_deck.py \
  --outline path/to/outline.md \
  --theme corporate \
  --out deck.pptx
```

Or programmatic:
```python
from scripts.agent import build_presentation
build_presentation(outline_path="outline.md", theme="dark", output="deck.pptx")
```

## Outline format (Markdown — the contract)

The agent should produce an outline like this, then call the script. **One slide per `##` heading.** First-line metadata controls the layout when needed.

```markdown
# Q2 2026 Strategy Review
> subtitle: Board of Directors · June 2026
> author: Mario Rossi · CTO

## Agenda
- Market overview
- Product roadmap
- Financials
- Risks & mitigations
- Q&A

## Market overview
@layout: two-column
**Left**: TAM grew 18% YoY, driven by EMEA mid-market adoption.
**Right**: Competitive pressure from 3 new entrants; pricing pressure +6%.

## Key KPIs
@layout: kpi
- ARR | €12.4M | +34% YoY
- NRR | 118% | +5pp
- Gross margin | 76% | +2pp
- Churn | 4.1% | -1.2pp

## "We don't sell software, we sell predictable outcomes."
@layout: quote
— Anna Bianchi, VP Sales

## Roadmap H2
@layout: timeline
- Jul | Beta multi-region failover
- Sep | GA enterprise SSO
- Nov | AI copilot v2
- Dec | SOC2 Type II

## On-prem vs Cloud
@layout: comparison
**On-prem**
- Full data control
- Higher CapEx
- Slower iteration
**Cloud**
- Elastic scale
- OpEx model
- Continuous delivery

## Revenue mix 2026
@layout: chart
- Subscriptions | 62
- Services | 21
- Marketplace | 11
- Other | 6

## Thank you
@layout: thanks
> Questions? mario.rossi@company.com
```

If `@layout:` is omitted the engine **auto-detects** based on content shape:
- 1 line + author → `title`
- Starts with `>` quote → `quote`
- All items contain `|` and 2-4 cols → `kpi` (3 cols) / `timeline` (2 cols) / `chart` (2 cols numeric)
- Has `**Left**` / `**Right**` → `two-column`
- Has `**X**` / `**Y**` with multiple bullets each → `comparison`
- "Thank you", "Q&A", "Grazie" → `thanks`
- Default → `bullets`

## Themes available
`corporate` (default · navy + gold) · `dark` (slate + cyan) · `vibrant` (purple + magenta) · `minimal` (b/w + accent) · `tech` (deep blue + neon green)

See `themes/*.json` for tokens (colours, fonts, sizes). Add a new theme = drop in a new JSON file. No code changes.

## Files in this skill
```
ppt-autodesign-skill/
├── SKILL.md                  ← this file (agent-facing dispatcher)
├── README.md                 ← human install + usage docs
├── themes/
│   ├── corporate.json
│   ├── dark.json
│   ├── vibrant.json
│   ├── minimal.json
│   └── tech.json
├── scripts/
│   ├── agent.py              ← orchestrator (parse → route → render)
│   ├── layouts.py            ← 10 layout renderers
│   ├── parser.py             ← markdown outline parser
│   └── build_deck.py         ← CLI entry point
├── examples/
│   ├── demo_outline.md
│   └── demo_presentation.pptx
└── references/
    └── layouts_catalog.md    ← visual catalog of all layouts
```

## Workaround playbook (HA mindset)
If you hit any of these, the skill self-recovers:

| Failure | Workaround built-in |
|---|---|
| Unknown theme name | Falls back to `corporate` + warning in stderr |
| Malformed outline line | Skips line, continues, logs to stderr |
| Layout heuristic ambiguous | Defaults to `bullets` |
| Chart values not numeric | Renders as plain bullet list instead of crashing |
| Empty slide | Inserts placeholder "TBD" rather than corrupting the .pptx |
| `python-pptx` missing | `build_deck.py` prints clear `pip install python-pptx` hint |

## Agent invocation pattern (recommended)
1. Read user request → draft outline as markdown (use template above).
2. Save outline to a temp file or pass via `--outline -` (stdin).
3. Choose theme based on context (corporate report → `corporate`; startup pitch → `vibrant`; engineering review → `tech`).
4. Run `python scripts/build_deck.py --outline outline.md --theme <theme> --out deck.pptx`.
5. Return path of generated `.pptx` to the user.

---
*Designed for resilience. Built for editability. Deployed in seconds.*
