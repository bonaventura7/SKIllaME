# ppt-autodesign — Agent Skill

> Generate professional, auto-designed `.pptx` decks from a simple Markdown outline.
> Designed by a Senior Solutions Architect mindset: **high availability, zero external dependencies, graceful degradation**.

[![Built for skills.sh](https://img.shields.io/badge/skills.sh-compatible-blue)](https://www.skills.sh)
[![python-pptx](https://img.shields.io/badge/python--pptx-1.0%2B-green)](https://python-pptx.readthedocs.io)
[![No API](https://img.shields.io/badge/no%20cloud%20API-100%25%20offline-success)](#)

---

## Why
Most "PPT skills" depend on cloud APIs (SlideSpeak, etc.). Great until the API key rotates, the rate limit hits, or the network is down. This skill is **fully local**:

- ✅ No HTTP calls, no API keys, no telemetry
- ✅ Works on air‑gapped machines
- ✅ Deterministic output (reproducible across runs)
- ✅ Editable `.pptx` — text remains selectable in PowerPoint, Keynote, Google Slides
- ✅ Built‑in fallback chain (theme → default → bullet)

## Install

### Via skills.sh (when published)
```bash
npx skills add <your-org>/ppt-autodesign-skill
```

### Manual (any agent)
```bash
git clone <this-repo> ~/.claude/skills/ppt-autodesign
# or just copy the folder anywhere on disk
pip install python-pptx
```

## CLI usage
```bash
python scripts/build_deck.py \
  --outline examples/demo_outline.md \
  --theme corporate \
  --out my_deck.pptx
```

Available themes: `corporate` (default) · `dark` · `vibrant` · `minimal` · `tech`

## Python usage
```python
from scripts.agent import build_presentation
build_presentation(
    outline_path="path/to/outline.md",
    theme="dark",
    output="my_deck.pptx",
)
```

## Outline contract (cheat sheet)

```markdown
# Deck Title
> subtitle: Optional subtitle
> author:   Optional author
> date:     Optional date

## Agenda                       ← auto-detected as "agenda"
- Item 1
- Item 2

## Key KPIs                     ← auto-detected as "kpi" (3+ cols)
@layout: kpi                    ← or force explicitly
- Label | Value | Delta
- ARR   | €12M  | +30%

## "A great quote here"         ← auto-detected as "quote"
@layout: quote
— Attribution

## Roadmap                      ← auto-detected as "timeline" (2 cols, non-numeric)
@layout: timeline
- Q1 | Plan
- Q2 | Build
- Q3 | Ship

## Revenue mix                  ← auto-detected as "chart" (2 cols, numeric)
@layout: chart
- A | 60
- B | 30
- C | 10

## Left vs Right                ← needs @layout: two-column
@layout: two-column
**Left**: text
**Right**: text

## A vs B vs C                  ← auto-detected as "comparison"
@layout: comparison
**A**
- foo
**B**
- bar

## Thank you                    ← auto-detected as "thanks"
@layout: thanks
> Contact: you@company.com
```

## Available layouts (10)

| Layout | Best for | Auto-trigger |
|---|---|---|
| `title` | Cover slide | First slide / empty body |
| `agenda` | Table of contents | heading = "Agenda" |
| `section` | Section divider | empty body |
| `bullets` | Generic content | default fallback |
| `two-column` | Side‑by‑side text | `**Left**`/`**Right**` |
| `kpi` | Metric cards (1‑8) | `- a | b | c` rows |
| `quote` | Pull quote | `"..."` heading or `>` body |
| `timeline` | Roadmap / milestones | `- date | event` rows |
| `comparison` | 2‑3 options compared | multiple `**Header**` blocks |
| `chart` | Bar chart | `- label | number` rows |
| `thanks` | Closing slide | "thank/grazie/Q&A" in heading |

## Themes
All 5 themes live in `themes/*.json` as plain design tokens (colors, fonts, sizes, decor flags). **To add a new theme, drop in a new JSON file. No code changes.**

```jsonc
{
  "name": "my-brand",
  "colors": { "bg": "FFFFFF", "primary": "...", "accent": "...", ... },
  "fonts":  { "title": "Calibri", "body": "Calibri", "mono": "Consolas" },
  "sizes":  { "title_pt": 40, "body_pt": 18, ... },
  "decor":  { "title_bar": true, "footer_bar": true, "accent_dot": true }
}
```

## Resilience (the HA mindset)
| Failure mode | Built‑in workaround |
|---|---|
| Unknown theme | Falls back to `corporate`, then to hardcoded minimal |
| Malformed outline line | Skipped with warning to stderr |
| Layout name unknown | Falls back to `bullets` |
| Chart values non-numeric | Falls back to `bullets` (no crash) |
| Layout renderer raises | Caught, falls back to `bullets`, traceback logged |
| Empty slide body | "TBD" placeholder inserted |
| `python-pptx` missing | Clear pip‑install hint in stderr |
| Concurrent invocations | Stateless — safe for parallel agent runs |

## File map
```
ppt-autodesign-skill/
├── SKILL.md                  agent-facing dispatcher (skills.sh standard)
├── README.md                 you are here
├── preview.html              live HTML preview of layouts × themes
├── themes/                   5 design-token JSON files
├── scripts/
│   ├── parser.py             markdown outline → deck dict
│   ├── layouts.py            10 layout renderers + dispatcher
│   ├── agent.py              orchestrator
│   └── build_deck.py         CLI entry point
├── examples/
│   ├── demo_outline.md       sample outline
│   ├── demo_presentation.pptx (corporate)
│   ├── demo_dark.pptx
│   ├── demo_vibrant.pptx
│   ├── demo_minimal.pptx
│   ├── demo_tech.pptx
│   └── demo_resilience.pptx  proves the fallback chain
└── references/
    └── layouts_catalog.md    detailed catalog
```

## Agent invocation pattern
1. Read user request.
2. Draft the markdown outline (use the template above).
3. Pick a theme: corporate → board reports · dark → tech keynotes · vibrant → startup pitches · minimal → editorial · tech → engineering reviews.
4. Run `python scripts/build_deck.py --outline <file> --theme <theme> --out <output>.pptx`.
5. Return path of the generated `.pptx` to the user.

## License
MIT
