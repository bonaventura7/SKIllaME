# Q2 2026 Strategy Review
> subtitle: Board of Directors · June 2026
> author: Mario Rossi · CTO
> date: 04 Jun 2026

## Agenda
- Market overview
- Product roadmap
- Key financial KPIs
- Architecture choice: On-prem vs Cloud
- Revenue mix
- Closing & next steps

## Market overview
@layout: two-column
**Left**: TAM grew 18% YoY, driven by EMEA mid-market adoption and accelerated cloud migration in regulated industries.
**Right**: Competitive pressure from 3 new entrants; pricing pressure +6%. Differentiation now hinges on time-to-value and HA guarantees.

## Key KPIs
@layout: kpi
- ARR | €12.4M | +34%
- NRR | 118% | +5pp
- Gross margin | 76% | +2pp
- Churn | 4.1% | -1.2pp

## "We don't sell software. We sell predictable outcomes."
@layout: quote
— Anna Bianchi, VP Sales

## Roadmap H2
@layout: timeline
- Jul | Beta multi-region failover
- Sep | GA enterprise SSO
- Nov | AI copilot v2
- Dec | SOC2 Type II audit

## On-prem vs Cloud
@layout: comparison
**On-prem**
- Full data sovereignty
- Higher CapEx upfront
- Slower iteration cycle
- Predictable cost profile
**Cloud**
- Elastic horizontal scale
- OpEx pay-as-you-go
- Continuous delivery
- Built-in HA & DR
**Hybrid**
- Best-of-both routing
- Workload-aware placement
- Complex governance
- Recommended path

## Revenue mix 2026
@layout: chart
- Subscriptions | 62
- Services | 21
- Marketplace | 11
- Other | 6

## Next quarter focus
- Finalize multi-region active/active rollout
- Hire 4 SRE specialists for 24/7 follow-the-sun
- Launch partner programme in DACH
- Publish HA whitepaper

## Thank you
@layout: thanks
> Questions? mario.rossi@company.com
