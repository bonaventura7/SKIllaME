// ============================================================
//  APP.JS — logica principale
// ============================================================

// ---------- MSAL (Microsoft Auth) ----------
const msalConfig = {
  auth: {
    clientId: CONFIG.MS_CLIENT_ID,
    authority: `https://login.microsoftonline.com/${CONFIG.MS_TENANT_ID}`,
    redirectUri: CONFIG.MS_REDIRECT_URI
  },
  cache: { cacheLocation: "sessionStorage" }
};

let msalInstance;
let accessToken = null;
let parsedData = [];   // dati AI parsati

// Carica MSAL dinamicamente
(function loadMSAL() {
  const s = document.createElement("script");
  s.src = "https://alcdn.msauth.net/browser/2.38.3/js/msal-browser.min.js";
  s.onload = () => {
    msalInstance = new msal.PublicClientApplication(msalConfig);
    msalInstance.handleRedirectPromise().then(resp => {
      if (resp) handleAuthResponse(resp);
    });
  };
  document.head.appendChild(s);
})();

function loginMicrosoft() {
  setStatus("login-status", "loading", "Apertura finestra Microsoft...");
  msalInstance.loginPopup({
    scopes: ["Mail.Read", "Calendars.Read", "OnlineMeetings.Read", "User.Read"]
  }).then(handleAuthResponse).catch(e => {
    setStatus("login-status", "error", "Errore login: " + e.message);
  });
}

function handleAuthResponse(resp) {
  accessToken = resp.accessToken;
  document.getElementById("section-login").style.display = "none";
  document.getElementById("section-app").style.display = "block";
  document.getElementById("user-badge").innerHTML =
    `<span class="user-badge">✅ ${resp.account.username}</span>`;
  setCurrentMonth();
}

// ---------- DATE HELPERS ----------
function setCurrentMonth() {
  const now = new Date();
  const y = now.getFullYear(), m = now.getMonth();
  document.getElementById("date-from").value = `${y}-${String(m+1).padStart(2,"0")}-01`;
  const last = new Date(y, m+1, 0).getDate();
  document.getElementById("date-to").value = `${y}-${String(m+1).padStart(2,"0")}-${last}`;
}

function setPrevMonth() {
  const now = new Date();
  const y = now.getMonth() === 0 ? now.getFullYear()-1 : now.getFullYear();
  const m = now.getMonth() === 0 ? 12 : now.getMonth();
  document.getElementById("date-from").value = `${y}-${String(m).padStart(2,"0")}-01`;
  const last = new Date(y, m, 0).getDate();
  document.getElementById("date-to").value = `${y}-${String(m).padStart(2,"0")}-${last}`;
}

// ---------- FETCH MICROSOFT DATA ----------
async function fetchGraphData(endpoint) {
  const resp = await fetch(`https://graph.microsoft.com/v1.0${endpoint}`, {
    headers: { Authorization: `Bearer ${accessToken}` }
  });
  if (!resp.ok) throw new Error(`Graph API error: ${resp.status}`);
  return resp.json();
}

async function fetchAndAnalyze() {
  const from = document.getElementById("date-from").value;
  const to = document.getElementById("date-to").value;
  if (!from || !to) { alert("Seleziona un periodo"); return; }

  setStatus("fetch-status", "loading", "<span class=\'spinner\'></span> Lettura mail e calendario da Microsoft 365...");

  try {
    // Fetch mail inviate
    const mailResp = await fetchGraphData(
      `/me/mailFolders/SentItems/messages?$filter=sentDateTime ge ${from}T00:00:00Z and sentDateTime le ${to}T23:59:59Z&$select=subject,sentDateTime,toRecipients,bodyPreview&$top=100`
    );
    const mails = mailResp.value || [];

    // Fetch calendario
    const calResp = await fetchGraphData(
      `/me/calendarView?startDateTime=${from}T00:00:00Z&endDateTime=${to}T23:59:59Z&$select=subject,start,end,attendees,organizer&$top=200`
    );
    const events = calResp.value || [];

    setStatus("fetch-status", "success",
      `✅ Trovati ${mails.length} email inviate e ${events.length} eventi calendario`);

    // Prepara contesto per AI
    const mailSummary = mails.slice(0, 60).map(m =>
      `[${m.sentDateTime.slice(0,10)}] Mail a: ${m.toRecipients.map(r=>r.emailAddress.name).join(", ")} — "${m.subject}"`
    ).join("\n");

    const calSummary = events.slice(0, 80).map(e =>
      `[${e.start.dateTime.slice(0,10)}] Riunione: "${e.subject}" — partecipanti: ${(e.attendees||[]).slice(0,4).map(a=>a.emailAddress.name).join(", ")}`
    ).join("\n");

    await analyzeWithAI(from, to, mailSummary, calSummary);

  } catch(err) {
    setStatus("fetch-status", "error", "Errore: " + err.message);
  }
}

// ---------- AI ANALYSIS ----------
async function analyzeWithAI(from, to, mails, calendar) {
  setStatus("fetch-status", "loading", "<span class=\'spinner\'></span> AI in analisi...");
  document.getElementById("card-ai").style.display = "block";
  document.getElementById("ai-output").textContent = "Analisi in corso...";

  const clientiList = CONFIG.CLIENTI.join(", ");
  const prompt = `Sei un assistente che aiuta a compilare timesheet per un avvocato/consulente di transfer pricing.

CLIENTI POSSIBILI: ${clientiList}

PERIODO: dal ${from} al ${to}

EMAIL INVIATE:
${mails || "(nessuna)"}

RIUNIONI CALENDARIO:
${calendar || "(nessuna)"}

ISTRUZIONI:
1. Analizza le email e le riunioni per capire su quali clienti ha lavorato ogni giorno
2. Stima le ore basandoti sulla frequenza e tipo di attività (riunione = 1-2h, email = 0.5-1h)
3. Considera solo i giorni lavorativi (lun-ven)
4. Rispondi SOLO con un JSON strutturato così (nessun testo prima o dopo):

{
  "analisi": "breve spiegazione di 2 righe su cosa hai trovato",
  "giorni": [
    {"data": "YYYY-MM-DD", "attivita": [{"cliente": "NomeCliente", "ore": 2, "motivo": "riunione X"}]},
    ...
  ]
}`;

  try {
    const resp = await fetch("https://openrouter.ai/api/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${CONFIG.OPENROUTER_API_KEY}`,
        "Content-Type": "application/json",
        "HTTP-Referer": window.location.origin,
        "X-Title": "SBNP Timesheet AI"
      },
      body: JSON.stringify({
        model: CONFIG.OPENROUTER_MODEL,
        messages: [{ role: "user", content: prompt }],
        temperature: 0.2
      })
    });

    const data = await resp.json();
    const raw = data.choices[0].message.content.trim();

    // Parse JSON from AI response
    const jsonMatch = raw.match(/\{[\s\S]*\}/);
    if (!jsonMatch) throw new Error("AI non ha restituito JSON valido");
    const parsed = JSON.parse(jsonMatch[0]);

    parsedData = parsed.giorni || [];
    document.getElementById("ai-output").textContent =
      `📋 ${parsed.analisi}\n\n` +
      parsedData.map(g =>
        `${g.data}: ` + g.attivita.map(a => `${a.cliente} ${a.ore}h (${a.motivo})`).join(" | ")
      ).join("\n");

    setStatus("fetch-status", "success", "✅ Analisi completata");

  } catch(err) {
    document.getElementById("ai-output").textContent = "Errore AI: " + err.message;
    setStatus("fetch-status", "error", "Errore AI: " + err.message);
  }
}

// ---------- BUILD TIMESHEET TABLE ----------
function applyToSheet() {
  if (!parsedData.length) { alert("Prima analizza il periodo"); return; }

  const from = document.getElementById("date-from").value;
  const to = document.getElementById("date-to").value;
  const days = getDaysInRange(from, to);
  const clienti = CONFIG.CLIENTI;

  // Costruisci mappa dati da AI
  const aiMap = {};
  parsedData.forEach(g => {
    aiMap[g.data] = {};
    g.attivita.forEach(a => { aiMap[g.data][a.cliente] = (aiMap[g.data][a.cliente] || 0) + a.ore; });
  });

  // Costruisci tabella
  let html = `<div style="overflow-x:auto"><table>
    <thead><tr>
      <th style="min-width:90px">Data</th>
      <th>Ore Tot</th>
      ${clienti.map(c => `<th style="min-width:60px">${c}</th>`).join("")}
    </tr></thead><tbody>`;

  days.forEach(d => {
    const isWeekend = new Date(d).getDay() === 0 || new Date(d).getDay() === 6;
    const rowStyle = isWeekend ? "background:#fafafa; color:#aaa;" : "";
    const dayData = aiMap[d] || {};
    let totOre = Object.values(dayData).reduce((s,v) => s+v, 0);

    html += `<tr style="${rowStyle}">
      <td>${d.slice(5).replace("-","/")} ${["Dom","Lun","Mar","Mer","Gio","Ven","Sab"][new Date(d).getDay()]}</td>
      <td id="tot-${d}" style="font-weight:700">${totOre || 0}</td>
      ${clienti.map(c => {
        const val = dayData[c] || "";
        return `<td><input class="cell-input" type="number" min="0" max="24" step="0.5"
          data-date="${d}" data-cliente="${c}"
          value="${val}" onchange="updateTotale('${d}')"></td>`;
      }).join("")}
    </tr>`;
  });

  // Riga totali
  html += `<tr class="totale-row">
    <td>TOTALE</td>
    <td id="tot-grand">—</td>
    ${clienti.map(c => `<td id="totcol-${c}">0</td>`).join("")}
  </tr>`;

  html += `</tbody></table></div>`;
  document.getElementById("sheet-table-container").innerHTML = html;
  document.getElementById("card-sheet").style.display = "block";

  // Calcola totali iniziali
  days.forEach(d => updateTotale(d));
  updateColTotals();
  document.getElementById("card-sheet").scrollIntoView({ behavior: "smooth" });
}

function updateTotale(date) {
  const inputs = document.querySelectorAll(`input[data-date="${date}"]`);
  let tot = 0;
  inputs.forEach(i => { tot += parseFloat(i.value) || 0; });
  document.getElementById(`tot-${date}`).textContent = tot || 0;
  updateColTotals();
}

function updateColTotals() {
  let grand = 0;
  CONFIG.CLIENTI.forEach(c => {
    const inputs = document.querySelectorAll(`input[data-cliente="${c}"]`);
    let tot = 0;
    inputs.forEach(i => { tot += parseFloat(i.value) || 0; });
    const el = document.getElementById(`totcol-${c}`);
    if (el) el.textContent = tot || 0;
    grand += tot;
  });
  const el = document.getElementById("tot-grand");
  if (el) el.textContent = grand;
}

// ---------- SAVE TO GOOGLE SHEETS ----------
async function saveToGoogleSheets() {
  setStatus("save-status", "loading", "<span class=\'spinner\'></span> Salvataggio in corso...");

  const from = document.getElementById("date-from").value;
  const to = document.getElementById("date-to").value;
  const days = getDaysInRange(from, to);

  // Costruisci array valori da scrivere
  const header = ["Data", "Ore", ...CONFIG.CLIENTI];
  const rows = [header];

  days.forEach(d => {
    const tot = parseFloat(document.getElementById(`tot-${d}`)?.textContent) || 0;
    const row = [d];
    row.push(tot);
    CONFIG.CLIENTI.forEach(c => {
      const inp = document.querySelector(`input[data-date="${d}"][data-cliente="${c}"]`);
      row.push(parseFloat(inp?.value) || 0);
    });
    rows.push(row);
  });

  try {
    const resp = await fetch(
      `https://sheets.googleapis.com/v4/spreadsheets/${CONFIG.GOOGLE_SHEETS_ID}/values/A1:Z200?valueInputOption=USER_ENTERED`,
      {
        method: "PUT",
        headers: {
          "Authorization": `Bearer ${await getGoogleToken()}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ range: "A1:Z200", majorDimension: "ROWS", values: rows })
      }
    );
    if (!resp.ok) throw new Error("Google Sheets API error: " + resp.status);
    setStatus("save-status", "success", "✅ Salvato su Google Sheets!");
  } catch(err) {
    setStatus("save-status", "error", "Errore salvataggio: " + err.message +
      " — Usa 'Esporta Excel' come alternativa");
  }
}

async function getGoogleToken() {
  // Google OAuth via popup (semplificato)
  return CONFIG.GOOGLE_API_KEY; // Per ora usa API Key (solo lettura); per scrittura serve OAuth
}

// ---------- EXPORT EXCEL ----------
function exportExcel() {
  const from = document.getElementById("date-from").value;
  const to = document.getElementById("date-to").value;
  const days = getDaysInRange(from, to);

  let csv = "Data,Ore," + CONFIG.CLIENTI.join(",") + "\n";
  days.forEach(d => {
    const tot = document.getElementById(`tot-${d}`)?.textContent || 0;
    const vals = CONFIG.CLIENTI.map(c => {
      const inp = document.querySelector(`input[data-date="${d}"][data-cliente="${c}"]`);
      return parseFloat(inp?.value) || 0;
    });
    csv += `${d},${tot},${vals.join(",")}\n`;
  });

  const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = `timesheet_${from}_${to}.csv`;
  a.click(); URL.revokeObjectURL(url);
}

// ---------- UTILS ----------
function getDaysInRange(from, to) {
  const days = [];
  let cur = new Date(from);
  const end = new Date(to);
  while (cur <= end) {
    days.push(cur.toISOString().slice(0,10));
    cur.setDate(cur.getDate() + 1);
  }
  return days;
}

function setStatus(id, type, msg) {
  const el = document.getElementById(id);
  if (!el) return;
  el.innerHTML = `<div class="status ${type}">${msg}</div>`;
}