# ⏱️ Timesheet AI — SBNP

## Setup in 4 passi (20 minuti)

---

## PASSO 1 — Registra App su Microsoft Azure

1. Vai su https://portal.azure.com
2. Cerca "App registrations" → "New registration"
3. Nome: `Timesheet SBNP`
4. Redirect URI: `Single-page application (SPA)` → inserisci l'URL dove carichi la webapp
   (es. `https://tuousername.github.io/timesheet/` oppure `http://localhost:5500/`)
5. Copia il **Application (client) ID**
6. Vai su "API Permissions" → Add permission → Microsoft Graph → Delegated:
   - `Mail.Read`
   - `Calendars.Read`
   - `User.Read`
7. Clicca "Grant admin consent"

Poi in `config.js`:
```js
MS_CLIENT_ID: "incolla-qui-il-client-id",
MS_TENANT_ID: "sbnp.it",  // oppure organizations
```

---

## PASSO 2 — Google Sheets API (per scrittura)

1. Vai su https://console.cloud.google.com
2. Crea progetto → Abilita "Google Sheets API"
3. Crea credenziali OAuth 2.0 (Web application)
4. Aggiungi redirect URI
5. Copia Client ID

**Alternativa più semplice**: usa solo "Esporta Excel/CSV" e importa manualmente su Google Sheets.
Il CSV generato ha esattamente la struttura del tuo foglio.

---

## PASSO 3 — Carica su GitHub Pages (gratis)

1. Crea repository su github.com (es. `timesheet-sbnp`)
2. Carica i 4 file: `index.html`, `config.js`, `app.js`, `README.md`
3. Settings → Pages → Source: main branch
4. URL: `https://tuousername.github.io/timesheet-sbnp/`

---

## PASSO 4 — Usa la webapp

1. Apri la URL
2. Click "Login con Microsoft" → autorizza con luca.consalter@sbnp.it
3. Seleziona periodo (es. Marzo 2026)
4. Click "Analizza con AI"
5. Controlla la proposta → modifica eventuali ore
6. "Salva su Google Sheets" oppure "Esporta Excel"

---

## File inclusi

| File | Cosa fa |
|------|---------|
| `index.html` | Interfaccia webapp |
| `config.js` | Le tue configurazioni e API keys |
| `app.js` | Tutta la logica (Microsoft Auth + AI + Sheets) |
| `README.md` | Questo file |

---

## Modello AI

Puoi cambiare modello in `config.js`:
```js
OPENROUTER_MODEL: "anthropic/claude-3.5-sonnet"  // default
OPENROUTER_MODEL: "openai/gpt-4o"                // alternativa
OPENROUTER_MODEL: "google/gemini-pro-1.5"        // alternativa
```
