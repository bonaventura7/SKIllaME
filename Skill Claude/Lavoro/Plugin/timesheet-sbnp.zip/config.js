// ============================================================
//  CONFIG — modifica solo questo file
// ============================================================

const CONFIG = {
  // OpenRouter API Key
  OPENROUTER_API_KEY: "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",
  OPENROUTER_MODEL: "anthropic/claude-3.5-sonnet",   // cambia con qualsiasi modello OpenRouter

  // Microsoft OAuth (Azure App Registration)
  MS_CLIENT_ID: "INSERISCI_QUI_IL_CLIENT_ID_AZURE",   // vedi README
  MS_TENANT_ID: "organizations",                        // oppure il tuo tenant ID sbnp.it
  MS_REDIRECT_URI: window.location.origin + "/",        // URL della tua webapp

  // Google Sheets
  GOOGLE_SHEETS_ID: "1wboFuFVIDUH-cNQAYQ6nOXyOLgbTjiJXRkzW_1y90Us",
  GOOGLE_API_KEY: "INSERISCI_QUI_GOOGLE_API_KEY",       // vedi README

  // Lista clienti (colonne del tuo foglio)
  CLIENTI: [
    "Tod's","Tesmec","Petrone","Ascoli","Eataly","Swiss Steel",
    "Pettinaroli","Innovo","Valbruna","Amenduni","Damiani",
    "Digital Bros","Inglese","RT Law","Review","Sviluppo",
    "SMEI","Sony","Beuer","Medel","Mega","Crosspolimeri","Bandera","Rhom"
  ]
};