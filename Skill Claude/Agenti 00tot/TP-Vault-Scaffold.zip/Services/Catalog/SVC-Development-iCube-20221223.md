---
title: "SVC-Development-iCube — Servizi di Sviluppo e Management"
date: 2026-04-30
type: service-catalog
category: Catalog
status: active
project: "Innovo-Renewables"
service_provider: "[[Innovo Renewables S.p.A.]]"
client: "[[iCube Renewables S.r.l.]]"
service_type: Development
nature: obbligazione_di_mezzi
pricing_model: fee_fissa
annual_fee: 1307793
fee_currency: EUR
billing_frequency: Annuale
exclusivity: totale_italia
scope_summary: "Management Services (domiciliazione, accounting/tax, tesoreria) + Development Services (origination terreni, contratti agrari, permitting, interconnessione TICA/STMG)"
related_agreements:
  - "[[../Agreements/AGR-iCube-Innovo-20221223]]"
  - "[[../Agreements/AGR-Amendment-iCube-20241118]]"
related:
  - "[[SVC-AssetMgmt-Bramante-2024]]"
  - "[[SVC-Engineering-PH-2024]]"
  - "[[../Financials/FIN-TP-FeeStructure-2024]]"
tags:
  - innovo
  - svc
  - development
  - icube
  - management-services
  - development-services
  - obbligazione-di-mezzi
  - esclusivita
---

# SVC-Development-iCube — Servizi di Sviluppo e Management

## Overview
Servizio integrato fornito da Innovo Renewables S.p.A. a iCube Renewables S.r.l. per lo sviluppo e la gestione amministrativa dei progetti rinnovabili in Italia.

## Scope Dettagliato

### Management Services
- Gestione corrispondenza e PEC
- Domiciliazione societaria
- Supporto societario (assemblee, consiglio)
- Coordinamento contabilita' e fiscalita' (esternalizzato a terzi)
- Gestione tesoreria e verifica fatture fornitori

### Development Services
- Identificazione e origination siti
- Negoziazione contratti agrari (opzioni, diritti di superficie)
- Permitting (licenze, autorizzazioni, VIA)
- Procedure di connessione rete (TICA / STMG)

## Natura Giuridica
> **Obbligazione di mezzi** (*obbligazione di mezzi*)
>
> Innovo non garantisce il risultato (es. ottenimento del permesso), ma l'impiego della **massima diligenza professionale**.

## Esclusivita'
- **Territorio:** Italia
- **Beneficiario:** iCube Renewables S.r.l. e Iberdrola
- **Deroghe:** Progetti preesistenti alla firma dell'accordo

## Evoluzione Corrispettivi
| Periodo | Fee Annuale | Variazione | Riferimento |
|---------|-------------|------------|-------------|
| 2022-2023 | EUR 871.862 | -- | Contratto originale |
| 2024 | **EUR 1.307.793** | +50% | [[AGR-Amendment-iCube-20241118]] |

## KPI e Metriche
- Progetti in pipeline gestiti: *da popolare da Claude*
- MW in sviluppo attivo: *da popolare*
- Tempo medio permitting: *da popolare*

## Compliance TP
- **Metodo:** CUP (Comparable Uncontrolled Price)
- **Benchmark:** Fee di servizio sviluppo nel settore rinnovabili Italia
- **Documentazione:** Master File Italia 2024, Local File iCube

---

*Template pronto per popolamento dati veri da Claude Code | Fonte: Service Agreement 20221223 + Amendment 20241118*