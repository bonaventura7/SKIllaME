---
title: "SVC-AssetMgmt-Bramante — Asset Management Post-COD"
date: 2026-04-30
type: service-catalog
category: Catalog
status: draft
project: "Innovo-Renewables"
service_provider: "[[Innovo Renewables S.p.A.]]"
client: "[[Bramante S.r.l.]]"
service_type: AssetManagement
nature: obbligazione_di_risultato
pricing_model: fee_variabile
annual_fee: 1200
fee_currency: EUR
fee_unit: per_MW_annuo
billing_frequency: Annuale
exclusivity: nessuna
scope_summary: "Gestione tecnica e commerciale impianti agrivoltaici post-COD: SCADA, manutenzione, agronomia, relazioni GSE"
related_agreements:
  - "[[../Agreements/AGR-TechCommMgmt-Pineta-2024]]"
related:
  - "[[SVC-Development-iCube-20221223]]"
  - "[[../Operations/OPS-SCADA-Monitoring-2024]]"
  - "[[../Operations/OPS-AgriPV-Compliance-2024]]"
tags:
  - innovo
  - svc
  - asset-management
  - bramante
  - post-cod
  - agrivoltaico
  - scada
---

# SVC-AssetMgmt-Bramante — Asset Management Post-COD

## Overview
Servizio di gestione tecnica e commerciale per impianti fotovoltaici entrati in esercizio (post-COD), con focus su impianti agrivoltaici del "Progetto Pineta".

## Scope Dettagliato

### Gestione Tecnica
- Monitoraggio proattivo tramite **SCADA**
- Analisi performance e benchmarking inverter
- Coordinamento fornitori manutenzione (**MSP**)
- Gestione guasti e interventi correttivi

### Asset Management Agrivoltaico
- Supervisione operazioni agricole
- Monitoraggio dati agronomici (sensori)
- Verifica conformita' requisiti **AgriPV** per incentivazione (PNRR)

### Relazioni Esterne
- Interfaccia **GSE** per tariffe incentivanti (CFD)
- Relazioni con distributori di rete (Terna, Enel, etc.)
- Gestione rapporti con proprietari terreni

### Treasury & Bookkeeping
- Gestione ordini di pagamento
- Waterfall distribuzione cash flow
- Riconciliazione conti correnti e prestiti
- Tenuta libri sociali e registri IVA

## Remunerazione
> **EUR 1.200 per MW** di capacita' installata, **annuo**.

| Impianto | MW | Fee Annuale | Stato |
|----------|-----|-------------|-------|
| Progetto Pineta — Massa Marittima | *da popolare* | *calcolare* | In esercizio |

## Natura Giuridica
> **Obbligazione di risultato** per la gestione operativa (manutenzione, reporting).
> **Obbligazione di mezzi** per la performance agronomica (dipendente da fattori climatici).

## Compliance TP
- **Metodo:** TNMM (Transactional Net Margin Method)
- **Benchmark:** Margini operatori O&M fotovoltaico Italia
- **Documentazione:** Da integrare in Local File 2025

---

*Template pronto per popolamento dati veri | Fonte: Innovo Renewables-SPVs_Asset Management Agreement_20260209*