---
title: "SVC-Engineering-PH — Servizi di Ingegneria Specialistica"
date: 2026-04-30
type: service-catalog
category: Catalog
status: active
project: "Innovo-Renewables"
service_provider: "[[Innovo PH Engineering Services S.r.l.]]"
client: "[[Gruppo Innovo Renewables]]"
service_type: Engineering
nature: obbligazione_di_mezzi
pricing_model: tariffa_oraria
annual_fee: null
fee_currency: EUR
billing_frequency: A_milestone
exclusivity: parziale
scope_summary: "Progettazione, consulenza tecnica e attivita' ordinistiche professionali per accelerare la pipeline interna"
related_agreements:
  - "[[../Agreements/AGR-Services-InnovoPH-2024]]"
related:
  - "[[SVC-Development-iCube-20221223]]"
  - "[[../Agreements/AGR-PriceAdjustment-PH-2025]]"
tags:
  - innovo
  - svc
  - engineering
  - ph-engineering
  - progettazione
  - inarcassa
  - ordinistiche
---

# SVC-Engineering-PH — Servizi di Ingegneria Specialistica

## Overview
Centro di competenza ingegneristico interno al gruppo, acquisito tramite l'operazione straordinaria di **PH Engineering**. Fornisce servizi di progettazione e consulenza tecnica per i progetti del gruppo.

## Scope Dettagliato

### Attivita' Professionali
- Progettazione impianti fotovoltaici (preliminare, definitiva, esecutiva)
- Consulenza tecnica su tecnologie e layout
- Supporto alle attivita' di permitting (disegni, relazioni tecniche)

### Attivita' Ordinistiche
> Prestazioni soggette a specifiche tariffe professionali e iscrizioni ad albi.

- Progettazione strutturale (Inarcassa)
- Certificazioni e collaudi
- Direzione lavori

## Entita'
- **Fornitore:** Innovo PH Engineering Services S.r.l.
- **Centro di competenza:** Team ingegneri specializzati
- **Clienti interni:** Innovo SpA, iCube, SPV operative

## Pricing Model
- **Tariffa oraria professionale** per attivita' standard
- **Fee a milestone** per progetti strutturati
- **Cost-plus** per attivita' di R&D

## Operazione Straordinaria
- **Acquisizione:** PH Engineering integrato nel gruppo
- **Price Adjustment:** Regolazione prezzo novembre 2025
- **Questioni previdenziali:** Gestione passivita' Inarcassa tramite indennizzi e accantonamenti fiscali
- Riferimento: [[AGR-PriceAdjustment-PH-2025]]

## Compliance TP
- **Metodo:** CUP per servizi ingegneria standardizzati
- **Metodo:** Cost-plus per attivita' di R&D
- **Documentazione:** Da integrare in Master File 2025

---

*Template pronto per popolamento dati veri | Fonte: Services Agreement Innovo-PH + Price Adjustment Letter*