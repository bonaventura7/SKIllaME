---
title: "Catalog — Definizioni Atomiche dei Servizi"
date: 2026-04-30
type: MOC
category: Catalog
status: active
project: "Innovo-Renewables"
related:
  - "[[../00_MOC_Services]]"
  - "[[SVC-Development-iCube-20221223]]"
  - "[[SVC-AssetMgmt-Bramante-2024]]"
  - "[[SVC-Engineering-PH-2024]]"
tags:
  - innovo
  - catalog
  - services
  - atomic-definitions
---

# Catalog — Definizioni Atomiche dei Servizi

> Ogni nota in questa cartella definisce **una tipologia di servizio** con scope, natura giuridica, KPI e pricing model.

## Servizi Catalogati

| Servizio | Entita' Fornitore | Entita' Cliente | Modello Fee | Stato |
|----------|-------------------|-----------------|-------------|-------|
| [[SVC-Development-iCube-20221223]] | Innovo Renewables S.p.A. | iCube Renewables S.r.l. | Fee annuale fissa | Attivo |
| [[SVC-AssetMgmt-Bramante-2024]] | Innovo Renewables S.p.A. | Bramante S.r.l. / SPV | EUR 1.200/MW/anno | Bozza |
| [[SVC-Engineering-PH-2024]] | Innovo PH Engineering S.r.l. | Gruppo Innovo | Tariffe professionali | Attivo |

## Template per Nuovo Servizio

```yaml
---
title: "SVC-[Tipologia]-[Cliente]-[YYYYMMDD]"
service_provider: "[[Entita' fornitrice]]"
client: "[[Entita' cliente]]"
service_type: [Development | AssetManagement | Engineering | Treasury | Other]
nature: [obbligazione_di_mezzi | obbligazione_di_risultato | best_efforts]
pricing_model: [fee_fissa | fee_variabile | cost_plus | tariffa_oraria]
annual_fee: [importo]
fee_currency: EUR
billing_frequency: [Mensile | Trimestrale | Annuale | A_milestone]
exclusivity: [totale | parziale | nessuna]
scope_summary: ""
status: [Active | Draft | Terminated]
related_agreements: []
---
```