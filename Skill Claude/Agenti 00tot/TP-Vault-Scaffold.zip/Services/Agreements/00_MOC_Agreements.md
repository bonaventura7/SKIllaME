---
title: "Agreements — Accordi Contrattuali Infragruppo"
date: 2026-04-30
type: MOC
category: Agreements
status: active
project: "Innovo-Renewables"
related:
  - "[[../00_MOC_Services]]"
  - "[[AGR-iCube-Innovo-20221223]]"
  - "[[AGR-Amendment-iCube-20241118]]"
  - "[[AGR-TechCommMgmt-Pineta-2024]]"
  - "[[AGR-Services-InnovoPH-2024]]"
  - "[[AGR-NotionalCashPooling-2024]]"
tags:
  - innovo
  - agreements
  - contracts
  - legal
  - infragruppo
---

# Agreements — Accordi Contrattuali Infragruppo

> **Registro contratti** del Gruppo Innovo. Ogni nota rappresenta un accordo legale con le sue clausole chiave, fee structure e compliance TP.

## Accordi Attivi

| Contratto | Tipo | Parti | Data | Stato |
|-----------|------|-------|------|-------|
| [[AGR-iCube-Innovo-20221223]] | Service Agreement | iCube <-> Innovo | 23/12/2022 | Attivo |
| [[AGR-Amendment-iCube-20241118]] | Amendment Fee | iCube <-> Innovo | 18/11/2024 | Attivo |
| [[AGR-TechCommMgmt-Pineta-2024]] | Asset Management | Innovo <-> Bramante/SPV | 2024 | Bozza |
| [[AGR-Services-InnovoPH-2024]] | Services Agreement | Innovo <-> PH Engineering | 2024 | Attivo |
| [[AGR-NotionalCashPooling-2024]] | Cash Pooling | Gruppo Innovo | 2024 | Attivo |
| [[AGR-PriceAdjustment-PH-2025]] | Price Adjustment | Innovo <-> PH Engineering | 2025 | Attivo |

## Finanziamenti Intercompany (Loan Agreements)

| Contratto | Tipo | Erogatore | Ricevente | Importo | Tasso |
|-----------|------|-----------|-----------|---------|-------|
| [[FIN-ShareholderLoan-Aviva-2024]] | SHL Principale | Aviva (AEIS) | Innovo SpA | EUR 25.000.000 | 9,75% |
| [[FIN-ShareholderLoan-AssetCo-2024]] | SHL Cascata | Innovo SpA | Innovo Power Generation S.r.l. | Cascata | 9,85% |
| [[FIN-ShareholderLoan-BorrowerCo-2024]] | SHL Cascata | IPG S.r.l. | IPG 1 S.r.l. | Cascata | 9,95% |
| [[FIN-Loan-iCube-ID7-20230719]] | Prestito soci | iCube | Innovo Dev 7 S.r.l. | *da popolare* | *da popolare* |
| [[FIN-Loan-Innovo-ETPAR-20231025]] | Prestito soci | Innovo SpA | ETP-AR Energy Limited | *da popolare* | *da popolare* |

## Template per Nuovo Accordo

```yaml
---
title: "AGR-[ParteA]-[ParteB]-[YYYYMMDD]"
contract_type: [ServiceAgreement | Amendment | LoanAgreement | CashPooling | Other]
party_a: "[[Entita' A]]"
party_b: "[[Entita' B]]"
contract_date: YYYY-MM-DD
effective_date: YYYY-MM-DD
expiration_date: YYYY-MM-DD
annual_fee: [importo]
fee_currency: EUR
payment_terms: [Annuale | Trimestrale | A_milestone]
exclusivity_clause: [true | false]
termination_clause: ""
governing_law: "Diritto italiano / inglese / altro"
related_services: []
related_financials: []
status: [Active | Draft | Terminated | Expired]
---
```