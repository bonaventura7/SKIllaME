---
title: "AGR-Amendment-iCube — Aggiornamento Fee 2024 (+50%)"
date: 2026-04-30
type: agreement
category: Agreements
status: active
project: "Innovo-Renewables"
contract_type: Amendment
party_a: "[[iCube Renewables S.r.l.]]"
party_b: "[[Innovo Renewables S.p.A.]]"
contract_date: 2024-11-18
effective_date: 2024-01-01
expiration_date: null
annual_fee: 1307793
fee_currency: EUR
fee_increase_pct: 50
previous_fee: 871862
payment_terms: Annuale
exclusivity_clause: true
termination_clause: "Mantiene condizioni contratto originale"
governing_law: "Diritto italiano"
related_services:
  - "[[../../Catalog/SVC-Development-iCube-20221223]]"
related_financials:
  - "[[../Financials/FIN-TP-FeeStructure-2024]]"
related:
  - "[[AGR-iCube-Innovo-20221223]]"
tags:
  - innovo
  - agreement
  - icube
  - amendment
  - fee-update
  - 2024
---

# AGR-Amendment-iCube — Aggiornamento Fee 2024 (+50%)

## Parti Contrattuali
- **Committente:** iCube Renewables S.r.l.
- **Fornitore:** Innovo Renewables S.p.A.
- **Data firma:** 18 novembre 2024
- **Decorrenza:** Retroattiva al 1 gennaio 2024

## Oggetto dell'Amendment
Aggiornamento della fee annuale per riflettere l'**ampliamento delle attivita'** svolte da Innovo a favore di iCube nel 2024.

## Variazione Fee

| Parametro | Valore |
|-----------|--------|
| Fee precedente | EUR 871.862 |
| Nuova fee | **EUR 1.307.793** |
| Incremento assoluto | **+EUR 435.931** |
| Incremento percentuale | **+50%** |

## Giustificazione dell'Aumento
- Espansione pipeline progetti (passaggio da X a Y MW in sviluppo attivo)
- Aumento complessita' permitting (AgriPV, storage)
- Integrazione nuove competenze ingegneristiche (PH Engineering)
- Maggiore coordinamento societario (aumento da 19 a 32 dipendenti)

## Scope Aggiornato
Mantiene le stesse categorie del contratto originale ma con **volume e complessita' aumentati**:
- Management Services (ampliamento attivita' treasury e reporting)
- Development Services (piu' progetti in parallelo, nuove tecnologie)

## Clausole Invariate
- Esclusivita' totale Italia
- Obbligazione di mezzi
- Recesso 180 giorni
- Rinnovo tacito

## Compliance TP
- **Metodo:** CUP aggiornato
- **Benchmark:** Fee sviluppo rinnovabili Italia 2024
- **Documentazione:** Da integrare in Local File 2024
- **Nota:** L'incremento del 50% deve essere giustificato con benchmark aggiornati o analisi cost-plus

---

*Fonte: 20241118-Service Agreement IR - Amendment- EXE Proposta_signed.pdf*