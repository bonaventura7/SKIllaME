---
title: "AGR-TechCommMgmt-Pineta — Asset Management Agreement (Bozza)"
date: 2026-04-30
type: agreement
category: Agreements
status: draft
project: "Innovo-Renewables"
contract_type: AssetManagementAgreement
party_a: "[[Innovo Renewables S.p.A.]]"
party_b: "[[Bramante S.r.l.]]"
contract_date: 2024-02-09
effective_date: null
expiration_date: null
annual_fee: null
fee_currency: EUR
fee_unit: per_MW_annuo
fee_per_mw: 1200
payment_terms: Annuale
exclusivity_clause: false
termination_clause: "Da definire in bozza"
governing_law: "Diritto italiano"
related_services:
  - "[[../../Catalog/SVC-AssetMgmt-Bramante-2024]]"
related_financials:
  - "[[../Financials/FIN-TP-FeeStructure-2024]]"
related:
  - "[[OPS-SCADA-Monitoring-2024]]"
  - "[[OPS-AgriPV-Compliance-2024]]"
tags:
  - innovo
  - agreement
  - bramante
  - asset-management
  - post-cod
  - agrivoltaico
  - bozza
---

# AGR-TechCommMgmt-Pineta — Asset Management Agreement (Bozza)

## Parti Contrattuali
- **Fornitore:** Innovo Renewables S.p.A.
- **Cliente:** Bramante S.r.l. (SPV operativa)
- **Data bozza:** 9 febbraio 2024
- **Stato:** Bozza in approvazione

## Oggetto
Fornitura di servizi di **Technical and Commercial Management** per impianti fotovoltaici agrivoltaici post-COD.

## Fee Structure
> **EUR 1.200 per MW** di capacita' installata, **annuo**.

| Impianto | Localita' | MW Stimati | Fee Annuale Stimata |
|----------|-----------|------------|---------------------|
| Progetto Pineta | Massa Marittima | *da popolare* | *calcolare* |

## Scope Dettagliato (dalla bozza)

### Technical Management
- Monitoraggio performance SCADA
- Benchmarking inverter e moduli
- Coordinamento manutenzione preventiva e correttiva
- Gestione garanzie fornitori

### Commercial Management
- Interfaccia GSE per CFD
- Gestione fatturazione energia
- Riconciliazione pagamenti
- Relazioni con distributori rete

### Agricultural Management (AgriPV)
- Supervisione operazioni agricole
- Monitoraggio sensori agronomici
- Compliance requisiti PNRR AgriPV
- Reportistica incentivante

### Treasury & Administration
- Gestione ordini pagamento
- Waterfall cash flow
- Riconciliazione bancaria
- Bookkeeping SPV

## Clausole da Definire
- [ ] Durata contratto
- [ ] Penali per underperformance
- [ ] Escalator fee (ISTAT / CPI)
- [ ] Clausola recesso
- [ ] Transfer pricing documentation

## Compliance TP
- **Metodo proposto:** TNMM
- **Benchmark:** Margini O&M settore fotovoltaico Italia
- **Documentazione:** Da preparare per Local File 2025

---

*Fonte: Innovo Renewables-SPVs_Asset Management Agreement_20260209.docx (bozza)*