---
title: "AGR-NotionalCashPooling — Contratto Quadro Tesoreria Accentrata"
date: 2026-04-30
type: agreement
category: Agreements
status: active
project: "Innovo-Renewables"
contract_type: CashPoolingAgreement
party_a: "[[Innovo Renewables S.p.A.]]"
party_b: "[[Partecipate Gruppo Innovo]]"
contract_date: 2024-01-01
effective_date: 2024-01-01
expiration_date: null
annual_fee: 0
fee_currency: EUR
payment_terms: N_A
exclusivity_clause: true
termination_clause: "Recesso con preavviso 90 giorni"
governing_law: "Diritto italiano / inglese per entita' UK"
related_services:
  - "[[../../Catalog/SVC-Development-iCube-20221223]]"
related_financials:
  - "[[../Financials/FIN-ShareholderLoan-Aviva-2024]]"
  - "[[../Financials/FIN-ShareholderLoan-AssetCo-2024]]"
  - "[[../Financials/FIN-ShareholderLoan-BorrowerCo-2024]]"
related:
  - "[[FIN-NotionalCashPooling-2024]]"
tags:
  - innovo
  - agreement
  - cash-pooling
  - treasury
  - pool-leader
  - notional
  - virtual-compensation
---

# AGR-NotionalCashPooling — Contratto Quadro Tesoreria Accentrata

## Parti Contrattuali
- **Pool Leader:** Innovo Renewables S.p.A.
- **Partecipanti:** Tutte le societa' del Gruppo Innovo (27 entita')
- **Banca:** *Da popolare*

## Oggetto
Gestione accentrata della liquidita' di gruppo tramite sistema di **Notional Cash Pooling** in valute EUR e GBP.

## Meccanismo Operativo

```
+-------------------------------------------------------------+
|                    NOTIONAL CASH POOLING                     |
+-------------------------------------------------------------+
|  Pool Leader: Innovo Renewables S.p.A.                      |
|                                                              |
|  +-------------+  +-------------+  +-------------+         |
|  |  iCube      |  |  IPG S.r.l. |  |  ETP-AR     |         |
|  |  +EUR 500K  |  |  -EUR 300K  |  |  +EUR 200K  |         |
|  +------+------+  +------+------+  +------+------+         |
|         |                |                |                 |
|         +----------------+----------------+                 |
|                          |                                  |
|              Compensazione Virtuale                         |
|              Saldo Netto: +EUR 400K                         |
|                          |                                  |
|              +-----------+-----------+                      |
|              |                       |                      |
|     Ottimizzazione              Conversione                 |
|     interessi attivi            in Shareholder              |
|     (debiti compensati)         Loan al 31/12               |
+-------------------------------------------------------------+
```

## Caratteristiche Tecniche
- **Tipo:** Notional (non fisico) -- nessun trasferimento reale di fondi
- **Valute:** EUR, GBP
- **Compensazione:** Virtuale dei saldi debitori/creditori
- **Ottimizzazione:** Riduzione oneri bancari esterni
- **Rendimento:** Miglioramento sui saldi attivi

## Conversione Annuale
Al **31 dicembre** di ogni anno:
- I saldi netti del pool possono essere **convertiti automaticamente** in **Shareholders' Loans**
- Tasso di interesse: da definire in linea con TP (*arm's length*)
- Documentazione: loan agreement separato per ogni conversione

## Ruolo Innovo SpA
> **Pool Leader** con responsabilita' di:
> - Gestione flussi EUR/GBP
> - Coordinamento con banca
> - Reportistica infragruppo
> - Conversione saldi in prestiti soci

## Partecipanti Confermati
| Entita' | Paese | Valuta | Stato |
|---------|-------|--------|-------|
| iCube Renewables S.r.l. | Italia | EUR | Attivo |
| Innovo Power Generation S.r.l. | Italia | EUR | Attivo |
| Innovo Power Generation 1 S.r.l. | Italia | EUR | Attivo |
| ETP-AR Energy Limited | UK | GBP | Attivo |
| Innovo Development 7 S.r.l. | Italia | EUR | Attivo |
| *Altre 22 entita'* | *Italia/UK/Spagna/Germania* | *EUR/GBP* | *Da verificare* |

## Compliance TP
- **Metodo:** CUP per servizi treasury standardizzati
- **Pricing:** Fee pool leader a valore di mercato (se applicabile)
- **Interessi:** Tassi su shareholder loans conformi a Safe Harbour o benchmark mercato
- **Documentazione:** Master File + Local File per ogni giurisdizione

---

*Fonte: REP - Bozza Cash Pooling (contratto quadro e regole operative)*