---
title: "AGR-PriceAdjustment-PH — Regolazione Acquisizione PH Engineering"
date: 2026-04-30
type: agreement
category: Agreements
status: active
project: "Innovo-Renewables"
contract_type: PriceAdjustment
party_a: "[[Innovo Renewables S.p.A.]]"
party_b: "[[PH Engineering S.r.l.]]"
contract_date: 2025-11-01
effective_date: 2025-11-01
expiration_date: null
annual_fee: null
fee_currency: EUR
payment_terms: A_milestone
exclusivity_clause: false
termination_clause: "Definitivo per acquisizione"
governing_law: "Diritto italiano"
related_services:
  - "[[../../Catalog/SVC-Engineering-PH-2024]]"
related_financials:
  - "[[../Financials/FIN-TP-FeeStructure-2024]]"
related:
  - "[[AGR-Services-InnovoPH-2024]]"
tags:
  - innovo
  - agreement
  - ph-engineering
  - price-adjustment
  - acquisizione
  - inarcassa
  - 2025
---

# AGR-PriceAdjustment-PH — Regolazione Acquisizione PH Engineering

## Parti Contrattuali
- **Acquirente:** Innovo Renewables S.p.A.
- **Target:** PH Engineering S.r.l. (poi Innovo PH Engineering Services S.r.l.)
- **Data regolazione:** Novembre 2025

## Oggetto
Regolazione del prezzo di acquisizione di PH Engineering, inclusa gestione di:
- Passivita' potenziali legate a contributi previdenziali (**Inarcassa**)
- Accantonamenti fiscali
- Indennizzi specifici

## Struttura della Transazione

| Componente | Descrizione | Stato |
|------------|-------------|-------|
| Prezzo base | *Da popolare* | Definito |
| Price adjustment | Regolazione post-closing | Firmato |
| Indennizzo Inarcassa | Copertura passivita' previdenziali | Pattuito |
| Accantonamenti fiscali | Gestione rischi fiscali | Definito |

## Question Previdenza (Inarcassa)
- **Rischio:** Contributi previdenziali non versati o contestati
- **Mitigazione:** Indennizzo specifico a carico del venditore
- **Copertura:** Accantonamento fiscale per rischio residual
- **Monitoraggio:** Verifica annuale posizione contributiva

## Integrazione Post-Acquisizione
- Rinominata in **Innovo PH Engineering Services S.r.l.**
- Integrata nel gruppo come centro di competenza ingegneristico
- Servizi forniti a tutte le entita' del gruppo
- Riferimento: [[SVC-Engineering-PH-2024]]

## Compliance TP
- **Metodo:** Valutazione a fair value per price adjustment
- **Documentazione:** Da integrare in Master File 2025
- **Nota:** L'operazione deve essere documentata per eventuali controlli sulla valutazione del goodwill

---

*Fonte: Price Adjustment Letter (firmato) + Ottobre 25_Group Structure Chart*