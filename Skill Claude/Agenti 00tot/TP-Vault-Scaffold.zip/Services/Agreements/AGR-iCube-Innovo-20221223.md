---
title: "AGR-iCube-Innovo — Service Agreement Originale (2022)"
date: 2026-04-30
type: agreement
category: Agreements
status: active
project: "Innovo-Renewables"
contract_type: ServiceAgreement
party_a: "[[iCube Renewables S.r.l.]]"
party_b: "[[Innovo Renewables S.p.A.]]"
contract_date: 2022-12-23
effective_date: 2023-01-01
expiration_date: null
annual_fee: 871862
fee_currency: EUR
payment_terms: Annuale
exclusivity_clause: true
termination_clause: "Recesso con preavviso 180 giorni, salvo cause di forza maggiore"
governing_law: "Diritto italiano"
related_services:
  - "[[../../Catalog/SVC-Development-iCube-20221223]]"
related_financials:
  - "[[../Financials/FIN-TP-FeeStructure-2024]]"
related:
  - "[[AGR-Amendment-iCube-20241118]]"
tags:
  - innovo
  - agreement
  - icube
  - service-agreement
  - originale
  - 2022
---

# AGR-iCube-Innovo — Service Agreement Originale (2022)

## Parti Contrattuali
- **Committente:** iCube Renewables S.r.l. (JV Iberdrola)
- **Fornitore:** Innovo Renewables S.p.A. (capogruppo)
- **Data firma:** 23 dicembre 2022
- **Decorrenza:** 1 gennaio 2023

## Oggetto
Fornitura integrata di servizi di **gestione amministrativa** e **sviluppo progetti** per il territorio italiano.

## Fee Structure Originale
| Voce | Importo | Note |
|------|---------|------|
| Fee annuale complessiva | **EUR 871.862** | Pagamento annuale anticipato |
| Ricalcolo ISTAT | Si' | Aggiornamento annuale |

## Scope Originale
- Management Services (domiciliazione, accounting, tax, treasury)
- Development Services (origination, permitting, interconnessione)

## Clausole Chiave
- **Esclusivita':** Totale in Italia per iCube/Iberdrola
- **Natura:** Obbligazione di mezzi
- **Recesso:** 180 giorni di preavviso
- **Rinnovo:** Tacito rinnovo salvo disdetta

## Storico Modifiche
| Data | Evento | Nuova Fee | Riferimento |
|------|--------|-----------|-------------|
| 23/12/2022 | Contratto originale | EUR 871.862 | Questo documento |
| 18/11/2024 | Amendment fee | **EUR 1.307.793** | [[AGR-Amendment-iCube-20241118]] |

## Compliance TP
- **Metodo:** CUP
- **Benchmark:** Fee sviluppo rinnovabili Italia 2022
- **Documentazione:** Inclusa in Master File 2023

---

*Fonte: 20221223_ICube-Innovo Group_Service Agreement.pdf*