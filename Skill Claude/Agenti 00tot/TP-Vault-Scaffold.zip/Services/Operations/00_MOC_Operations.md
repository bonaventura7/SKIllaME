---
title: "Operations — Output Operativi e Reporting"
date: 2026-04-30
type: MOC
category: Operations
status: active
project: "Innovo-Renewables"
related:
  - "[[../00_MOC_Services]]"
  - "[[OPS-SCADA-Monitoring-2024]]"
  - "[[OPS-AgriPV-Compliance-2024]]"
  - "[[OPS-Reporting-SAL-2024]]"
tags:
  - innovo
  - operations
  - reporting
  - scada
  - agrivoltaico
---

# Operations — Output Operativi e Reporting

> Documentazione operativa generata dall'esecuzione dei servizi infragruppo: monitoraggio tecnico, compliance agronomica, verbali di stato avanzamento lavori.

## Note Operative

| Nota | Tipo | Progetto | Frequenza | Stato |
|------|------|----------|-----------|-------|
| [[OPS-SCADA-Monitoring-2024]] | Monitoring | Pineta / Bramante | Continuo | Attivo |
| [[OPS-AgriPV-Compliance-2024]] | Compliance | Pineta / Bramante | Trimestrale | Attivo |
| [[OPS-Reporting-SAL-2024]] | Verbali | Vari | A milestone | Bozza |

## Template Operativo

```yaml
---
title: "OPS-[Tipo]-[Progetto]-[YYYYMMDD]"
operation_type: [SCADA | AgriPV | SAL | Maintenance | Other]
project: "[[Progetto riferimento]]"
service_ref: "[[Servizio correlato]]"
date: YYYY-MM-DD
author: "[[Autore]]"
status: [Draft | Final | Approved]
---
```