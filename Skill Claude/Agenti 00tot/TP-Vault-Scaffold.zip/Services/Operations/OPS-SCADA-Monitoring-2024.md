---
title: "OPS-SCADA-Monitoring — Monitoraggio Impianti Progetto Pineta"
date: 2026-04-30
type: operations
category: Operations
status: active
project: "Innovo-Renewables"
operation_type: SCADA
project_ref: "[[Progetto Pineta]]"
service_ref: "[[../../Catalog/SVC-AssetMgmt-Bramante-2024]]"
agreement_ref: "[[../../Agreements/AGR-TechCommMgmt-Pineta-2024]]"
location: "Massa Marittima (GR)"
monitoring_system: "SCADA"
frequency: Continuo
related:
  - "[[OPS-AgriPV-Compliance-2024]]"
  - "[[../../Catalog/SVC-AssetMgmt-Bramante-2024]]"
tags:
  - innovo
  - ops
  - scada
  - monitoring
  - pineta
  - bramante
  - post-cod
---

# OPS-SCADA-Monitoring — Monitoraggio Impianti Progetto Pineta

## Overview
Sistema di monitoraggio proattivo degli impianti fotovoltaici del **Progetto Pineta** gestiti da Bramante S.r.l. tramite piattaforma SCADA.

## Impianti Monitorati

| Impianto | Localita' | MW | Stato | Data COD |
|----------|-----------|-----|-------|----------|
| Pineta 1 | Massa Marittima | *da popolare* | In esercizio | *da popolare* |
| Pineta 2 | Massa Marittima | *da popolare* | In esercizio | *da popolare* |

## Metriche SCADA (Template)

### Performance Ratio (PR)
```
PR = (Energia effettiva / Energia teorica) x 100
Target: > 82%
```

### Benchmarking Inverter
| Inverter | Marca | Modello | Efficienza | Stato |
|----------|-------|---------|------------|-------|
| INV-001 | *da popolare* | *da popolare* | *da popolare* | OK |

### Allarmi e Anomalie
| Data | Allarme | Gravita' | Azione | Stato |
|------|---------|----------|--------|-------|
| *da popolare* | *da popolare* | *da popolare* | *da popolare* | *da popolare* |

## Manutenzione
- **Preventiva:** Programmata trimestrale
- **Correttiva:** A chiamata (target TTR < 48h)
- **Fornitore MSP:** *Da popolare*

## Reporting
- **Giornaliero:** Dashboard produzione
- **Settimanale:** Report performance e anomalie
- **Mensile:** Report completo per Asset Management

## Integrazione AgriPV
- Dati SCADA correlati a [[OPS-AgriPV-Compliance-2024]]
- Performance energetica vs performance agronomica
- Reportistica congiunta per GSE e PNRR

---

*Template pronto per popolamento dati reali da SCADA | Fonte: Technical and Commercial Management Agreement*