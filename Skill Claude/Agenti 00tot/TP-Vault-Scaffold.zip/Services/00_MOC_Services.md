---
title: "Services — MOC Layer Servizi Infragruppo"
date: 2026-04-30
type: MOC
category: Map-of-Content
status: active
project: "Innovo-Renewables"
related:
  - "[[../00_MOC_Innovo_Services]]"
  - "[[Catalog/00_MOC_Catalog]]"
  - "[[Agreements/00_MOC_Agreements]]"
  - "[[Operations/00_MOC_Operations]]"
  - "[[Financials/00_MOC_Financials]]"
tags:
  - innovo
  - moc
  - services
  - layer-2
---

# Services — MOC Layer Servizi

> **Separation of Concerns:** ogni sottocartella rappresenta un dominio funzionale del sistema SOA documentale.

## Sottocartelle

| Cartella | Scopo | Naming Prefix |
|----------|-------|---------------|
| `Catalog/` | Definizioni atomiche dei servizi | `SVC-` |
| `Agreements/` | Contratti legali e accordi | `AGR-` |
| `Operations/` | Output operativi e reporting | `OPS-` |
| `Financials/` | Fee, TP, Cash Pooling, Loans | `FIN-` |

## Navigazione
- -> [[Catalog/00_MOC_Catalog|Catalogo Servizi]]
- -> [[Agreements/00_MOC_Agreements|Accordi Contrattuali]]
- -> [[Operations/00_MOC_Operations|Operazioni]]
- -> [[Financials/00_MOC_Financials|Financials & TP]]