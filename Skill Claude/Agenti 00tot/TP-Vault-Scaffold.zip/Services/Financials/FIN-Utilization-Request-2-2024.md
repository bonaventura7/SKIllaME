---
title: "FIN-Utilization-Request-2 — Seconda Tranche (EUR 3,12M)"
date: 2026-04-30
type: financials
category: Financials
status: active
project: "Innovo-Renewables"
financial_type: Utilization
amount: 3120000
currency: EUR
party_from: "[[Innovo Power Generation 1 S.r.l.]]"
party_to: "[[Progetti Pink, Tarallo, Acquacotta]]"
rate: null
rate_type: N_A
reference_rate: None
spread: null
maturity: null
tp_method: N_A
tp_documentation: N_A
related_agreements:
  - "[[../../Agreements/AGR-NotionalCashPooling-2024]]"
related:
  - "[[FIN-ShareholderLoan-BorrowerCo-2024]]"
  - "[[FIN-Utilization-Request-1-2024]]"
tags:
  - innovo
  - fin
  - utilization
  - erogazione
  - pink
  - tarallo
  - acquacotta
  - 2024
---

# FIN-Utilization-Request-2 — Seconda Tranche (EUR 3,12M)

## Overview
Seconda richiesta irrevocabile di utilizzo del finanziamento a cascata per l'acquisizione di ulteriori progetti fotovoltaici.

## Struttura della Richiesta

| Parametro | Valore |
|-----------|--------|
| **Importo** | **EUR 3.120.000** |
| **Richiedente** | Innovo Power Generation 1 S.r.l. (BorrowerCo) |
| **Beneficiario finale** | Progetti operativi |
| **Data richiesta** | Dicembre 2024 |
| **Stato** | Erogato |

## Progetti Finanziati

| Progetto | Localita' | MW Stimati | Stato | Note |
|----------|-----------|------------|-------|------|
| **Pink** | *Da popolare* | *Da popolare* | Acquisito | RtB |
| **Tarallo** | *Da popolare* | *Da popolare* | Acquisito | RtB |
| **Acquacotta** | *Da popolare* | *Da popolare* | Acquisito | RtB |

## Flusso Documentale

### Richiesta 2 (da BorrowerCo verso AssetCo)
- **Documento:** Utilization Request n. 2 — Innovo Power Generation 1 S.r.l. -> Innovo Power Generation S.r.l.
- **Importo:** EUR 3.120.000
- **Finalita':** Acquisizione progetti Pink, Tarallo, Acquacotta

### Richiesta 2 (da AssetCo verso Capogruppo)
- **Documento:** Utilization Request n. 2 — Innovo Power Generation S.r.l. -> Innovo Renewables S.p.A.
- **Importo:** EUR 3.120.000
- **Finalita':** Medesima

## Cumulo Utilizations
| Tranche | Importo | Progetti | Stato |
|---------|---------|----------|-------|
| Utilization 1 | EUR 5.630.000 | Rose Garden, Cappella Cantone, Acquacotta | Erogato |
| Utilization 2 | EUR 3.120.000 | Pink, Tarallo, Acquacotta | Erogato |
| **Totale erogato** | **EUR 8.750.000** | -- | -- |
| **Residuo linea** | **EUR 16.250.000** | -- | -- |

## Compliance TP
- **Nota:** L'acquacotta compare in entrambe le utilizations — verificare se e' lo stesso progetto o due fasi distinte
- **Documentazione:** Valutazione fair value progetti acquisiti

---

*Fonte: Utilization Request n. 2.pdf (entrambe le controparti)*