---
title: "FIN-ShareholderLoan-BorrowerCo — Prestito Cascata IPG -> IPG1 (9,95%)"
date: 2026-04-30
type: financials
category: Financials
status: active
project: "Innovo-Renewables"
financial_type: ShareholderLoan
amount: null
currency: EUR
party_from: "[[Innovo Power Generation S.r.l.]]"
party_to: "[[Innovo Power Generation 1 S.r.l.]]"
rate: 9.95
rate_type: fisso
reference_rate: None
spread: 20
spread_basis: bp_vs_originale
maturity: null
tp_method: CUP
tp_documentation: Both
related_agreements:
  - "[[../../Agreements/AGR-NotionalCashPooling-2024]]"
related:
  - "[[FIN-ShareholderLoan-Aviva-2024]]"
  - "[[FIN-ShareholderLoan-AssetCo-2024]]"
  - "[[FIN-Utilization-Request-1-2024]]"
  - "[[FIN-Utilization-Request-2-2024]]"
tags:
  - innovo
  - fin
  - shareholder-loan
  - borrowerco
  - ipg1
  - cascata
  - 2024
---

# FIN-ShareholderLoan-BorrowerCo — Prestito Cascata IPG -> IPG1 (9,95%)

## Overview
Tranche finale del meccanismo di finanziamento a cascata. Innovo Power Generation S.r.l. (AssetCo) eroga finanziamenti a Innovo Power Generation 1 S.r.l. (BorrowerCo), la SPV operativa che detiene i progetti.

## Struttura

| Parametro | Valore |
|-----------|--------|
| **Erogatore** | Innovo Power Generation S.r.l. (AssetCo) |
| **Beneficiario** | Innovo Power Generation 1 S.r.l. (BorrowerCo) |
| **Tasso** | **9,95% fisso** |
| **Spread vs originale** | +20 bp (vs 9,75% Aviva->Innovo) |
| **Importo** | *Determinato da utilization requests* |

## Ruolo BorrowerCo
- **Funzione:** SPV operativa che detiene i progetti fotovoltaici
- **Controllo:** 100% AssetCo -> 100% Innovo SpA
- **Attivita':** Acquisizione terreni, sviluppo progetti, costruzione impianti
- **Cash flow:** Vendita energia -> rimborso prestiti -> dividendi verso AssetCo

## Utilization Requests Erogate
| Request | Importo | Progetti | Stato |
|---------|---------|----------|-------|
| [[FIN-Utilization-Request-1-2024]] | EUR 5.630.000 | Rose Garden, Cappella Cantone, Acquacotta | Erogato |
| [[FIN-Utilization-Request-2-2024]] | EUR 3.120.000 | Pink, Tarallo, Acquacotta | Erogato |

## Giustificazione Spread +20bp
- **Risk premium progetto specifico:** BorrowerCo e' esposta a rischi di sviluppo
- **Costo del capitale aggiuntivo:** Due livelli di holding intermedi
- **Benchmark:** Spread 15-35bp per SPV operative vs holding, settore energy

## Meccanismo Back-to-Back
```
Aviva -> Innovo:      EUR 25M @ 9,75%  (originale)
Innovo -> AssetCo:    Cascata  @ 9,85%  (+10bp)
AssetCo -> BorrowerCo: Cascata  @ 9,95%  (+20bp)
                        =========================
Totale spread:        +20bp (arm's length per struttura 3-livelli)
```

## Compliance TP
- **Metodo:** CUP per tasso di interesse infragruppo
- **Benchmark:** Prestini soci holding -> SPV, settore rinnovabili
- **Documentazione:** Master File + Local File
- **Nota:** Il tasso deve riflettere il profilo di rischio della SPV operativa

---

*Fonte: BorrowerCo Loan Agreement Docs + Utilization Requests*