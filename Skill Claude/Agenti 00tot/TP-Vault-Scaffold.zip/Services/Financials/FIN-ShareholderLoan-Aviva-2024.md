---
title: "FIN-ShareholderLoan-Aviva — Prestito Socio Principale (EUR 25M)"
date: 2026-04-30
type: financials
category: Financials
status: active
project: "Innovo-Renewables"
financial_type: ShareholderLoan
amount: 25000000
currency: EUR
party_from: "[[Aviva / AEIS]]"
party_to: "[[Innovo Renewables S.p.A.]]"
rate: 9.75
rate_type: fisso
reference_rate: None
spread: null
maturity: null
tp_method: CUP
tp_documentation: Both
related_agreements:
  - "[[../../Agreements/AGR-NotionalCashPooling-2024]]"
related:
  - "[[FIN-ShareholderLoan-AssetCo-2024]]"
  - "[[FIN-Utilization-Request-1-2024]]"
  - "[[FIN-Utilization-Request-2-2024]]"
tags:
  - innovo
  - fin
  - shareholder-loan
  - aviva
  - aeis
  - prestito-soci
  - 2024
---

# FIN-ShareholderLoan-Aviva — Prestito Socio Principale (EUR 25M)

## Overview
Finanziamento principale erogato dal socio di maggioranza **Aviva (tramite AEIS)** alla capogruppo Innovo Renewables S.p.A. per il finanziamento della pipeline di progetti.

## Struttura del Finanziamento

| Parametro | Valore |
|-----------|--------|
| **Erogatore** | Aviva / AEIS (Aviva European Infrastructure Securities) |
| **Beneficiario** | Innovo Renewables S.p.A. |
| **Importo** | **EUR 25.000.000** |
| **Tasso** | **9,75% fisso** |
| **Tipo tasso** | Fisso (non indicizzato) |
| **Durata** | *Da popolare* |
| **Scadenza** | *Da popolare* |
| **Rating Moody's** | Ba1 (AEIS/Aviva) |

## Meccanismo a Cascata

```
AEIS (Aviva) @ 9,75%
    |
    v
Innovo Renewables S.p.A.
    |
    v  SHL @ 9,85% (+10bp)
Innovo Power Generation S.r.l. (AssetCo)
    |
    v  SHL @ 9,95% (+20bp da originale)
Innovo Power Generation 1 S.r.l. (BorrowerCo)
    |
    v  Utilization Requests
Progetti operativi
```

## Spread Infragruppo
| Tranche | Spread vs originale | Giustificazione |
|---------|---------------------|-----------------|
| Innovo -> AssetCo | +10 bp | Risk premium entita' intermedia |
| AssetCo -> BorrowerCo | +20 bp | Risk premium progetto specifico |
| Totale cascata | +20 bp | Arm's length per struttura multi-livello |

## Utilizzo dei Fondi
| Utilization | Importo | Progetti | Data |
|-------------|---------|----------|------|
| [[FIN-Utilization-Request-1-2024]] | EUR 5.630.000 | Rose Garden, Cappella Cantone, Acquacotta | Dic 2024 |
| [[FIN-Utilization-Request-2-2024]] | EUR 3.120.000 | Pink, Tarallo, Acquacotta | Dic 2024 |
| [[FIN-Utilization-iCube-Iberdrola-2024]] | EUR 600.000 | Costi sviluppo iCube | 2024 |

## Compliance TP
- **Metodo:** CUP per tasso di interesse
- **Benchmark:** Corporate bond BBB/BB Italia, prestiti infragruppo settore energy
- **Safe Harbour:** Tasso entro range 9-11% per finanziamenti soci a medio-lungo termine
- **Documentazione:** Master File + Local File Italia

## Covenants e Condizioni
- [ ] Debt service coverage ratio (DSCR) > 1,2x
- [ ] Loan-to-value (LTV) < 75%
- [ ] Cash sweep annuale (excess cash flow)
- [ ] Restrizioni dividendi

---

*Fonte: Aviva/AEIS Loan Agreement Docs + Credit Rating Reports*