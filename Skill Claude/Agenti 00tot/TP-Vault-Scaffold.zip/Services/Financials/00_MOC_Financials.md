---
title: "Financials — Fee, Transfer Pricing e Struttura Finanziaria"
date: 2026-04-30
type: MOC
category: Financials
status: active
project: "Innovo-Renewables"
related:
  - "[[../00_MOC_Services]]"
  - "[[FIN-TP-FeeStructure-2024]]"
  - "[[FIN-ShareholderLoan-Aviva-2024]]"
  - "[[FIN-ShareholderLoan-AssetCo-2024]]"
  - "[[FIN-ShareholderLoan-BorrowerCo-2024]]"
  - "[[FIN-Utilization-Request-1-2024]]"
  - "[[FIN-Utilization-Request-2-2024]]"
  - "[[FIN-Utilization-iCube-Iberdrola-2024]]"
  - "[[FIN-NotionalCashPooling-2024]]"
  - "[[Dashboard_Service_Revenue]]"
tags:
  - innovo
  - financials
  - transfer-pricing
  - fee
  - cash-pooling
  - shareholder-loans
  - utilization
  - tp
---

# Financials — Fee, Transfer Pricing e Struttura Finanziaria

> **Centro di controllo finanziario** del Gruppo Innovo. Traccia fee structure, compliance Transfer Pricing, finanziamenti intercompany e ottimizzazione tesoreria.

## Dashboard Rapida

### Ricavi Servizi Infragruppo 2024
| Fonte | Importo | % Totale |
|-------|---------|----------|
| Service Agreement iCube | **EUR 1.307.793** | 99,99% |
| Altri contratti (cessati 2023) | EUR 111 | 0,01% |
| **TOTALE** | **EUR 1.307.904** | 100% |

### Struttura Finanziaria a Cascata
```
Aviva (AEIS) EUR 25M @ 9,75%
    |
Innovo Renewables S.p.A.
    |  SHL @ 9,85%
Innovo Power Generation S.r.l. (AssetCo)
    |  SHL @ 9,95%
Innovo Power Generation 1 S.r.l. (BorrowerCo)
    |  Utilization Requests
Progetti operativi (Rose Garden, Cappella Cantone, Acquacotta, Pink, Tarallo)
```

## Note Finanziarie

| Nota | Tipo | Importo | Stato |
|------|------|---------|-------|
| [[FIN-TP-FeeStructure-2024]] | TP Analysis | EUR 1.307.793 | Attivo |
| [[FIN-ShareholderLoan-Aviva-2024]] | SHL Principale | EUR 25.000.000 | Attivo |
| [[FIN-ShareholderLoan-AssetCo-2024]] | SHL Cascata | Cascata | Attivo |
| [[FIN-ShareholderLoan-BorrowerCo-2024]] | SHL Cascata | Cascata | Attivo |
| [[FIN-Utilization-Request-1-2024]] | Utilization | EUR 5.630.000 | Erogato |
| [[FIN-Utilization-Request-2-2024]] | Utilization | EUR 3.120.000 | Erogato |
| [[FIN-Utilization-iCube-Iberdrola-2024]] | Utilization | EUR 600.000 | Erogato |
| [[FIN-NotionalCashPooling-2024]] | Treasury | -- | Attivo |
| [[FIN-CostRecharge-2024]] | Riaddebiti | *da popolare* | Attivo |

## Template Finanziario

```yaml
---
title: "FIN-[Tipo]-[Descrittore]-[YYYY]"
financial_type: [FeeStructure | ShareholderLoan | Utilization | CashPooling | CostRecharge]
amount: [importo]
currency: EUR
party_from: "[[Entita' erogatrice]]"
party_to: "[[Entita' ricevente]]"
rate: [tasso_percentuale]
rate_type: [fisso | variabile]
reference_rate: [Euribor | BTP | Prime | None]
spread: [spread_bp]
maturity: YYYY-MM-DD
tp_method: [CUP | TNMM | CP | Other]
tp_documentation: [MasterFile | LocalFile | Both]
status: [Active | Draft | Closed]
---
```