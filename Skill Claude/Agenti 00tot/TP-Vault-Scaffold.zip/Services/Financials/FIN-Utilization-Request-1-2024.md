---
title: "FIN-Utilization-Request-1 — Prima Tranche (EUR 5,63M)"
date: 2026-04-30
type: financials
category: Financials
status: active
project: "Innovo-Renewables"
financial_type: Utilization
amount: 5630000
currency: EUR
party_from: "[[Innovo Power Generation 1 S.r.l.]]"
party_to: "[[Progetti Rose Garden, Cappella Cantone, Acquacotta]]"
rate: null
rate_type: N_A
reference_rate: None
spread: null
maturity: null
tp_method: N_A
tp_documentation: N_A
related_agreements:
  - "[[../../Agreements/AGR-NotionalCashPooling-2024]]"
related:
  - "[[FIN-ShareholderLoan-BorrowerCo-2024]]"
  - "[[FIN-Utilization-Request-2-2024]]"
tags:
  - innovo
  - fin
  - utilization
  - erogazione
  - rose-garden
  - cappella-cantone
  - acquacotta
  - 2024
---

# FIN-Utilization-Request-1 — Prima Tranche (EUR 5,63M)

## Overview
Prima richiesta irrevocabile di utilizzo del finanziamento a cascata per l'acquisizione di progetti fotovoltaici specifici.

## Struttura della Richiesta

| Parametro | Valore |
|-----------|--------|
| **Importo** | **EUR 5.630.000** |
| **Richiedente** | Innovo Power Generation 1 S.r.l. (BorrowerCo) |
| **Beneficiario finale** | Progetti operativi |
| **Data richiesta** | Dicembre 2024 |
| **Stato** | Erogato |

## Progetti Finanziati

| Progetto | Localita' | MW Stimati | Stato | Note |
|----------|-----------|------------|-------|------|
| **Rose Garden** | *Da popolare* | *Da popolare* | Acquisito | RtB (Ready to Build) |
| **Cappella Cantone** | *Da popolare* | *Da popolare* | Acquisito | RtB |
| **Acquacotta** | *Da popolare* | *Da popolare* | Acquisito | RtB |

## Flusso Documentale

### Richiesta 1 (da BorrowerCo verso AssetCo)
- **Documento:** Utilization Request n. 1 — Innovo Power Generation 1 S.r.l. -> Innovo Power Generation S.r.l.
- **Importo:** EUR 5.630.000
- **Finalita':** Acquisizione progetti Rose Garden, Cappella Cantone, Acquacotta

### Richiesta 1 (da AssetCo verso Capogruppo)
- **Documento:** Utilization Request n. 1 — Innovo Power Generation S.r.l. -> Innovo Renewables S.p.A.
- **Importo:** EUR 5.630.000
- **Finalita':** Medesima

## Meccanismo Back-to-Back
```
Aviva (AEIS) -> Innovo SpA:     EUR 25M @ 9,75%
Innovo SpA -> AssetCo (IPG):    Cascata @ 9,85%
AssetCo -> BorrowerCo (IPG1):   Cascata @ 9,95%
BorrowerCo -> Progetti:         EUR 5,63M (Utilization 1)
```

## Compliance TP
- **Metodo:** N/A per utilization (e' un'erogazione di fondi, non una transazione TP)
- **Nota:** L'acquisizione dei progetti deve essere a valore di mercato per TP
- **Documentazione:** Valutazione fair value progetti acquisiti

---

*Fonte: Utilization Request n. 1.pdf (entrambe le controparti)*