---
title: "FIN-NotionalCashPooling — Gestione Tesoreria Accentrata 2024"
date: 2026-04-30
type: financials
category: Financials
status: active
project: "Innovo-Renewables"
financial_type: CashPooling
amount: null
currency: EUR
party_from: "[[Innovo Renewables S.p.A.]]"
party_to: "[[Partecipate Gruppo Innovo]]"
rate: null
rate_type: N_A
reference_rate: None
spread: null
maturity: null
tp_method: CUP
tp_documentation: Both
related_agreements:
  - "[[../../Agreements/AGR-NotionalCashPooling-2024]]"
related:
  - "[[FIN-ShareholderLoan-Aviva-2024]]"
  - "[[FIN-ShareholderLoan-AssetCo-2024]]"
  - "[[FIN-ShareholderLoan-BorrowerCo-2024]]"
tags:
  - innovo
  - fin
  - cash-pooling
  - treasury
  - notional
  - pool-leader
  - 2024
---

# FIN-NotionalCashPooling — Gestione Tesoreria Accentrata 2024

## Overview
Sistema di gestione accentrata della liquidita' di gruppo tramite **Notional Cash Pooling** virtuale in valute EUR e GBP.

## Meccanismo Operativo

### Pool Leader
- **Entita':** Innovo Renewables S.p.A.
- **Responsabilita':** Gestione flussi, coordinamento banca, reportistica, conversione saldi

### Partecipanti
| Entita' | Paese | Valuta | Saldo Tipo | Stato |
|---------|-------|--------|------------|-------|
| iCube Renewables S.r.l. | Italia | EUR | Attivo | Partecipante |
| Innovo Power Generation S.r.l. | Italia | EUR | Attivo | Partecipante |
| Innovo Power Generation 1 S.r.l. | Italia | EUR | Attivo | Partecipante |
| ETP-AR Energy Limited | UK | GBP | Attivo | Partecipante |
| Innovo Development 7 S.r.l. | Italia | EUR | Attivo | Partecipante |
| *Altre 22 entita'* | *Multi* | *EUR/GBP* | *Da verificare* | *Da verificare* |

### Compensazione Virtuale
```
Saldi partecipanti:
  iCube:        +EUR 500.000 (credito)
  IPG S.r.l.:   -EUR 300.000 (debito)
  ETP-AR:       +GBP 150.000 (credito)
  IPG 1:        -EUR 200.000 (debito)

Compensazione notional:
  Saldo netto EUR: +EUR 0 (500 - 300 - 200 = 0)
  Saldo netto GBP: +GBP 150.000

Ottimizzazione:
  - Debiti compensati -> zero interessi passivi
  - Crediti remunerati -> interessi attivi ottimizzati
```

## Conversione Annuale (31 Dicembre)
Al 31 dicembre di ogni anno:
1. Calcolo saldi netti per ogni partecipante
2. Conversione automatica in **Shareholders' Loans**
3. Tasso di interesse: arm's length (benchmark mercato)
4. Documentazione: loan agreement separato per ogni conversione

| Anno | Saldo Netto | Convertito in SHL | Tasso | Riferimento |
|------|-------------|-------------------|-------|-------------|
| 2024 | *Da calcolare* | *Da verificare* | *Da popolare* | *Da popolare* |

## Compliance TP
- **Servizio Pool Leader:** Fee a valore di mercato (se applicabile)
- **Interessi SHL:** Tassi conformi a Safe Harbour o benchmark
- **Documentazione:** Master File + Local File per giurisdizione
- **Nota:** La compensazione virtuale non genera trasferimenti fisici -> nessuna ritenuta alla fonte

## Vantaggi
- Riduzione oneri bancari esterni
- Ottimizzazione rendimento liquidita'
- Centralizzazione controllo tesoreria
- Flessibilita' allocazione capitali

---

*Fonte: REP - Bozza Cash Pooling (contratto quadro e regole operative)*