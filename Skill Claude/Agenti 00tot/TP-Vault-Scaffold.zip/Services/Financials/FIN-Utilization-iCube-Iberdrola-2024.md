---
title: "FIN-Utilization-iCube-Iberdrola — Tranche iCube (EUR 600K)"
date: 2026-04-30
type: financials
category: Financials
status: active
project: "Innovo-Renewables"
financial_type: Utilization
amount: 600000
currency: EUR
party_from: "[[iCube Renewables S.r.l.]]"
party_to: "[[Iberdrola / Progetti iCube]]"
rate: null
rate_type: N_A
reference_rate: None
spread: null
maturity: null
tp_method: N_A
tp_documentation: N_A
related_agreements:
  - "[[../../Agreements/AGR-iCube-Innovo-20221223]]"
related:
  - "[[FIN-ShareholderLoan-Aviva-2024]]"
  - "[[FIN-TP-FeeStructure-2024]]"
tags:
  - innovo
  - fin
  - utilization
  - icube
  - iberdrola
  - sviluppo
  - 2024
---

# FIN-Utilization-iCube-Iberdrola — Tranche iCube (EUR 600K)

## Overview
Richiesta di utilizzo separata per iCube Renewables S.r.l., la JV con Iberdrola, per il finanziamento dei costi di sviluppo progetti.

## Struttura della Richiesta

| Parametro | Valore |
|-----------|--------|
| **Importo** | **EUR 600.000** |
| **Richiedente** | iCube Renewables S.r.l. |
| **Erogatore** | Iberdrola (tramite meccanismo paritetico) |
| **Data richiesta** | 2024 |
| **Stato** | Erogato |

## Meccanismo Paritetico

### Richiesta Iberdrola -> iCube
- **Documento:** Utilisation 5_Iberdrola_signed-signed.pdf
- **Importo:** EUR 600.000
- **Erogatore:** Iberdrola
- **Beneficiario:** iCube Renewables S.r.l.
- **Finalita':** Costi di sviluppo progetti

### Richiesta Innovo -> iCube (paritetica)
- **Documento:** Utilisation 5_Innovo_signed-signed.pdf
- **Importo:** EUR 600.000
- **Erogatore:** Innovo Renewables S.p.A.
- **Beneficiario:** iCube Renewables S.r.l.
- **Finalita':** Medesima

## Contesto
- iCube Renewables S.r.l. e' una JV tra Innovo e Iberdrola
- I costi di sviluppo sono finanziati paritetivamente dai due soci
- Innovo fornisce anche servizi di sviluppo a iCube (vedi [[AGR-iCube-Innovo-20221223]])
- Questo finanziamento e' separato dalla fee di servizio

## Compliance TP
- **Nota:** Il finanziamento paritetico deve essere a condizioni arm's length
- **Benchmark:** Rate di finanziamento soci per JV settore energy
- **Documentazione:** Da integrare in Local File iCube

---

*Fonte: Utilisation 5_Iberdrola_signed-signed.pdf + Utilisation 5_Innovo_signed-signed.pdf*