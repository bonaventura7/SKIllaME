---
title: "FIN-ShareholderLoan-AssetCo — Prestito Cascata Innovo -> IPG (9,85%)"
date: 2026-04-30
type: financials
category: Financials
status: active
project: "Innovo-Renewables"
financial_type: ShareholderLoan
amount: null
currency: EUR
party_from: "[[Innovo Renewables S.p.A.]]"
party_to: "[[Innovo Power Generation S.r.l.]]"
rate: 9.85
rate_type: fisso
reference_rate: None
spread: 10
spread_basis: bp_vs_originale
maturity: null
tp_method: CUP
tp_documentation: Both
related_agreements:
  - "[[../../Agreements/AGR-NotionalCashPooling-2024]]"
related:
  - "[[FIN-ShareholderLoan-Aviva-2024]]"
  - "[[FIN-ShareholderLoan-BorrowerCo-2024]]"
  - "[[FIN-Utilization-Request-1-2024]]"
tags:
  - innovo
  - fin
  - shareholder-loan
  - assetco
  - ipg
  - cascata
  - 2024
---

# FIN-ShareholderLoan-AssetCo — Prestito Cascata Innovo -> IPG (9,85%)

## Overview
Tranche intermedia del meccanismo di finanziamento a cascata. Innovo Renewables S.p.A. (capogruppo) eroga finanziamenti a Innovo Power Generation S.r.l. (AssetCo), la piattaforma di holding per i progetti operativi.

## Struttura

| Parametro | Valore |
|-----------|--------|
| **Erogatore** | Innovo Renewables S.p.A. |
| **Beneficiario** | Innovo Power Generation S.r.l. (AssetCo) |
| **Tasso** | **9,85% fisso** |
| **Spread vs originale** | +10 bp (vs 9,75% Aviva->Innovo) |
| **Importo** | *Determinato da utilization requests* |

## Ruolo AssetCo
- **Funzione:** Piattaforma di holding per progetti operativi
- **Controllo:** 100% Innovo SpA
- **Attivita':** Detiene partecipazioni nelle SPV operative (BorrowerCo)
- **Cash flow:** Riceve dividendi dalle SPV, serve debito verso capogruppo

## Meccanismo di Erogazione
1. Aviva eroga EUR 25M a Innovo SpA @ 9,75%
2. Innovo SpA eroga a AssetCo @ 9,85% (+10bp)
3. AssetCo eroga a BorrowerCo @ 9,95% (+20bp vs originale)
4. BorrowerCo utilizza per acquisizioni progetti (Rose Garden, etc.)

## Giustificazione Spread +10bp
- **Risk premium entita' intermedia:** AssetCo e' una holding non operativa
- **Costo del capitale aggiuntivo:** Struttura multi-livello richiede remunerazione
- **Benchmark:** Spread 10-30bp per holding intermedie nel settore energy

## Compliance TP
- **Metodo:** CUP per tasso di interesse infragruppo
- **Benchmark:** Prestiti soci holding -> operativa, settore rinnovabili
- **Documentazione:** Master File + Local File

---

*Fonte: AssetCo Loan Agreement Docs + Group Structure Chart*