---
title: "FIN-TP-FeeStructure — Analisi Transfer Pricing Fee Servizi 2024"
date: 2026-04-30
type: financials
category: Financials
status: active
project: "Innovo-Renewables"
financial_type: FeeStructure
amount: 1307793
currency: EUR
party_from: "[[Innovo Renewables S.p.A.]]"
party_to: "[[iCube Renewables S.r.l.]]"
tp_method: CUP
tp_documentation: Both
related_agreements:
  - "[[../../Agreements/AGR-iCube-Innovo-20221223]]"
  - "[[../../Agreements/AGR-Amendment-iCube-20241118]]"
related_services:
  - "[[../../Catalog/SVC-Development-iCube-20221223]]"
related:
  - "[[FIN-CostRecharge-2024]]"
  - "[[Dashboard_Service_Revenue]]"
tags:
  - innovo
  - fin
  - transfer-pricing
  - cup
  - fee-structure
  - icube
  - 2024
---

# FIN-TP-FeeStructure — Analisi Transfer Pricing Fee Servizi 2024

## Overview
Analisi di conformita' Transfer Pricing per la fee annuale di **EUR 1.307.793** corrisposta da iCube Renewables S.r.l. a Innovo Renewables S.p.A. nel 2024.

## Transazione Analizzata

| Parametro | Valore |
|-----------|--------|
| **Fornitore** | Innovo Renewables S.p.A. |
| **Cliente** | iCube Renewables S.r.l. |
| **Tipo servizio** | Development & Management Services |
| **Fee 2024** | **EUR 1.307.793** |
| **Fee 2023** | EUR 871.862 |
| **Variazione** | **+50%** |
| **Natura giuridica** | Obbligazione di mezzi |

## Metodologia TP

### Metodo Selezionato: CUP (Comparable Uncontrolled Price)
Il metodo CUP e' applicabile perche' esistono nel mercato transazioni comparabili di fee di servizio per sviluppo progetti rinnovabili.

### Fattori di Comparabilita'
| Fattore | Stato | Note |
|---------|-------|------|
| Caratteristiche funzionali | Alta | Servizi standard nel settore |
| Condizioni contrattuali | Media | Esclusivita' totale Italia |
| Rischi assumibili | Bassa | Obbligazione di mezzi |
| Attivita' economiche | Alta | Sviluppatore -> IPP |

### Benchmark di Mercato
| Confronto | Fee Range | Fonte |
|-----------|-----------|-------|
| Sviluppo progetti solari Italia | EUR 800-1.500/KW in sviluppo | Bureau van Dijk |
| Management fee IPP | 1,5-3% del valore asset | Industry practice |
| Fee amministrative SPV | EUR 50-120/KW/anno | Comparables TP |

## Analisi Arm's Length

### Test di Conformita'
```
Fee Innovo / MW in sviluppo = EUR 1.307.793 / X MW = EUR Y/MW
Range benchmark: EUR 800-1.500/MW
Posizione: [da calcolare con dati reali]
```

### Giustificazione Incremento 50%
1. **Aumento pipeline:** Da X a Y MW in sviluppo attivo
2. **Maggiore complessita':** Progetti AgriPV + storage
3. **Integrazione PH Engineering:** Competenze tecniche aggiuntive
4. **Scale-up organico:** +13 dipendenti (19 -> 32)

## Documentazione Richiesta
- [x] Master File Italia 2024
- [x] Local File iCube 2024
- [ ] Aggiornamento benchmark 2025
- [ ] Analisi cost-plus come metodo alternativo

## Rischi TP
| Rischio | Probabilita' | Impatto | Mitigazione |
|---------|--------------|---------|-------------|
| Challenge Agenzia Entrate | Media | Alto | Documentazione robusta |
| Variazione fee non giustificata | Bassa | Medio | Benchmark aggiornati |
| Riclassificazione natura servizio | Bassa | Medio | Contratto chiaro |

---

*Template pronto per popolamento dati reali | Fonte: Bilancio FY24 + Service Agreement + Amendment*