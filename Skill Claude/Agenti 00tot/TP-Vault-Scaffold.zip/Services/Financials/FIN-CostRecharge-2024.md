---
title: "FIN-CostRecharge — Riaddebito Costi Amministrativi Infragruppo"
date: 2026-04-30
type: financials
category: Financials
status: active
project: "Innovo-Renewables"
financial_type: CostRecharge
amount: null
currency: EUR
party_from: "[[Innovo Renewables S.p.A.]]"
party_to: "[[Partecipate Gruppo Innovo]]"
rate: null
rate_type: N_A
reference_rate: None
spread: null
maturity: null
tp_method: CostPlus
tp_documentation: Both
related_agreements:
  - "[[../../Agreements/AGR-iCube-Innovo-20221223]]"
related:
  - "[[FIN-TP-FeeStructure-2024]]"
  - "[[Dashboard_Service_Revenue]]"
tags:
  - innovo
  - fin
  - cost-recharge
  - riaddebito
  - cost-plus
  - amministrazione
  - 2024
---

# FIN-CostRecharge — Riaddebito Costi Amministrativi Infragruppo

## Overview
Sistema di riaddebito dei costi amministrativi sostenuti dalla capogruppo Innovo Renewables S.p.A. per conto delle partecipate, dove non esiste un contratto formale di servizio.

## Logica dei Riaddebiti

### Fornitura Diretta (Contract-based)
- Regolata da Service Agreements formali (iCube, Bramante)
- Fee stabilite a valore di mercato (*arm's length*)
- Documentazione TP completa

### Riaddebito Costi (Cost Recharging)
- Dove non c'e' contratto formale
- Innovo SpA riaddebita costi amministrativi sostenuti per conto delle partecipate
- Esempi: assicurazioni, licenze software, servizi legali condivisi

## Categorie di Costi Riaddebitati

| Categoria | Descrizione | Base di Allocazione | Stato |
|-----------|-------------|---------------------|-------|
| Assicurazioni | Polizze gruppo (D&O, property) | Fatturato / asset | Da popolare |
| Licenze software | ERP, SCADA, strumenti | Numero utenti | Da popolare |
| Servizi legali | Consulenza corporate | Tempo dedicato | Da popolare |
| Servizi IT | Infrastruttura, cloud | Consumo | Da popolare |
| Facility | Uffici, domiciliazione | Superficie / dipendenti | Da popolare |

## Metodologia di Allocazione

### Metodo: Cost-Plus
```
Costo diretto:        EUR X
+ Mark-up gestione:   Y% (tipicamente 5-10%)
= Costo riaddebitato: EUR Z
```

### Basi di Allocazione Accettabili
- **Fatturato:** Per costi commerciali e marketing
- **Numero dipendenti:** Per HR, IT, facility
- **Superficie / MW:** Per costi tecnici e operativi
- **Tempo dedicato:** Per servizi professionali (legal, tax)

## Neutralita' Fiscale
- I riaddebiti devono essere a **valore di mercato**
- Mark-up gestione giustificato con benchmark
- Documentazione: analisi cost-plus con comparables
- Obiettivo: evitare doppia tassazione e garantire deductibilita'

## Compliance TP
- **Metodo:** Cost-Plus
- **Benchmark:** Mark-up 5-10% per servizi di supporto amministrativo
- **Documentazione:** Master File + Local File
- **Nota:** I riaddebiti non devono creare margini significativi per la capogruppo

---

*Template pronto per popolamento dati reali | Fonte: Bilancio FY24 + analisi costi amministrativi*