---
title: "Dashboard Group Structure — Organigramma Gruppo Innovo (27 Societa')"
date: 2026-04-30
type: dashboard
category: Dashboard
status: active
project: "Innovo-Renewables"
related:
  - "[[00_MOC_Innovo_Services]]"
  - "[[Dashboard_Service_Revenue]]"
tags:
  - innovo
  - dashboard
  - group-structure
  - governance
  - 2025
---

# Dashboard Group Structure — Organigramma Gruppo Innovo (27 Societa')

## Overview
Il Gruppo Innovo Renewables comprende **27 societa'** totali, con una struttura articolata in JV strategiche, filiera IPP controllata al 100% e centri di competenza specialistici.

## Struttura Ownership

### Livello 1: Capogruppo
- **Innovo Renewables S.p.A.** (Italia)
  - Controllo: Aviva (AEIS) ~70% + management ~30%
  - Funzione: Holding, servizi integrati, tesoreria
  - Rating: Ba3 (Moody's)

### Livello 2: JV Strategiche
```
Innovo Renewables S.p.A.
    |
    +-- iCube Renewables S.r.l. (JV Iberdrola)
    |       |-- Innovo Development 7 S.r.l.
    |       |-- Altre SPV sviluppo
    |
    +-- Innovo Solar Fields S.r.l. (JV Solarfields)
    |       |-- SPV operative
    |
    +-- Innovo Power Generation S.r.l. (AssetCo) [100%]
            |-- Innovo Power Generation 1 S.r.l. (BorrowerCo) [100%]
            |       |-- SPV progetti (Rose Garden, etc.)
            |
            +-- ETP-AR Energy Limited (UK) [100%]
            |       |-- SPV UK
            |
            +-- Altre entita' operative
```

### Livello 3: Centri di Competenza
- **Innovo PH Engineering Services S.r.l.** [100%]
  - Acquisizione: PH Engineering (2025)
  - Funzione: Progettazione, consulenza tecnica

### Totale Societa' per Giurisdizione
| Paese | Numero Societa' | Attivita' Principale |
|-------|-----------------|----------------------|
| Italia | 18 | Sviluppo, IPP, AM, Engineering |
| UK | 4 | Sviluppo, holding |
| Spagna | 3 | Sviluppo |
| Germania | 2 | Engineering (PH) |
| **TOTALE** | **27** | -- |

## Filiera IPP (Controllata al 100%)
```
Innovo SpA
    |
    v  SHL @ 9,85%
Innovo Power Generation S.r.l. (AssetCo)
    |
    v  SHL @ 9,95%
Innovo Power Generation 1 S.r.l. (BorrowerCo)
    |
    v  Equity
SPV Progetto (Rose Garden, Cappella Cantone, etc.)
    |
    v  PPA / Vendita energia
Cash flow -> rimborso prestiti -> dividendi
```

## JV con Iberdrola (iCube)
```
Innovo SpA (50%) + Iberdrola (50%)
    |
    v
iCube Renewables S.r.l. (JV)
    |
    +-- Sviluppo progetti Italia
    +-- Accesso pipeline Iberdrola
    +-- Know-how tecnico
```

## Rating e Merito Creditizio
| Entita' | Rating Moody's | Outlook | Note |
|---------|----------------|---------|------|
| AEIS (Aviva) | Ba1 | Stable | Socio di maggioranza |
| Innovo Renewables S.p.A. | Ba3 | Stable | Capogruppo |
| iCube Renewables S.r.l. | *Non rated* | -- | JV |

---

*Fonte: Ottobre 25_Group Structure Chart + Credit Rating Reports*