---
title: "Dashboard Service Revenue — Ricavi Servizi Infragruppo 2024"
date: 2026-04-30
type: dashboard
category: Dashboard
status: active
project: "Innovo-Renewables"
related:
  - "[[../00_MOC_Innovo_Services]]"
  - "[[../Services/Catalog/SVC-Development-iCube-20221223]]"
  - "[[../Services/Agreements/AGR-Amendment-iCube-20241118]]"
  - "[[../Services/Financials/FIN-TP-FeeStructure-2024]]"
tags:
  - innovo
  - dashboard
  - revenue
  - services
  - 2024
---

# Dashboard Service Revenue — Ricavi Servizi Infragruppo 2024

## Sintesi

| Indicatore | Valore | YoY |
|------------|--------|-----|
| **Ricavi totali servizi** | **EUR 1.307.904** | +50% |
| Di cui: Service Agreement iCube | EUR 1.307.793 | +50% |
| Di cui: Altri contratti | EUR 111 | -99,9% |
| Costi servizi esterni | EUR 1.338.955 | *da popolare* |
| Costo del personale | EUR 4.613.554 | +70% |
| **Margine lordo servizi** | **EUR -31.051** | Negativo |

## Analisi per Tipologia Servizio

| Tipologia | Ricavo 2024 | % Totale | Cliente Principale |
|-----------|-------------|----------|--------------------|
| Development Services | EUR 653.897 | 50% | iCube |
| Management Services | EUR 653.896 | 50% | iCube |
| Asset Management | EUR 0 | 0% | Bozza contratto |
| Engineering Services | EUR 0 | 0% | Interno |
| Treasury Services | EUR 0 | 0% | Pool Leader |

## Concentrazione Cliente
```
iCube Renewables:        99,99%  ████████████████████████████████
Altri (cessati 2023):     0,01%  ▏
```

## Trend Fee iCube
```
2022: EUR 871.862  ████████████████
2023: EUR 871.862  ████████████████
2024: EUR 1.307.793 ████████████████████████████  (+50%)
```

## Marginalita' Analisi

| Voce | Importo | Note |
|------|---------|------|
| Valore della produzione | EUR 1.307.904 | Ricavi servizi |
| Costi per servizi esterni | EUR 1.338.955 | Outsourcing, consulenze |
| Costo del personale | EUR 4.613.554 | +70% YoY |
| **Risultato operativo** | **EUR -4.644.605** | Fisiologico per scale-up |

## KPI Futuri (Target 2025)
- [ ] Diversificazione clienti (riduzione dipendenza iCube)
- [ ] Attivazione fee Asset Management (Bramante)
- [ ] Internalizzazione Engineering (margine PH Engineering)
- [ ] Ottimizzazione costo personale (produttivita' per dipendente)

---

*Fonte: INNOVO RENEWABLES S.P.A. FY 24.pdf — Nota Integrativa*