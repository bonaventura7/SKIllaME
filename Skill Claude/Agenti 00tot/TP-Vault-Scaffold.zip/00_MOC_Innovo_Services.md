---
title: "00 — MOC Servizi Infragruppo Innovo Renewables"
date: 2026-04-30
type: MOC
category: Map-of-Content
status: active
project: "Innovo-Renewables"
related:
  - "[[Services/00_MOC_Services]]"
  - "[[Services/Catalog/00_MOC_Catalog]]"
  - "[[Services/Agreements/00_MOC_Agreements]]"
  - "[[Services/Operations/00_MOC_Operations]]"
  - "[[Services/Financials/00_MOC_Financials]]"
  - "[[Dashboard_Service_Revenue]]"
  - "[[Dashboard_Group_Structure]]"
tags:
  - innovo
  - moc
  - services
  - infragruppo
  - tp
  - governance
  - master-index
---

# 00 — MOC Servizi Infragruppo Innovo Renewables

> **Architettura SOA documentale** del Gruppo Innovo Renewables. Questa nota e' il punto di ingresso principale per navigare l'ecosistema dei servizi, contratti, flussi finanziari e compliance Transfer Pricing.

---

## Struttura del Vault (SOA Layers)

```
Services/
├── Catalog/          -> Definizioni atomiche delle tipologie di servizio
├── Agreements/       -> Contratti legali e accordi commerciali
├── Operations/       -> Output operativi (reporting, verbali, SCADA)
└── Financials/       -> Fee, Transfer Pricing, Cash Pooling, Loans
```

---

## Dashboard di Navigazione Rapida

### A. Servizi di Sviluppo e Management (Core: iCube)
| Documento | Tipo | Fee 2024 | Stato |
|-----------|------|----------|-------|
| [[AGR-iCube-Innovo-20221223]] | Service Agreement | EUR 871.862 (originale) | Attivo |
| [[AGR-Amendment-iCube-20241118]] | Amendment | **EUR 1.307.793** | Attivo |
| [[SVC-Development-iCube-20221223]] | Catalogo servizi | -- | Definito |

**Natura giuridica:** Obbligazione di **mezzi** (*means*), non di risultato.
**Esclusivita':** Totale in Italia a favore di iCube / Iberdrola.

### B. Asset Management (Post-COD)
| Documento | Tipo | Remunerazione | Stato |
|-----------|------|---------------|-------|
| [[AGR-TechCommMgmt-Pineta-2024]] | Technical & Commercial Mgmt | EUR 1.200/MW/anno | Bozza |
| [[SVC-AssetMgmt-Bramante-2024]] | Catalogo servizi AM | -- | Bozza |

**Scope:** Treasury, Bookkeeping, Plant Operation (SCADA), Agricultural Component (AgriPV).

### C. Ingegneria Specialistica
| Documento | Tipo | Entita' | Stato |
|-----------|------|---------|-------|
| [[SVC-Engineering-PH-2024]] | Catalogo servizi | Innovo PH Engineering S.r.l. | Attivo |
| [[AGR-Services-InnovoPH-2024]] | Services Agreement | PH Engineering | Attivo |

**Attivita':** Progettazione, consulenza tecnica, attivita' ordinistiche (Inarcassa).

### D. Tesoreria Accentrata e Finanziamenti
| Documento | Tipo | Importo | Stato |
|-----------|------|---------|-------|
| [[AGR-NotionalCashPooling-2024]] | Cash Pooling Agreement | -- | Attivo |
| [[FIN-ShareholderLoan-Aviva-2024]] | SHL (Aviva -> Innovo) | **EUR 25.000.000** @ 9,75% | Attivo |
| [[FIN-ShareholderLoan-AssetCo-2024]] | SHL (Innovo -> IPG) | Cascata @ 9,85% | Attivo |
| [[FIN-ShareholderLoan-BorrowerCo-2024]] | SHL (IPG -> IPG1) | Cascata @ 9,95% | Attivo |
| [[FIN-Utilization-Request-1-2024]] | Utilization Request | **EUR 5.630.000** | Erogato |
| [[FIN-Utilization-Request-2-2024]] | Utilization Request | **EUR 3.120.000** | Erogato |
| [[FIN-Utilization-iCube-Iberdrola-2024]] | Utilization Request | **EUR 600.000** | Erogato |

**Ruolo Innovo SpA:** **Pool Leader** -- gestione virtuale EUR/GBP senza trasferimenti fisici.

---

## Knowledge Graph -- Relazioni Principali

```mermaid
graph TD
    A[iCube Renewables S.r.l.] -->|Service Agreement| B[Innovo Renewables S.p.A.]
    B -->|Fee EUR 1.307.793| A
    B -->|Pool Leader| C[Notional Cash Pooling]
    C -->|Compensazione virtuale| D[Partecipate gruppo]
    D -->|Saldi netti ->| E[Shareholders Loans]
    B -->|SHL EUR 25M @ 9.75%| F[Aviva / AEIS]
    B -->|SHL cascata @ 9.85%| G[Innovo Power Generation S.r.l.]
    G -->|SHL cascata @ 9.95%| H[Innovo Power Generation 1 S.r.l.]
    H -->|Utilization EUR 5.63M| I[Progetti: Rose Garden, Cappella Cantone, Acquacotta]
    H -->|Utilization EUR 3.12M| J[Progetti: Pink, Tarallo, Acquacotta]
    B -->|Asset Management| K[Progetto Pineta / Bramante S.r.l.]
    B -->|Engineering Services| L[Innovo PH Engineering S.r.l.]
```

---

## Metriche Gruppo (FY 2024)

| Indicatore | Valore | Nota |
|------------|--------|------|
| **Ricavi servizi infragruppo** | EUR 1.307.904 | 100% da contratto iCube |
| **Costi servizi esterni** | EUR 1.338.955 | -- |
| **Costo del personale** | EUR 4.613.554 | +70% YoY (19 -> 32 dipendenti) |
| **Perdita netta 2024** | EUR 7.860.000 | Fisiologica per scale-up |
| **Patrimonio netto** | EUR 32.890.000 | Aumenti capitale Aviva |
| **Pipeline totale** | **8,6 GW** solari + 2,2 GW storage + 600 MW eolici |
| **Societa' nel perimetro** | **27** | Chart ottobre 2025 |
| **Rating Moody's** | **Ba3** (Innovo) / **Ba1** (AEIS/Aviva) | -- |

---

## Governance e Compliance

- **Transfer Pricing:** Tutte le transazioni a valore di mercato (*arm's length*)
- **Metodologia:** CUP (Comparable Uncontrolled Price) per servizi, TNMM per fee AM
- **Documentazione:** Master File e Local File Italia 2024
- **Revisori:** Deloitte & Touche (2024) -> PwC (2025)

---

## Workflow Operativi

1. **Nuovo contratto di servizio** -> Crea in `Services/Agreements/` con prefisso `AGR-`
2. **Nuovo progetto** -> Crea MOC dedicato in `Projects/` con link a servizi correlati
3. **Aggiornamento fee** -> Modifica nota agreement + aggiorna `Dashboard_Service_Revenue`
4. **Nuova utilization** -> Crea in `Services/Financials/` con prefisso `FIN-Utilization-`
5. **Chiusura anno** -> Verifica conversione saldi Cash Pooling in Shareholders Loans

---

*Ultimo aggiornamento: 2026-04-30 | Architetto: Senior Solutions Architect | Vault: C:\Users\luca.consalter\Documents\TP*